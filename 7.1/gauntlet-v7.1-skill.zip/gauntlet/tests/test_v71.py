"""Regression tests for the GAUNTLET 7.1 changes.

Each test names the field problem it guards. They came out of a real run on a
561 MB desktop-app workspace where every mark/check re-hashed the whole tree,
temporary QA folders had to be marked file by file, coverage read near zero,
and the report listed hundreds of probe rows.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT))
sys.path.insert(0, str(SKILL_ROOT / "templates"))

from engine import gauntlet  # noqa: E402
import generate_report  # noqa: E402


class TempCase(unittest.TestCase):
    def setUp(self):
        self._temp = tempfile.TemporaryDirectory()
        self.base = Path(self._temp.name)
        self.root = self.base / "target"
        (self.root / "src").mkdir(parents=True)
        (self.root / "src" / "a.ts").write_text("export const a = 1;\n")
        (self.root / "src" / "b.ts").write_text("export const b = 2;\n")
        (self.root / "tmp" / "qa").mkdir(parents=True)
        (self.root / "tmp" / "qa" / "big.log").write_text("x" * 4096)
        (self.root / "tmp" / "qa" / "shot.png").write_bytes(b"\x89PNG\r\n\x1a\n" + b"0" * 64)
        (self.root / "README.md").write_text("# demo\n")
        self.manifest_path = self.base / "run" / "manifest.json"
        self.manifest_path.parent.mkdir()

    def tearDown(self):
        self._temp.cleanup()

    def build(self, exclusions=None):
        manifest = gauntlet.build_manifest(
            self.root, "full", "REPORT", "shell", 1_000_000, None, None, None,
            owner_exclusions=gauntlet.parse_owner_exclusions(exclusions or []),
        )
        gauntlet.atomic_json(self.manifest_path, manifest)
        return manifest


class OwnerExclusionTests(TempCase):
    def test_parse_rejects_unsafe_or_malformed_values(self):
        for bad in ["/etc=x", "../up=x", "tmp/../..=x", "tmp", "tmp=", "tmp=has space", ".=x", "a=x;rm"]:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                gauntlet.parse_owner_exclusions([bad])
        with self.assertRaises(ValueError):
            gauntlet.parse_owner_exclusions(["tmp=a", "tmp/=b"])
        self.assertEqual(
            gauntlet.parse_owner_exclusions(["./tmp/qa/=temporary_qa_material"]),
            [{"path": "tmp/qa", "reason": "temporary_qa_material"}],
        )

    def test_excluded_subtree_is_one_non_mandatory_surface_and_is_not_hashed(self):
        manifest = self.build(["tmp/qa=temporary_qa_material"])
        by_path = {s["path"]: s for s in manifest["surfaces"]}
        self.assertIn("tmp/qa/", by_path)
        self.assertNotIn("tmp/qa/big.log", by_path)
        excluded = by_path["tmp/qa/"]
        self.assertEqual(excluded["handling"], "owner_excluded")
        self.assertFalse(excluded["mandatory"])
        self.assertEqual(excluded["reason"], "owner_excluded:temporary_qa_material")
        self.assertEqual(manifest["sampling"]["owner_exclusions"], [{"path": "tmp/qa", "reason": "temporary_qa_material"}])
        self.assertTrue(any(e["owner_excluded"] for e in manifest["exclusions"]))
        gauntlet.validate_manifest(manifest)

    def test_single_file_exclusion(self):
        manifest = self.build(["README.md=owner_scope"])
        surface = next(s for s in manifest["surfaces"] if s["path"] == "README.md")
        self.assertEqual(surface["state"], "excluded")
        self.assertIsNone(surface["sha256"])

    def test_fingerprint_recheck_uses_the_same_exclusions(self):
        manifest = self.build(["tmp/qa=temporary_qa_material"])
        # Churn inside the owner-excluded subtree does not invalidate the epoch...
        (self.root / "tmp" / "qa" / "big.log").write_text("changed")
        (self.root / "tmp" / "qa" / "new.txt").write_text("new")
        self.assertEqual(gauntlet.current_target_fingerprint(manifest), manifest["target"]["fingerprint"])
        # ...but a change to in-scope source still does.
        (self.root / "src" / "a.ts").write_text("export const a = 2;\n")
        self.assertNotEqual(gauntlet.current_target_fingerprint(manifest), manifest["target"]["fingerprint"])

    def test_tampered_exclusion_record_is_rejected(self):
        manifest = self.build(["tmp/qa=temporary_qa_material"])
        manifest["sampling"]["owner_exclusions"] = [{"path": "../outside", "reason": "x"}]
        with self.assertRaises(ValueError):
            gauntlet.validate_manifest(manifest)

    def test_unmatched_exclusion_warns(self):
        manifest = self.build(["does/not/exist=typo"])
        self.assertIn("owner exclusion matched nothing: does/not/exist", manifest["warnings"])

    def test_cli_accepts_repeatable_exclude(self):
        out = self.base / "run" / "cli.json"
        gauntlet.main(["manifest", str(self.root), "-o", str(out), "--track", "REPORT",
                       "--exclude", "tmp/qa=temporary_qa_material", "--exclude", "README.md=owner_scope"])
        manifest = json.loads(out.read_text())
        self.assertEqual(len(manifest["sampling"]["owner_exclusions"]), 2)


class BatchTests(TempCase):
    def test_mark_batch_rechecks_the_target_once(self):
        self.build(["tmp/qa=temporary_qa_material"])
        ops = self.base / "run" / "marks.json"
        ops.write_text(json.dumps([
            {"glob": "src/*.ts", "state": "reviewed", "evidence": ["read:src"]},
            {"surface": "README.md", "state": "reviewed", "evidence": ["read:readme"]},
        ]))
        real = gauntlet.current_target_fingerprint
        with mock.patch.object(gauntlet, "current_target_fingerprint", side_effect=real) as spy:
            result = gauntlet.mark_batch(self.manifest_path, ops)
        self.assertEqual(spy.call_count, 1)
        self.assertEqual(result["surfaces_changed"], 3)
        manifest = json.loads(self.manifest_path.read_text())
        self.assertTrue(all(s["state"] == "reviewed" for s in manifest["surfaces"] if s["mandatory"]))

    def test_glob_never_remarks_excluded_subtrees(self):
        (self.root / "src" / "node_modules" / "pkg").mkdir(parents=True)
        (self.root / "src" / "node_modules" / "pkg" / "i.js").write_text("1")
        self.build(["tmp/qa=temporary_qa_material"])
        ops = self.base / "run" / "marks.json"
        ops.write_text(json.dumps([{"glob": "*", "state": "reviewed", "evidence": ["read:all"]}]))
        gauntlet.mark_batch(self.manifest_path, ops)
        by_path = {s["path"]: s for s in json.loads(self.manifest_path.read_text())["surfaces"]}
        self.assertEqual(by_path["tmp/qa/"]["state"], "excluded")
        self.assertEqual(by_path["tmp/qa/"]["reason"], "owner_excluded:temporary_qa_material")
        self.assertEqual(by_path["src/node_modules/"]["state"], "excluded")
        ops.write_text(json.dumps([{"surface": "tmp/qa/", "state": "reviewed", "evidence": ["x"]}]))
        with self.assertRaisesRegex(ValueError, "new manifest"):
            gauntlet.mark_batch(self.manifest_path, ops)

    def test_mark_batch_is_all_or_nothing(self):
        self.build()
        before = self.manifest_path.read_text()
        ops = self.base / "run" / "marks.json"
        ops.write_text(json.dumps([
            {"glob": "src/*.ts", "state": "reviewed", "evidence": ["read:src"]},
            {"glob": "nothing/*", "state": "reviewed", "evidence": ["x"]},
        ]))
        with self.assertRaisesRegex(ValueError, "operation 1"):
            gauntlet.mark_batch(self.manifest_path, ops)
        self.assertEqual(self.manifest_path.read_text(), before)

    def test_mark_batch_refuses_a_changed_target(self):
        self.build()
        (self.root / "src" / "a.ts").write_text("changed\n")
        ops = self.base / "run" / "marks.json"
        ops.write_text(json.dumps([{"surface": "README.md", "state": "reviewed", "evidence": ["x"]}]))
        with self.assertRaisesRegex(ValueError, "target changed"):
            gauntlet.mark_batch(self.manifest_path, ops)

    def test_mark_batch_keeps_single_mark_rules(self):
        self.build()
        ops = self.base / "run" / "marks.json"
        for op, message in [
            ({"surface": "README.md", "state": "reviewed"}, "evidence"),
            ({"surface": "README.md", "state": "excluded"}, "reason"),
            ({"surface": "README.md", "glob": "*", "state": "reviewed", "evidence": ["x"]}, "exactly one"),
            ({"surface": "README.md", "state": "reviewed", "evidence": ["x"], "extra": 1}, "unknown keys"),
        ]:
            with self.subTest(op=op):
                ops.write_text(json.dumps([op]))
                with self.assertRaisesRegex(ValueError, message):
                    gauntlet.mark_batch(self.manifest_path, ops)

    def test_check_batch_records_many_checks_once(self):
        self.build()
        ops = self.base / "run" / "checks.json"
        ops.write_text(json.dumps({"operations": [
            {"id": "CHK-UNIT", "execution": "completed", "result": "holds", "scope": "79 tests", "evidence": ["npm test"]},
            {"id": "CHK-VOICEOVER", "execution": "could_not_run", "result": "unknown", "scope": "VoiceOver walk", "reason": "no screen reader session"},
        ]}))
        real = gauntlet.current_target_fingerprint
        with mock.patch.object(gauntlet, "current_target_fingerprint", side_effect=real) as spy:
            gauntlet.check_batch(self.manifest_path, ops)
        self.assertEqual(spy.call_count, 1)
        checks = {c["id"]: c for c in json.loads(self.manifest_path.read_text())["checks"]}
        self.assertEqual(checks["CHK-UNIT"]["result"], "holds")
        self.assertEqual(checks["CHK-VOICEOVER"]["execution_status"], "could_not_run")

    def test_check_batch_rejects_completed_without_evidence(self):
        self.build()
        ops = self.base / "run" / "checks.json"
        ops.write_text(json.dumps([{"id": "CHK-X", "execution": "completed", "result": "holds", "scope": "x"}]))
        with self.assertRaisesRegex(ValueError, "evidence"):
            gauntlet.check_batch(self.manifest_path, ops)


class CoverageTests(TempCase):
    def test_in_scope_rate_excludes_owner_and_marked_exclusions(self):
        manifest = self.build(["tmp/qa=temporary_qa_material"])
        for surface in manifest["surfaces"]:
            if surface["path"] == "README.md":
                surface.update({"state": "excluded", "reason": "owner_scope"})
            elif surface["mandatory"]:
                surface.update({"state": "reviewed", "evidence": ["read"]})
        gate = gauntlet.coverage_gate(manifest, None)
        coverage = gate["coverage"]
        self.assertEqual(coverage["mandatory_total"], 3)
        self.assertEqual(coverage["in_scope_total"], 2)
        self.assertEqual(coverage["in_scope_rate"], 1.0)
        self.assertAlmostEqual(coverage["rate"], 2 / 3, places=5)
        self.assertTrue(any("temporary_qa_material" in note for note in coverage["notes"]))

    def test_gate_receipt_rejects_inflated_in_scope_rate(self):
        manifest = self.build()
        gate = gauntlet.coverage_gate(manifest, None)
        gate["coverage"]["in_scope_rate"] = 1.0
        with self.assertRaisesRegex(ValueError, "in-scope"):
            gauntlet.validate_gate_receipt(gate)


class DesktopRoutingTests(TempCase):
    def test_tauri_config_routes_the_desktop_pack(self):
        (self.root / "src-tauri" / "capabilities").mkdir(parents=True)
        (self.root / "src-tauri" / "tauri.conf.json").write_text("{}")
        manifest = self.build()
        self.assertIn("gauntlet.desktop", manifest["rule_packs"])
        self.assertIn("gauntlet.application", manifest["rule_packs"])
        self.assertEqual(manifest["rule_routing"][0]["evidence"], ["src-tauri/tauri.conf.json"])
        gauntlet.validate_manifest(manifest)

    def test_plain_web_source_does_not_route_the_desktop_pack(self):
        manifest = self.build()
        self.assertNotIn("gauntlet.desktop", manifest["rule_packs"])
        self.assertEqual(manifest["rule_routing"], [])

    def test_marker_inside_an_owner_exclusion_does_not_route(self):
        (self.root / "tmp" / "qa" / "tauri.conf.json").write_text("{}")
        manifest = self.build(["tmp/qa=temporary_qa_material"])
        self.assertNotIn("gauntlet.desktop", manifest["rule_packs"])

    def test_desktop_pack_is_valid_and_covers_the_field_defects(self):
        packs = gauntlet.load_rule_packs()
        ids = {rule["id"] for rule in packs["gauntlet.desktop"]["rules"]}
        self.assertTrue({"DESK-WINDOW-PERMS", "DESK-QUIT-GUARD", "DESK-ERROR-CONTAIN", "DESK-VERSION",
                         "DESK-WINDOW-STATE", "DESK-BACKUP-RETENTION", "DESK-SIGNING"} <= ids)


class ReportRenderingTests(unittest.TestCase):
    def probe(self, n, result="holds", execution="completed", kind="code"):
        return {"id": f"CHK-P{n}", "kind": kind, "required": True, "blocking": False,
                "execution_status": execution, "result": result, "scope": f"src/f{n}.ts",
                "evidence": [f"/very/long/path/receipts/{n}.json"], "surface_ids": [f"S-{n:012x}"],
                "candidate_count": 1 if result == "candidates" else 0}

    def test_clean_probes_fold_into_one_row_per_adapter(self):
        checks = [self.probe(i) for i in range(40)] + [self.probe(99, result="candidates")]
        checks.append({"id": "CHK-UNIT", "kind": "manual_or_external", "required": True, "blocking": False,
                       "execution_status": "completed", "result": "holds", "scope": "unit tests", "evidence": ["npm test"]})
        html = generate_report.checks_block(checks)
        self.assertIn("code probes", html)
        self.assertIn("41 surfaces", html)
        self.assertIn("CHK-P99", html)      # a probe with candidates is still listed
        self.assertIn("CHK-UNIT", html)     # manual checks are always listed
        self.assertNotIn("CHK-P7<", html)   # clean probes are folded
        self.assertIn('table class="checks"', html)

    def test_full_detail_lists_every_check(self):
        checks = [self.probe(i) for i in range(5)]
        html = generate_report.checks_block(checks, "full")
        for i in range(5):
            self.assertIn(f"CHK-P{i}<", html)

    def test_path_reasons_group_by_directory(self):
        reasons = [{"code": "SURFACE_PENDING", "surface_id": f"S-{i:012x}", "path": f"tmp/qa/shots/{i}.png"} for i in range(300)]
        reasons.append({"code": "OPEN_HIGH", "count": 1})
        items = generate_report.grouped_reasons(reasons)
        self.assertEqual(len(items), 2)
        self.assertTrue(any("tmp/qa/shots/ (300 items)" in item for item in items))

    def test_checks_manifest_sentinel_copies_bound_manifest(self):
        with tempfile.TemporaryDirectory() as temp:
            manifest_path = Path(temp) / "m.json"
            manifest_path.write_text(json.dumps({"checks": [self.probe(1), self.probe(2)]}))
            ledger = {"manifest_path": str(manifest_path), "checks": "manifest"}
            generate_report.resolve_manifest_checks(ledger, None)
            self.assertEqual([c["id"] for c in ledger["checks"]], ["CHK-P1", "CHK-P2"])
        with self.assertRaises(SystemExit):
            generate_report.resolve_manifest_checks({"checks": "everything"}, None)


if __name__ == "__main__":
    unittest.main()
