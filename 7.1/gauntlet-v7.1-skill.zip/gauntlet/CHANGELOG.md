# GAUNTLET changelog

## 7.1 (9 October 2026)

Field fixes from a full v7.0 run on a 561 MB Tauri desktop-app workspace. Data formats stay at schema 7.0; every new field is optional, so 7.0 manifests, ledgers, and receipts still validate.

**Speed on large targets**
- `mark-batch` and `check-batch` apply many surface marks or check results from one JSON file with a single target recheck and one atomic write. All or nothing; a bad entry names its index and leaves the manifest untouched.
- `mark --glob PATTERN` marks every matching surface in one call (`*` also crosses `/`). Excluded subtrees are locked: a glob skips them and an exact reference to one is refused, so an owner exclusion can only change in a new manifest.

**Scope**
- `manifest --exclude PATH=REASON` (repeatable) leaves an owner-designated subtree or file out at creation. It becomes one non-mandatory `owner_excluded` surface, is never hashed, is re-applied on every target recheck, and is listed in coverage notes. Unsafe paths (absolute, `..`, the root) are refused; an exclusion that matches nothing is a warning.

**Coverage**
- The gate adds `in_scope_total` and `in_scope_rate` (reviewed over mandatory surfaces minus excluded) beside the existing raw `rate`, both validated. Owner exclusions are summarized in `coverage.notes`.

**Report**
- `"checks": "manifest"` copies check receipts from the bound manifest, so a report ledger cannot drift from its run.
- Clean probe checks fold into one row per adapter; any probe that did not end `holds` or `not_applicable` is still listed. `"check_detail": "full"` restores every row.
- Gate reasons that name paths are grouped by directory with an item count.
- The Check receipts table uses fixed columns and wraps long paths, so the evidence column no longer clips on screen or in print.
- The coverage badge shows the in-scope rate when present, with the raw rate in the detail line.

**Desktop apps**
- New `gauntlet.desktop` rule pack (window permissions against API calls, quit guard, error containment, version identity, menus and window state, backup retention, signing of shared builds), routed automatically with `gauntlet.application` when the manifest contains a desktop shell marker. The routing reason is recorded in `rule_routing`.

**Compatibility**
- The workbook fixture generator now runs on Python 3.9 (the macOS system Python); the full suite passes on 3.9 and 3.13.

**Tests**
- 25 new tests (102 total). Each new guard was shown to fail when its defect was put back.

## 7.0

Universal manifest, safe probes, independent verifier, coverage gate, and report generator.
