# Module: Native Engine, Coverage, and Run State

**Activate:** every run. This module turns the review protocol into an accountable execution record. It never replaces judgment, module sweeps, runtime checks, or artifact-specific expertise.

## Engine location and safety

Resolve every path relative to the live `SKILL.md`, never the current working directory:

```text
engine/gauntlet.py
schemas/review-manifest-schema.json
schemas/check-receipt-schema.json
schemas/candidate-ledger-schema.json
schemas/verifier-receipt-schema.json
schemas/gate-receipt-schema.json
templates/findings-schema.json
rules/
```

The engine is first-party, standard-library Python, read-only against the target except for explicitly requested manifest and receipt output. It never executes target code. If Python or shell access is unavailable, reproduce the same fields in the working ledger and set the evidence ceiling accordingly. Missing engine access is degradation, not failure, when the target can still be reviewed honestly.

## Run contract

1. **Create the manifest before interpretation.** For a complete file or directory review:
   ```bash
   python3 <skill-root>/engine/gauntlet.py manifest <target> -o <run-dir>/review-manifest.json --mode full --track REPORT --evidence-ceiling full
   ```
   **Leave owner-designated non-deliverables out at creation, not file by file afterwards.** Temporary QA material, screenshots, local exports, build output that is not ignored by name, and archives inside the target are excluded with a repeatable `--exclude PATH=REASON` (path relative to the target, reason a short slug):
   ```bash
   python3 <skill-root>/engine/gauntlet.py manifest <target> -o <run-dir>/review-manifest.json --mode full --track REPORT \
     --exclude tmp/qa=temporary_qa_material --exclude src-tauri/target=build_output
   ```
   Each exclusion becomes one non-mandatory `owner_excluded` surface, is never hashed, is re-applied on every target recheck, and is listed in the gate's coverage notes. Only exclude what the owner has said is not part of the deliverable or what is plainly generated; never exclude entry points, manifests, permission files, stores, or anything a finding depends on. An exclusion that matches nothing is printed as a warning; fix the typo rather than ignoring it.

   For a workspace, commit, or branch change, use `--mode workspace`, `--mode commit --ref <ref>`, or `--mode range --base <ref> --head <ref>`. Git is called without a shell. Commit/range adapters inspect immutable Git blobs rather than ambient working-tree bytes, base-side content represents deletions, and a rename out of a scoped subtree remains an in-scope deletion. Never substitute a hand-written diff list when the engine can resolve it.
2. **Inspect the manifest before reviewing.** Confirm the designated and resolved paths, Git root and refs, target fingerprint, exhaustive or sampled declaration, adapters, rule packs, mandatory surfaces, subtree exclusions, sensitive-path handling, file and surface limits, and warnings. Correct a wrong scope before reading for findings. A surface-budget overflow fails closed; raise the explicit budget or partition the run rather than silently truncating inventory.
3. **Run safe deterministic probes.** `probe` performs local static HTML, workbook, text, secret-candidate, residue, PDF/document-package, selected image/SVG/WAV, ZIP/archive-containment, and generic binary scans and writes hash-bound receipts. `inspect-artifact` runs the same detector against one file. Unsupported codecs and legacy formats return `could_not_run` with the missing parser named. Candidate output is not automatically a finding; adjudicate it against context and counter-evidence.
4. **Mark every mandatory surface.** `reviewed` requires evidence that the surface received its applicable semantic review, not merely that it appeared in a file list. `excluded`, `cannot_verify`, and `failed` require a reason. A directory exclusion accounts for its subtree only when `covers_subtree` is true. `mark --glob 'src/components/*.tsx'` applies one state to every matching path (it must match at least one; `*` also crosses `/`). Excluded subtrees are locked: a glob skips them and an exact reference to one is refused, so changing an exclusion means a new manifest.
5. **Record checks as execution plus result.** Execution is `pending`, `completed`, `failed`, `could_not_run`, or `skipped`. Result is `unknown`, `holds`, `fails`, `candidates`, or `not_applicable`. This keeps a tool crash separate from a target failure. Store exact scope and receipt path.
   **Batch on large targets.** Every `mark` and `check` re-inventories and re-hashes the whole target to prove it has not changed, which is slow on large trees. Write the operations to a JSON file outside the target and apply them with one recheck and one atomic write:
   ```bash
   python3 <skill-root>/engine/gauntlet.py mark-batch <manifest> --ops <run-dir>/marks.json
   python3 <skill-root>/engine/gauntlet.py check-batch <manifest> --ops <run-dir>/checks.json
   ```
   `marks.json` is an array of `{"surface" | "glob", "state", "reason"?, "evidence"?}`; `checks.json` is an array of `{"id", "execution", "result", "scope", "required"?, "blocking"?, "evidence"?, "reason"?}`. The same rules as the single commands apply to every entry, unknown keys are refused, and the batch is all or nothing: one bad entry leaves the manifest untouched and names the entry index.
6. **Persist candidate findings.** During discovery, use `schemas/candidate-ledger-schema.json`: run identity, target fingerprint, manifest path, and findings only. Each finding already uses the full finding contract from `templates/findings-schema.json`. Final REPORT assembly adds verdict, coverage, checks, gate, sections, and revisions required by the full template schema.
7. **Fingerprint findings.** Use normalized artifact location, manifest surfaces, rule or domain, quoted offending material, and root cause. Harmless source line movement must not create a new identity. The engine command is available when needed:
   ```bash
   python3 <skill-root>/engine/gauntlet.py fingerprint --location <coordinate> --rule <id> --quote <quote> --root-cause <cause>
   ```
8. **Run the independent verifier.** Discovery does not approve itself:
   ```bash
   python3 <skill-root>/engine/gauntlet.py verify <manifest> <ledger> -o <run-dir>/verifier-receipt.json
   ```
   It rechecks target and ledger binding, fingerprints, surface references, current hashes, and anchors, then records `CHK-FINDINGS-VERIFIER` with both the verifier receipt and exact candidate ledger as evidence. Any non-empty finding set still requires independent human adjudication of factual consequence, counter-evidence, severity, confidence, root cause, duplication, and regression. That separate verifier must issue a schema-valid receipt bound to the candidate-ledger SHA-256, list the same finding IDs and fingerprints, resolve all human checks, and report `holds`. Then record both immutable inputs:
   ```bash
   python3 <skill-root>/engine/gauntlet.py check <manifest> --id CHK-FINDINGS-VERIFIER --execution completed --result holds --required --blocking --scope "verified findings ledger" --evidence <verifier-receipt> --evidence <candidate-ledger>
   ```
   A status flag or free-form adjudication note is not a verifier receipt. Never clear a protected finding merely to satisfy the gate.
9. **Compare re-reviews conservatively.** `compare` classifies new, persisting, fixed, regressed, accepted, withdrawn, and not-rechecked findings. Absence from a later ledger is never resolution.
10. **Run the gate before delivery.** `gate <manifest> --ledger <ledger>` rechecks the live target, opens and validates the bound verifier receipt and candidate ledger, records SHA-256 bindings for the manifest, candidate ledger, and verifier receipt, then combines surface coverage, check execution, verifier state, blocking results, and finding state. Its result is an input to final judgment and cannot be overridden silently. The report ledger stores the gate-receipt path and SHA-256; report generation reopens the receipt and requires byte-hash and embedded-gate agreement.
11. **Start a fresh epoch after mutation.** Any edit to target bytes or scope invalidates the manifest. Generate a new manifest and ledger, preserve the prior run, and use `compare`; never rewrite an old fingerprint or reuse stale receipts. The engine refuses probe, mark, check, verifier, and READY gate operations against changed targets.

## Universal terminal states

Every manifest item ends in exactly one state:

- **reviewed**: applicable inspection completed, with evidence.
- **excluded**: intentionally outside scope, with a valid reason and whether a subtree is covered.
- **cannot_verify**: applicable, but evidence, access, parser, tool, format expertise, or safe execution is missing.
- **failed**: inspection was attempted but failed; the failure itself is visible.
- **pending**: unfinished. A mandatory pending item blocks READY.

Never mark a surface reviewed because a scanner opened it, a model mentioned it, another file imports it, or no finding was reported. The `mark` command requires an evidence reference for `reviewed`. Manifest, receipt, and verifier output belongs outside a reviewed directory so evidence generation cannot mutate the target or silently expand a Git change set.

## Secret-safe dual plane

Sensitive paths stay local. Deterministic secret checks may inspect them on the owner's machine; receipts contain rule ID, line or coordinate, count, and redaction state, never the value. External models receive sanitized context only. A protected file is not excluded from the security disposition merely because its raw contents cannot leave the machine.

## Adapter and rule routing

The manifest proposes adapters and first-party rule packs from file type and structure. A desktop shell marker (`tauri.conf.json`, an Electron builder or Forge config, `Info.plist`, an `.entitlements` file, `AppxManifest.xml`) routes `gauntlet.application` and `gauntlet.desktop` automatically and records why in `rule_routing`. The desktop pack holds the cheap checks that catch real shipped defects: window permissions against the API calls that need them, quit paths through the unsaved-edit guard, error containment, version identity, menus and window state, backup retention, and signing of shared builds. Classification in Phase 1 may add application, web, AI-agent, document, media, or other packs based on the whole target. It may not remove `gauntlet.core`, the safety gates, or an applicable rule merely to reduce work. Rules are inspection memory: each still receives an applicability decision, evidence, and counter-evidence where material.

## Coverage gate interpretation

- **READY**: every mandatory surface reviewed, every required check completed, no blocking failure, no open CRITICAL or HIGH, and no accepted HIGH or unresolved evidence condition.
- **CONDITIONAL**: no hard failure, but a mandatory uncertainty, accepted HIGH, assumption, or unverifiable item remains.
- **NOT_READY**: REPORT, HYBRID, or DIFFERENTIAL target has a failed mandatory surface/check or an open CRITICAL/HIGH.
- **BLOCKED**: REBUILD target cannot satisfy a mandatory gate or material defect with available authority and evidence.

**Two coverage figures.** `rate` is reviewed over every mandatory surface. `in_scope_rate` is reviewed over mandatory surfaces minus those marked excluded, so a run that excludes a large folder by reason still shows how much of the real scope was read. Report the in-scope figure as the headline and the raw figure beside it; never quote one without the other when they differ. Exclusions still appear as gate reasons and keep the verdict at CONDITIONAL or below until they are resolved or accepted by the owner.

**Report ledger shortcuts.** Set `"checks": "manifest"` in the report ledger to copy the check receipts from the bound manifest instead of transcribing them. The report folds clean probe checks into one row per adapter and lists every probe that did not end `completed` with `holds` or `not_applicable`; set `"check_detail": "full"` to list every row. Gate reasons that name paths are grouped by directory.

A gate file is not the report. Explain the reasons, their consequences, and the exact next proof in delivery.
