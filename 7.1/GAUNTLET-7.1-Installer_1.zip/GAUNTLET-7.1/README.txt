GAUNTLET 7.1

Install on this Mac (Claude Code in Terminal and in the Claude desktop app)
1. Put this GAUNTLET-7.1 folder in Downloads (AirDrop saves it there).
2. Open Terminal and run:
     bash ~/Downloads/GAUNTLET-7.1/install.sh
   (Double-clicking "Install Gauntlet.command" also works when macOS allows it.)
3. Start a new Claude Code session and type /gauntlet

The installer moves any older version to ~/.claude/skills-backup/ before copying,
then runs the built-in self-test. Nothing outside ~/.claude is changed.

What changed: see gauntlet/CHANGELOG.md
