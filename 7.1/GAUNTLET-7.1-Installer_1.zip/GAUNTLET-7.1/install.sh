#!/bin/bash
# GAUNTLET 7.1 installer for Claude Code on macOS (terminal and the Claude desktop app).
# Run it with:   bash ~/Downloads/GAUNTLET-7.1/install.sh
# (Running it through bash works even when macOS blocks double-clicked scripts.)
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/gauntlet"
SKILLS="$HOME/.claude/skills"
DEST="$SKILLS/gauntlet"
BACKUPS="$HOME/.claude/skills-backup"

if [ ! -f "$SRC/SKILL.md" ]; then
  echo "Cannot find gauntlet/SKILL.md next to this installer. Unzip the whole folder first." >&2
  exit 1
fi
VERSION="$(grep -m1 'version:' "$SRC/SKILL.md" | sed 's/.*"\(.*\)".*/\1/')"
echo "Installing GAUNTLET $VERSION into $DEST"

mkdir -p "$SKILLS"
if [ -e "$DEST" ] || [ -L "$DEST" ]; then
  mkdir -p "$BACKUPS"
  OLD="$(grep -m1 'version:' "$DEST/SKILL.md" 2>/dev/null | sed 's/.*"\(.*\)".*/\1/' || true)"
  BK="$BACKUPS/gauntlet-${OLD:-unknown}-$(date +%Y%m%d-%H%M%S)"
  mv "$DEST" "$BK"
  echo "Previous version ${OLD:-unknown} moved to: $BK"
fi

cp -R "$SRC" "$DEST"
# Files that arrive by AirDrop or download carry a quarantine flag; clear it on the installed copy only.
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true
chmod +x "$DEST/engine/gauntlet.py" "$DEST/templates/generate_report.py" 2>/dev/null || true

INSTALLED="$(grep -m1 'version:' "$DEST/SKILL.md" | sed 's/.*"\(.*\)".*/\1/')"
if [ "$INSTALLED" != "$VERSION" ]; then
  echo "Install check failed: expected $VERSION, found $INSTALLED" >&2
  exit 1
fi

if command -v python3 >/dev/null 2>&1; then
  echo "Engine: $(python3 "$DEST/engine/gauntlet.py" --version 2>&1)"
  echo "Running the self-test (about 5 seconds)..."
  TMPRUN="$(mktemp -d)"
  if (cd "$DEST" && PYTHONDONTWRITEBYTECODE=1 TMPDIR="$TMPRUN" python3 -m unittest discover -s tests -q >"$TMPRUN/selftest.log" 2>&1); then
    echo "Self-test: $(grep -E '^Ran ' "$TMPRUN/selftest.log") - all passed"
  else
    echo "Self-test reported problems. The skill is installed; the log is at $TMPRUN/selftest.log"
  fi
  find "$DEST" -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
else
  echo "python3 not found. The skill is installed and works; the engine needs Python 3.9+ (xcode-select --install)."
fi

echo
echo "Done. GAUNTLET $INSTALLED is installed for Claude Code."
echo "Start a new Claude Code session (terminal or the Code tab in the Claude desktop app) and type /gauntlet"
