#!/bin/bash
# Double-click helper. If macOS blocks it, open Terminal and run:  bash ~/Downloads/GAUNTLET-7.1/install.sh
bash "$(cd "$(dirname "$0")" && pwd)/install.sh"
echo
read -n 1 -s -r -p "Press any key to close this window."
