#!/usr/bin/env python3
"""Gauntlet native support engine.

This tool supplies deterministic mechanics to the Gauntlet review skill. It does
not replace adversarial reasoning. It creates universal review manifests,
resolves Git change scope, routes first-party rule packs, runs safe static
artifact probes, records check receipts, fingerprints findings, compares runs,
and computes coverage-aware gates.

The engine uses only the Python standard library and never executes target code.
Run `python3 engine/gauntlet.py --help` from any directory.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html.parser
import json
import os
import re
import stat as statlib
import struct
import subprocess
import sys
import tempfile
import uuid
import wave
import zipfile
import zlib
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlsplit, urlunsplit
import xml.etree.ElementTree as ET

ENGINE_VERSION = "7.0.0"
SCHEMA_VERSION = "7.0"
ROOT = Path(__file__).resolve().parents[1]
RULES_DIR = ROOT / "rules"

SURFACE_STATES = {"pending", "reviewed", "excluded", "cannot_verify", "failed"}
EXECUTION_STATES = {"pending", "completed", "failed", "could_not_run", "skipped"}
CHECK_RESULTS = {"unknown", "holds", "fails", "candidates", "not_applicable"}
TRACKS = {"UNDECIDED", "REBUILD", "REPORT", "HYBRID", "DIFFERENTIAL"}
EVIDENCE_CEILINGS = {"full", "shell_network", "shell", "text_only"}

EXCLUDED_DIRS = {
    ".git": "version_control_internals",
    ".hg": "version_control_internals",
    ".svn": "version_control_internals",
    "node_modules": "generated_dependency_tree",
    ".venv": "generated_dependency_tree",
    "venv": "generated_dependency_tree",
    "__pycache__": "generated_cache",
    ".pytest_cache": "generated_cache",
    ".mypy_cache": "generated_cache",
    ".ruff_cache": "generated_cache",
    ".tox": "generated_cache",
    ".gradle": "generated_cache",
    ".dart_tool": "generated_cache",
    "DerivedData": "generated_cache",
    "Pods": "generated_dependency_tree",
}
EXCLUDED_FILES = {".DS_Store": "operating_system_metadata", "Thumbs.db": "operating_system_metadata"}

CODE_EXTENSIONS = {
    ".c", ".cc", ".cpp", ".cs", ".dart", ".ex", ".exs", ".go", ".h", ".hpp",
    ".java", ".js", ".jsx", ".kt", ".kts", ".lua", ".m", ".mm", ".php", ".pl",
    ".py", ".r", ".rb", ".rs", ".scala", ".sh", ".swift", ".ts", ".tsx", ".vue",
}
DATA_CONFIG_EXTENSIONS = {
    ".cfg", ".conf", ".css", ".env", ".ini", ".json", ".jsonl", ".lock", ".plist",
    ".properties", ".sql", ".toml", ".xml", ".yaml", ".yml",
}
INSTRUCTION_EXTENSIONS = {".md", ".mdx", ".prompt", ".rst", ".txt"}
WORKBOOK_EXTENSIONS = {".csv", ".ods", ".tsv", ".xls", ".xlsm", ".xlsx"}
DOCUMENT_EXTENSIONS = {".doc", ".docx", ".epub", ".pages", ".pdf", ".rtf"}
MEDIA_EXTENSIONS = {
    ".aiff", ".avi", ".bmp", ".flac", ".gif", ".jpeg", ".jpg", ".m4a", ".mkv",
    ".mov", ".mp3", ".mp4", ".ogg", ".opus", ".png", ".svg", ".tif", ".tiff",
    ".wav", ".webm", ".webp",
}
ARCHIVE_EXTENSIONS = {".7z", ".dmg", ".gz", ".iso", ".rar", ".tar", ".tgz", ".zip"}

SENSITIVE_NAME_PATTERNS = [
    re.compile(r"^\.env(?:\..+)?$", re.I),
    re.compile(r"^(?:id_rsa|id_dsa|id_ecdsa|id_ed25519)$", re.I),
    re.compile(r"\.(?:key|p12|pfx|pem)$", re.I),
    re.compile(r"^(?:credentials|secrets?)(?:\..+)?$", re.I),
]

PACKS_BY_ADAPTER = {
    "repository": ["gauntlet.core", "gauntlet.code", "gauntlet.slop"],
    "code": ["gauntlet.core", "gauntlet.code", "gauntlet.slop"],
    "html": ["gauntlet.core", "gauntlet.html", "gauntlet.web", "gauntlet.slop"],
    "workbook": ["gauntlet.core", "gauntlet.workbook", "gauntlet.slop"],
    "data-config": ["gauntlet.core", "gauntlet.data"],
    "instruction": ["gauntlet.core", "gauntlet.instruction", "gauntlet.slop"],
    "ai-agent": ["gauntlet.core", "gauntlet.ai-agent", "gauntlet.slop"],
    "web": ["gauntlet.core", "gauntlet.web", "gauntlet.slop"],
    "application": ["gauntlet.core", "gauntlet.application", "gauntlet.slop"],
    "document": ["gauntlet.core", "gauntlet.document", "gauntlet.slop"],
    "media": ["gauntlet.core", "gauntlet.media"],
    "archive-binary": ["gauntlet.core", "gauntlet.binary"],
    "generic-text": ["gauntlet.core", "gauntlet.slop"],
    "generic-file": ["gauntlet.core", "gauntlet.binary"],
    "symlink": ["gauntlet.core"],
    "directory": ["gauntlet.core"],
}

SECRET_PATTERNS = [
    ("SECRET-PRIVATE-KEY", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
    ("SECRET-STRIPE-LIVE", re.compile(r"\bsk_live_[A-Za-z0-9]{12,}\b")),
    ("SECRET-AWS-ACCESS", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("SECRET-GOOGLE-API", re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b")),
    ("SECRET-GITHUB-TOKEN", re.compile(r"\b(?:ghp|github_pat)_[A-Za-z0-9_]{20,}\b")),
    ("SECRET-BEARER", re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{16,}", re.I)),
    ("SECRET-URL-CREDENTIALS", re.compile(r"\b[a-z][a-z0-9+.-]*://[^\s:/?#]+:[^@\s/]+@", re.I)),
    ("SECRET-ASSIGNMENT", re.compile(r"\b(?:api[_-]?key|secret|token|password)\s*[:=]\s*['\"][^'\"\n]{8,}['\"]", re.I)),
    ("SECRET-ENV-ASSIGNMENT", re.compile(r"^\s*(?:export\s+)?[A-Z0-9_]*(?:API_KEY|SECRET|TOKEN|PASSWORD)[A-Z0-9_]*\s*=\s*[^\s#'\"]{8,}\s*$", re.M)),
]
SLOP_PATTERNS = [
    ("SLOP-PLACEHOLDER", re.compile(r"\b(?:TODO|FIXME|HACK|XXX|lorem ipsum)\b", re.I)),
    ("SLOP-LOCALHOST", re.compile(r"\b(?:localhost|127\.0\.0\.1)(?::\d+)?\b", re.I)),
    ("SLOP-EMPTY-CATCH", re.compile(r"catch\s*(?:\([^)]*\))?\s*\{\s*\}", re.S)),
    ("SLOP-DEBUG-LOG", re.compile(r"\b(?:console\.log|debugger\s*;|debugPrint\s*\(|print\s*\(\s*['\"](?:DEBUG|TRACE|TEMP)\b)", re.I)),
]

def secret_matches(pattern: re.Pattern[str], text: str) -> list[re.Match[str]]:
    return [match for match in pattern.finditer(text) if "redacted" not in match.group(0).lower()]


def detected_secret_ids(text: str) -> list[str]:
    return sorted(pattern_id for pattern_id, pattern in SECRET_PATTERNS if secret_matches(pattern, text))


MAX_STATIC_TEXT_BYTES = 20 * 1024 * 1024
DEFAULT_MAX_FILE_BYTES = MAX_STATIC_TEXT_BYTES
DEFAULT_MAX_SURFACES = 100_000
MAX_ZIP_ENTRIES = 100_000
MAX_ZIP_ENTRY_BYTES = 64 * 1024 * 1024
MAX_ZIP_TOTAL_BYTES = 512 * 1024 * 1024
MAX_ZIP_RATIO = 1_000


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def short_hash(*parts: Any, length: int = 16) -> str:
    material = "\0".join("" if p is None else str(p) for p in parts)
    return hashlib.sha256(material.encode("utf-8", "surrogateescape")).hexdigest()[:length]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_json(path: Path, data: Any) -> None:
    path = path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, ensure_ascii=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON in {path}: line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc


def ensure_within(path: Path, root: Path) -> Path:
    resolved = path.resolve(strict=False)
    root_resolved = root.resolve(strict=False)
    try:
        resolved.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"path escapes target root: {path}") from exc
    return resolved


def normalized_rel(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix() or "."


def is_sensitive_name(path: Path) -> bool:
    return any(pattern.search(path.name) for pattern in SENSITIVE_NAME_PATTERNS)


def looks_text_bytes(sample: bytes) -> bool:
    sample = sample[:8192]
    if not sample:
        return True
    if sample.startswith((b"\xff\xfe", b"\xfe\xff", b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff")):
        return True
    if b"\x00" in sample:
        return False
    try:
        sample.decode("utf-8")
        return True
    except UnicodeDecodeError:
        printable = sum(byte in b"\t\n\r" or 32 <= byte < 127 for byte in sample)
        return printable / len(sample) > 0.88


def looks_text(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            return looks_text_bytes(handle.read(8192))
    except (OSError, PermissionError):
        return False


def decode_text_local(data: bytes) -> str:
    if data.startswith((b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff")):
        return data.decode("utf-32")
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    return data.decode("utf-8-sig", "replace")


def read_text_local(path: Path) -> str:
    return decode_text_local(path.read_bytes())


def magic_kind_bytes(head: bytes) -> str | None:
    signatures = [
        (b"%PDF", "pdf"), (b"PK\x03\x04", "zip"), (b"\x89PNG\r\n\x1a\n", "png"),
        (b"\xff\xd8\xff", "jpeg"), (b"GIF87a", "gif"), (b"GIF89a", "gif"),
        (b"SQLite format 3\x00", "sqlite"), (b"\x1f\x8b", "gzip"),
    ]
    for signature, kind in signatures:
        if head.startswith(signature):
            return kind
    return None


def magic_kind(path: Path) -> str | None:
    try:
        with path.open("rb") as handle:
            return magic_kind_bytes(handle.read(16))
    except (OSError, PermissionError):
        return None


def classify_file(path: Path, exists: bool = True, content: bytes | None = None) -> dict[str, Any]:
    suffix = path.suffix.lower()
    name = path.name.lower()
    sensitive = is_sensitive_name(path)
    magic = magic_kind_bytes(content[:16]) if content is not None else magic_kind(path) if exists and path.is_file() else None

    if magic == "pdf":
        kind, adapter = "document", "document"
    elif magic in {"png", "jpeg", "gif"}:
        kind, adapter = "media", "media"
    elif magic == "zip" and suffix in WORKBOOK_EXTENSIONS:
        kind, adapter = "workbook", "workbook"
    elif magic == "zip" and suffix in DOCUMENT_EXTENSIONS:
        kind, adapter = "document", "document"
    elif magic in {"zip", "gzip"}:
        kind, adapter = "archive_or_binary", "archive-binary"
    elif magic == "sqlite":
        kind, adapter = "data_or_configuration", "data-config"
    elif suffix in {".html", ".htm"}:
        kind, adapter = "standalone_html", "html"
    elif suffix in WORKBOOK_EXTENSIONS:
        kind, adapter = "workbook", "workbook"
    elif suffix in CODE_EXTENSIONS or name in {"dockerfile", "makefile", "rakefile", "gemfile"}:
        kind, adapter = "source_code", "code"
    elif suffix in DATA_CONFIG_EXTENSIONS or name in {"package.json", "cargo.toml", "go.mod", "docker-compose.yml"}:
        kind, adapter = "data_or_configuration", "data-config"
    elif suffix in INSTRUCTION_EXTENSIONS:
        kind, adapter = "instruction_or_document", "instruction"
    elif suffix in DOCUMENT_EXTENSIONS or magic == "pdf":
        kind, adapter = "document", "document"
    elif suffix in MEDIA_EXTENSIONS or magic in {"png", "jpeg", "gif"}:
        kind, adapter = "media", "media"
    elif suffix in ARCHIVE_EXTENSIONS or magic in {"zip", "gzip"}:
        kind, adapter = "archive_or_binary", "archive-binary"
    elif (content is not None and looks_text_bytes(content)) or (content is None and exists and looks_text(path)):
        kind, adapter = "text", "generic-text"
    else:
        kind, adapter = "binary_or_unknown", "generic-file"

    expected_extensions = {
        "pdf": {".pdf"}, "png": {".png"}, "jpeg": {".jpg", ".jpeg"}, "gif": {".gif"},
        "gzip": {".gz", ".tgz"}, "sqlite": {".db", ".sqlite", ".sqlite3"},
        "zip": {".zip", ".xlsx", ".xlsm", ".ods", ".docx", ".epub", ".pages", ".jar", ".whl", ".apk", ".ipa"},
    }
    return {
        "kind": kind,
        "adapter": adapter,
        "extension": suffix,
        "magic": magic,
        "extension_magic_mismatch": bool(magic and suffix and suffix not in expected_extensions.get(magic, {suffix})),
        "handling": "local_only" if sensitive else "normal",
        "sensitive_path": sensitive,
        "rule_packs": PACKS_BY_ADAPTER.get(adapter, ["gauntlet.core"]),
    }


def surface_id(relative_path: str) -> str:
    return "S-" + short_hash(relative_path, length=12)


def build_surface(path: Path, root: Path, max_file_bytes: int, change: dict[str, Any] | None = None) -> dict[str, Any]:
    rel = normalized_rel(path, root)
    base: dict[str, Any] = {
        "id": surface_id(rel),
        "path": rel,
        "absolute_path": str(path.resolve(strict=False)),
        "mandatory": True,
        "coverage_method": "exhaustive",
        "state": "pending",
        "reason": None,
        "evidence": [],
    }
    if change:
        base["change"] = change
    if change and change.get("status") == "D":
        info = classify_file(path, exists=False)
        base.update(info)
        base.update({"exists": False, "size": None, "sha256": None})
        return base
    if path.is_symlink():
        target = os.readlink(path)
        resolved = path.resolve(strict=False)
        try:
            resolved.relative_to(root.resolve())
            outside = False
        except ValueError:
            outside = True
        base.update({
            "kind": "symlink", "adapter": "symlink", "extension": path.suffix.lower(),
            "magic": None, "handling": "metadata_only", "coverage_method": "metadata_only", "sensitive_path": False,
            "rule_packs": PACKS_BY_ADAPTER["symlink"], "exists": True,
            "size": path.lstat().st_size, "sha256": short_hash(target, length=64), "file_mode": statlib.S_IMODE(path.lstat().st_mode),
            "link_target": target, "link_outside_root": outside,
        })
        return base
    try:
        stat = path.stat()
    except (OSError, PermissionError) as exc:
        info = classify_file(path, exists=False)
        base.update(info)
        base.update({"exists": path.exists(), "size": None, "sha256": None, "coverage_method": "metadata_only", "state": "cannot_verify", "reason": f"stat_failed:{type(exc).__name__}"})
        return base
    info = classify_file(path)
    base.update(info)
    base.update({"exists": True, "size": stat.st_size, "sha256": None, "file_mode": statlib.S_IMODE(stat.st_mode)})
    if stat.st_size > max_file_bytes:
        base.update({"state": "cannot_verify", "reason": "size_limit", "handling": "metadata_only", "coverage_method": "metadata_only"})
        return base
    try:
        base["sha256"] = sha256_file(path)
    except (OSError, PermissionError) as exc:
        base.update({"state": "cannot_verify", "reason": f"hash_failed:{type(exc).__name__}"})
    return base


def build_git_blob_surface(root: Path, change: dict[str, Any], git_meta: dict[str, Any], max_file_bytes: int) -> dict[str, Any]:
    rel = change["path"]
    deleted = change.get("status") == "D"
    mode = git_meta["mode"]
    if mode == "workspace":
        content_ref = git_meta["head"] if deleted else None
    elif mode == "commit":
        content_ref = git_meta.get("parent") if deleted else git_meta["commit"]
    else:
        content_ref = git_meta["merge_base"] if deleted else git_meta["head"]
    if not content_ref:
        return build_surface(root / rel, root, max_file_bytes, change=change)
    base: dict[str, Any] = {
        "id": surface_id(rel), "path": rel, "absolute_path": str((root / rel).resolve(strict=False)),
        "mandatory": True, "coverage_method": "exhaustive", "state": "pending", "reason": None,
        "evidence": [], "change": change, "exists": not deleted, "historical_content": deleted,
        "content_source": "git_blob", "git_root": str(root), "content_ref": content_ref,
    }
    try:
        entry = git_tree_entry(root, content_ref, rel)
        content, oid = read_git_blob(root, content_ref, rel)
    except ValueError as exc:
        info = classify_file(root / rel, exists=False)
        base.update(info)
        base.update({"size": None, "sha256": None, "blob_oid": None, "state": "cannot_verify", "reason": f"blob_unavailable:{type(exc).__name__}", "handling": "metadata_only", "coverage_method": "metadata_only"})
        return base
    if entry and entry["mode"] == "120000":
        link_target = os.fsdecode(content)
        resolved_link = ((root / rel).parent / link_target).resolve(strict=False)
        try:
            resolved_link.relative_to(root.resolve())
            outside = False
        except ValueError:
            outside = True
        info = {
            "kind": "symlink", "adapter": "symlink", "extension": (root / rel).suffix.lower(),
            "magic": None, "extension_magic_mismatch": False, "handling": "metadata_only",
            "sensitive_path": False, "rule_packs": PACKS_BY_ADAPTER["symlink"],
            "coverage_method": "metadata_only", "link_target": link_target, "link_outside_root": outside,
        }
    else:
        info = classify_file(root / rel, exists=False, content=content)
    base.update(info)
    base.update({"size": len(content), "sha256": hashlib.sha256(content).hexdigest(), "blob_oid": oid, "git_mode": entry["mode"] if entry else None})
    if len(content) > max_file_bytes:
        base.update({"state": "cannot_verify", "reason": "size_limit", "handling": "metadata_only", "coverage_method": "metadata_only"})
    return base


def excluded_subtree_surface(path: Path, root: Path, reason: str) -> dict[str, Any]:
    rel = normalized_rel(path, root)
    return {
        "id": surface_id(rel + "/"), "path": rel + "/", "absolute_path": str(path.resolve(strict=False)),
        "kind": "directory", "adapter": "directory", "extension": "", "magic": None,
        "handling": "excluded_subtree", "sensitive_path": False,
        "rule_packs": PACKS_BY_ADAPTER["directory"], "exists": True, "size": None,
        "sha256": None, "mandatory": False, "coverage_method": "excluded", "state": "excluded", "reason": reason,
        "covers_subtree": True, "evidence": [],
    }


def inventory_full(target: Path, max_file_bytes: int, max_surfaces: int = DEFAULT_MAX_SURFACES) -> tuple[Path, list[dict[str, Any]], list[str]]:
    warnings: list[str] = []
    if target.is_file() or target.is_symlink():
        root = target.parent
        return root, [build_surface(target, root, max_file_bytes)], warnings
    if not target.is_dir():
        raise ValueError(f"target is not a readable file or directory: {target}")
    root = target.resolve()
    surfaces: list[dict[str, Any]] = []

    def walk_error(exc: OSError) -> None:
        failed_path = Path(exc.filename).resolve(strict=False) if exc.filename else root
        try:
            rel = normalized_rel(failed_path, root).rstrip("/") + "/"
        except ValueError:
            rel = "./"
        surfaces.append({
            "id": surface_id(rel), "path": rel, "absolute_path": str(failed_path),
            "kind": "directory", "adapter": "directory", "extension": "", "magic": None,
            "handling": "metadata_only", "sensitive_path": False, "rule_packs": PACKS_BY_ADAPTER["directory"],
            "exists": failed_path.exists(), "size": None, "sha256": None, "mandatory": True,
            "coverage_method": "metadata_only", "state": "cannot_verify", "reason": f"walk_failed:{type(exc).__name__}",
            "covers_subtree": True, "evidence": [],
        })
        warnings.append(f"directory inventory failed for {rel}: {type(exc).__name__}")

    for dirpath, dirnames, filenames in os.walk(root, topdown=True, followlinks=False, onerror=walk_error):
        current = Path(dirpath)
        kept_dirs: list[str] = []
        for dirname in sorted(dirnames):
            child = current / dirname
            if child.is_symlink():
                surfaces.append(build_surface(child, root, max_file_bytes))
            elif dirname in EXCLUDED_DIRS:
                surfaces.append(excluded_subtree_surface(child, root, EXCLUDED_DIRS[dirname]))
            else:
                kept_dirs.append(dirname)
            if len(surfaces) > max_surfaces:
                raise ValueError(f"manifest surface limit exceeded: {max_surfaces}")
        dirnames[:] = kept_dirs
        for filename in sorted(filenames):
            path = current / filename
            if filename in EXCLUDED_FILES:
                rel = normalized_rel(path, root)
                surfaces.append({
                    "id": surface_id(rel), "path": rel, "absolute_path": str(path.resolve(strict=False)),
                    "kind": "metadata", "adapter": "generic-file", "extension": path.suffix.lower(),
                    "magic": None, "handling": "excluded", "sensitive_path": False,
                    "rule_packs": ["gauntlet.core"], "exists": True, "size": path.stat().st_size,
                    "sha256": None, "mandatory": False, "coverage_method": "excluded", "state": "excluded",
                    "reason": EXCLUDED_FILES[filename], "evidence": [],
                })
            else:
                surfaces.append(build_surface(path, root, max_file_bytes))
            if len(surfaces) > max_surfaces:
                raise ValueError(f"manifest surface limit exceeded: {max_surfaces}")
    if len(surfaces) > max_surfaces:
        raise ValueError(f"manifest surface limit exceeded: {max_surfaces}")
    surfaces.sort(key=lambda item: item["path"])
    return root, surfaces, warnings


def run_git(root: Path, args: list[str], timeout: int = 30) -> bytes:
    command = ["git", "--no-optional-locks", "-c", "core.quotepath=false", "-C", str(root), *args]
    proc = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, check=False)
    if proc.returncode != 0:
        message = proc.stderr.decode("utf-8", "replace").strip() or "unknown Git error"
        raise ValueError(f"Git command failed ({' '.join(args)}): {message}")
    return proc.stdout


def find_git_root(target: Path) -> Path:
    start = target if target.is_dir() else target.parent
    output = run_git(start, ["rev-parse", "--show-toplevel"])
    return Path(os.fsdecode(output.strip())).resolve()


def git_tree_entry(root: Path, ref: str, rel: str) -> dict[str, str] | None:
    raw = run_git(root, ["ls-tree", "-z", ref, "--", rel])
    for record in raw.split(b"\0"):
        if not record or b"\t" not in record:
            continue
        metadata, raw_path = record.split(b"\t", 1)
        fields = metadata.split()
        decoded = raw_path.decode("utf-8", "surrogateescape")
        if decoded == rel and len(fields) >= 3:
            return {"mode": fields[0].decode("ascii"), "type": fields[1].decode("ascii"), "oid": fields[2].decode("ascii")}
    return None


def git_blob_oid(root: Path, ref: str, rel: str) -> str | None:
    entry = git_tree_entry(root, ref, rel)
    return entry["oid"] if entry and entry["type"] == "blob" else None


def read_git_blob(root: Path, ref: str, rel: str, expected_oid: str | None = None) -> tuple[bytes, str]:
    oid = git_blob_oid(root, ref, rel)
    if not oid:
        raise ValueError(f"git blob is unavailable for {rel} at {ref}")
    if expected_oid and oid != expected_oid:
        raise ValueError(f"git blob identity changed for {rel} at {ref}")
    return run_git(root, ["cat-file", "blob", oid]), oid


def parse_name_status_z(raw: bytes) -> list[dict[str, Any]]:
    tokens = [os.fsdecode(token) for token in raw.split(b"\0") if token]
    changes: list[dict[str, Any]] = []
    index = 0
    while index < len(tokens):
        status_token = tokens[index]
        index += 1
        code = status_token[0] if status_token else "?"
        if code in {"R", "C"}:
            if index + 1 >= len(tokens):
                raise ValueError("malformed Git rename/copy output")
            old_path, path = tokens[index], tokens[index + 1]
            index += 2
            changes.append({"status": code, "score": status_token[1:] or None, "old_path": old_path, "path": path})
        else:
            if index >= len(tokens):
                raise ValueError("malformed Git name-status output")
            path = tokens[index]
            index += 1
            changes.append({"status": code, "path": path})
    return changes


def git_workspace_changes(root: Path) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}
    commands = [
        ("unstaged", ["diff", "--name-status", "-z", "--find-renames"]),
        ("staged", ["diff", "--cached", "--name-status", "-z", "--find-renames"]),
    ]
    for source, args in commands:
        for change in parse_name_status_z(run_git(root, args)):
            item = merged.setdefault(change["path"], {**change, "sources": []})
            item["sources"].append(source)
            if change.get("old_path"):
                item["old_path"] = change["old_path"]
            item["status"] = change["status"]
    untracked = [os.fsdecode(token) for token in run_git(root, ["ls-files", "--others", "--exclude-standard", "-z"]).split(b"\0") if token]
    for path in untracked:
        merged[path] = {"status": "A", "path": path, "sources": ["untracked"]}
    return [merged[key] for key in sorted(merged)]


def verify_ref(root: Path, ref: str) -> str:
    return os.fsdecode(run_git(root, ["rev-parse", "--verify", "--end-of-options", f"{ref}^{{commit}}"]).strip())


def git_changes(root: Path, mode: str, ref: str | None, base: str | None, head: str | None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    head_sha = verify_ref(root, head or "HEAD")
    meta: dict[str, Any] = {"root": str(root), "mode": mode, "head": head_sha}
    if mode == "workspace":
        return git_workspace_changes(root), meta
    if mode == "commit":
        commit = verify_ref(root, ref or "HEAD")
        raw = run_git(root, ["diff-tree", "--root", "--no-commit-id", "--name-status", "-z", "-r", "--find-renames", commit])
        parent_row = os.fsdecode(run_git(root, ["rev-list", "--parents", "-n", "1", commit])).strip().split()
        meta["commit"] = commit
        meta["parent"] = parent_row[1] if len(parent_row) > 1 else None
        return parse_name_status_z(raw), meta
    if mode == "range":
        if not base:
            raise ValueError("range mode requires --base")
        base_sha = verify_ref(root, base)
        merge_base = os.fsdecode(run_git(root, ["merge-base", base_sha, head_sha]).strip())
        raw = run_git(root, ["diff", "--name-status", "-z", "--find-renames", merge_base, head_sha])
        meta.update({"base": base_sha, "merge_base": merge_base})
        return parse_name_status_z(raw), meta
    raise ValueError(f"unsupported Git mode: {mode}")


def inventory_git(target: Path, mode: str, ref: str | None, base: str | None, head: str | None, max_file_bytes: int, max_surfaces: int = DEFAULT_MAX_SURFACES) -> tuple[Path, list[dict[str, Any]], list[str], dict[str, Any]]:
    root = find_git_root(target)
    changes, git_meta = git_changes(root, mode, ref, base, head)
    target_resolved = target.resolve(strict=False)
    scope_prefix = ""
    if target_resolved != root:
        try:
            scope_prefix = target_resolved.relative_to(root).as_posix().rstrip("/") + "/"
        except ValueError as exc:
            raise ValueError("target is outside its reported Git root") from exc
        scoped_changes: list[dict[str, Any]] = []
        scope_root = scope_prefix.rstrip("/")
        for change in changes:
            path_in_scope = change["path"] == scope_root or change["path"].startswith(scope_prefix)
            old_path = change.get("old_path")
            old_in_scope = bool(old_path and (old_path == scope_root or old_path.startswith(scope_prefix)))
            if path_in_scope:
                scoped_changes.append(change)
            elif old_in_scope and change.get("status") == "R":
                scoped_changes.append({
                    "status": "D", "path": old_path, "renamed_to": change["path"],
                    "original_status": change["status"], "sources": change.get("sources", []),
                })
        changes = scoped_changes
    if len(changes) > max_surfaces:
        raise ValueError(f"manifest surface limit exceeded: {max_surfaces}")
    surfaces: list[dict[str, Any]] = []
    warnings: list[str] = []
    for change in changes:
        rel = change["path"]
        candidate = ensure_within(root / rel, root)
        if mode == "workspace" and change.get("status") != "D":
            surface = build_surface(candidate, root, max_file_bytes, change=change)
            surface["content_source"] = "working_tree"
        else:
            surface = build_git_blob_surface(root, change, git_meta, max_file_bytes)
        surfaces.append(surface)
    if not surfaces:
        warnings.append("selected Git scope contains no changed files")
    surfaces.sort(key=lambda item: item["path"])
    return root, surfaces, warnings, git_meta


def target_fingerprint(target: dict[str, Any], surfaces: list[dict[str, Any]], git_meta: dict[str, Any] | None) -> str:
    """Fingerprint target identity and bytes, never mutable review state."""
    rows = [
        f"{s['path']}\0{s.get('sha256') or ''}\0{s.get('size') if s.get('size') is not None else ''}\0{s.get('file_mode') or s.get('git_mode') or ''}\0{json.dumps(s.get('change', {}), sort_keys=True)}"
        for s in sorted(surfaces, key=lambda item: item["path"])
    ]
    return hashlib.sha256((json.dumps(target, sort_keys=True) + json.dumps(git_meta or {}, sort_keys=True) + "\n".join(rows)).encode("utf-8", "surrogateescape")).hexdigest()


def pack_ids_for_surfaces(surfaces: Iterable[dict[str, Any]]) -> list[str]:
    packs = {"gauntlet.core"}
    for surface in surfaces:
        packs.update(surface.get("rule_packs", []))
    return sorted(packs)


def derive_manifest_status(surfaces: list[dict[str, Any]], checks: list[dict[str, Any]]) -> str:
    mandatory = [surface for surface in surfaces if surface.get("mandatory", True)]
    required = [check for check in checks if check.get("required", False)]
    if any(surface["state"] == "failed" for surface in mandatory) or any(check.get("execution_status") == "failed" or (check.get("result") == "fails" and check.get("blocking")) for check in required):
        return "failed"
    if any(surface["state"] == "pending" for surface in mandatory) or any(check.get("execution_status") == "pending" for check in required):
        return "in_progress"
    if any(surface["state"] in {"excluded", "cannot_verify"} for surface in mandatory) or any(check.get("execution_status") in {"could_not_run", "skipped"} or check.get("result") in {"unknown", "candidates", "fails"} for check in required):
        return "partial"
    return "complete"


def manifest_stats(surfaces: list[dict[str, Any]], checks: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    states = Counter(surface["state"] for surface in surfaces)
    mandatory = Counter(surface["state"] for surface in surfaces if surface.get("mandatory", True))
    check_exec = Counter(check.get("execution_status", "pending") for check in checks or [])
    return {
        "surfaces_total": len(surfaces),
        "surface_states": dict(sorted(states.items())),
        "mandatory_surface_states": dict(sorted(mandatory.items())),
        "checks_total": len(checks or []),
        "check_execution_states": dict(sorted(check_exec.items())),
    }


def build_manifest(target: Path, mode: str, track: str, evidence_ceiling: str, max_file_bytes: int, ref: str | None, base: str | None, head: str | None, max_surfaces: int = DEFAULT_MAX_SURFACES) -> dict[str, Any]:
    if max_file_bytes <= 0:
        raise ValueError("max_file_bytes must be positive")
    if max_surfaces <= 0:
        raise ValueError("max_surfaces must be positive")
    # Keep the lexical designation so a submitted symlink is inventoried as a
    # symlink rather than silently followed. The resolved destination is recorded
    # separately for identity and reviewer inspection.
    target = Path(os.path.abspath(os.path.expanduser(os.fspath(target))))
    if mode == "auto":
        try:
            git_root = find_git_root(target)
            workspace = git_workspace_changes(git_root)
            mode = "workspace" if workspace else "full"
        except ValueError:
            mode = "full"
    git_meta: dict[str, Any] | None = None
    if mode in {"workspace", "commit", "range"}:
        root, surfaces, warnings, git_meta = inventory_git(target, mode, ref, base, head, max_file_bytes, max_surfaces)
    elif mode == "full":
        root, surfaces, warnings = inventory_full(target, max_file_bytes, max_surfaces)
    else:
        raise ValueError(f"unsupported mode: {mode}")

    target_kind = "symlink" if target.is_symlink() else "file" if target.is_file() else "directory" if target.is_dir() else "missing"
    target_data = {
        "designated_path": str(target), "resolved_path": str(target.resolve(strict=False)),
        "root": str(root), "kind": target_kind,
    }
    fingerprint = target_fingerprint(target_data, surfaces, git_meta)
    run_id = "GNT-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    checks = [
        {
            "id": "CHK-MANIFEST-INVENTORY", "kind": "manifest_integrity", "required": True,
            "blocking": True, "execution_status": "completed", "result": "holds",
            "scope": f"{len(surfaces)} manifest surfaces", "evidence": ["engine:manifest"],
            "started_at": utc_now(), "completed_at": utc_now(),
        },
        {
            "id": "CHK-FINDINGS-VERIFIER", "kind": "finding_verifier", "required": True,
            "blocking": True, "execution_status": "pending", "result": "unknown",
            "scope": "candidate findings ledger", "evidence": [], "reason": None,
            "started_at": None, "completed_at": None,
        },
    ]
    manifest = {
        "$schema": "https://miancore.local/gauntlet/review-manifest-schema.json",
        "schema_version": SCHEMA_VERSION,
        "engine_version": ENGINE_VERSION,
        "run_id": run_id,
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "status": "planned",
        "mode": mode,
        "track": track,
        "evidence_ceiling": evidence_ceiling,
        "target": {**target_data, "fingerprint": fingerprint},
        "git": git_meta,
        "adapters": sorted({surface["adapter"] for surface in surfaces}),
        "rule_packs": pack_ids_for_surfaces(surfaces),
        "surfaces": surfaces,
        "exclusions": [
            {"surface_id": s["id"], "path": s["path"], "reason": s.get("reason"), "covers_subtree": s.get("covers_subtree", False)}
            for s in surfaces if s["state"] == "excluded"
        ],
        "checks": checks,
        "warnings": warnings,
        "sampling": {"method": "exhaustive_inventory", "sampled": False, "declaration": "Every selected file or explicit excluded subtree is represented in the manifest.", "max_file_bytes": max_file_bytes, "max_surfaces": max_surfaces},
        "budgets": {"time_seconds": None, "tokens": None, "cost": None, "max_workers": 1},
        "checkpoint": {"compatible_fingerprint": fingerprint, "completed_units": []},
    }
    manifest["stats"] = manifest_stats(surfaces, checks)
    validate_manifest(manifest)
    return manifest


def sanitize_url(value: str) -> str:
    """Retain useful URL location evidence without credentials or query values."""
    protocol_relative = value.startswith("//")
    candidate = "https:" + value if protocol_relative else value
    try:
        parsed = urlsplit(candidate)
        if parsed.scheme in {"http", "https"}:
            host = parsed.hostname or ""
            try:
                port = parsed.port
            except ValueError:
                return "invalid-url"
            netloc = f"{host}:{port}" if port is not None else host
            segments = []
            for segment in parsed.path.split("/"):
                opaque = len(segment) >= 24 and bool(re.fullmatch(r"[A-Za-z0-9._~+=-]+", segment))
                segments.append("[redacted]" if len(segment) > 64 or opaque else segment)
            safe = urlunsplit(("" if protocol_relative else parsed.scheme, netloc, "/".join(segments), "", ""))
            return "//" + safe.lstrip("/") if protocol_relative else safe
    except ValueError:
        return "invalid-url"
    return value.split("?", 1)[0].split("#", 1)[0][:180]


def sanitize_evidence_label(value: Any, max_length: int = 180) -> str:
    text = re.sub(r"[\x00-\x1f\x7f]", "�", str(value))
    secret = bool(detected_secret_ids(text))
    opaque = bool(
        re.fullmatch(r"[0-9a-fA-F]{24,}", text)
        or re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", text)
        or (len(text) >= 32 and re.fullmatch(r"[A-Za-z0-9]+", text) and re.search(r"[A-Za-z]", text) and re.search(r"\d", text))
    )
    if secret or opaque:
        return f"[redacted-{short_hash(text, length=10)}]"
    return text[:max_length] + ("…" if len(text) > max_length else "")


def sanitize_evidence_path(value: Any) -> str:
    text = str(value)
    if detected_secret_ids(text):
        return f"[redacted-path-{short_hash(text, length=10)}]"
    parts = re.split(r"([/\\])", text)
    return "".join(part if part in {"/", "\\"} else sanitize_evidence_label(part, 120) for part in parts)


def receipt_base(adapter: str, path: Path, limitations: list[str]) -> dict[str, Any]:
    return {
        "$schema": "https://miancore.local/gauntlet/check-receipt-schema.json",
        "schema_version": SCHEMA_VERSION,
        "adapter": adapter,
        "adapter_version": ENGINE_VERSION,
        "path": sanitize_evidence_path(path.expanduser().resolve(strict=False)),
        "artifact": {"sha256": None, "size": None},
        "started_at": utc_now(),
        "execution_status": "completed",
        "result": "unknown",
        "issues": [],
        "inventory": {},
        "limitations": limitations,
    }


def bind_receipt(result: dict[str, Any], path: Path, max_bytes: int | None = None) -> None:
    stat = path.stat()
    if not path.is_file():
        raise ValueError("adapter target is not a regular file")
    if max_bytes is not None and stat.st_size > max_bytes:
        raise ValueError(f"adapter size limit exceeded: {stat.st_size} > {max_bytes}")
    result["artifact"] = {"sha256": sha256_file(path), "size": stat.st_size}


class StaticHTMLInspector(html.parser.HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: list[tuple[str, int]] = []
        self.labels_for: set[str] = set()
        self.controls: list[dict[str, Any]] = []
        self.external_resources: list[dict[str, Any]] = []
        self.inline_events: list[dict[str, Any]] = []
        self.forms: list[dict[str, Any]] = []
        self.module_scripts: list[int] = []
        self.tags = Counter()
        self.label_depth = 0
        self.open_buttons: list[int] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.tags[tag] += 1
        data = {key.lower(): value or "" for key, value in attrs}
        line, _ = self.getpos()
        if tag == "label":
            self.label_depth += 1
        if data.get("id"):
            self.ids.append((data["id"], line))
        if tag == "label" and data.get("for"):
            self.labels_for.add(data["for"])
        if tag in {"input", "select", "textarea", "button"}:
            self.controls.append({
                "tag": tag, "line": line, "id": data.get("id"), "type": data.get("type"),
                "has_name": bool(data.get("aria-label") or data.get("aria-labelledby") or data.get("title")),
                "implicit_label": self.label_depth > 0, "has_text": False,
            })
            if tag == "button":
                self.open_buttons.append(len(self.controls) - 1)
        for attr, kind in (("src", "resource"), ("href", "link"), ("action", "form_action")):
            value = data.get(attr, "")
            if value.startswith(("http://", "https://", "//")):
                self.external_resources.append({"tag": tag, "kind": kind, "line": line, "url": sanitize_url(value)})
        for name in data:
            if name.startswith("on"):
                self.inline_events.append({"tag": tag, "event": name, "line": line})
        if tag == "form":
            self.forms.append({"line": line, "method": (data.get("method") or "get").lower(), "action": sanitize_url(data.get("action", ""))})
        if tag == "script" and data.get("type", "").lower() == "module":
            self.module_scripts.append(line)

    def handle_endtag(self, tag: str) -> None:
        if tag == "label" and self.label_depth:
            self.label_depth -= 1
        if tag == "button" and self.open_buttons:
            self.open_buttons.pop()

    def handle_data(self, data: str) -> None:
        if self.open_buttons and data.strip():
            self.controls[self.open_buttons[-1]]["has_text"] = True


def inspect_html(path: Path) -> dict[str, Any]:
    path = path.expanduser().resolve(strict=False)
    result = receipt_base(
        "html", path,
        ["static inspection only; runtime, layout, network, file-protocol, and interaction behavior remain unverified"],
    )
    try:
        bind_receipt(result, path, MAX_STATIC_TEXT_BYTES)
        text = read_text_local(path)
        parser = StaticHTMLInspector()
        parser.feed(text)
    except Exception as exc:
        receipt_exception(result, exc)
        result["completed_at"] = utc_now()
        return result
    id_counts = Counter(value for value, _ in parser.ids)
    for value, count in id_counts.items():
        if count > 1:
            result["issues"].append({"rule_id": "HTML-A11Y", "detector_id": "HTML-DUPLICATE-ID", "kind": "duplicate_id", "count": count, "id": sanitize_evidence_label(value)})
    for control in parser.controls:
        if control["tag"] == "input" and (control.get("type") or "text").lower() == "hidden":
            continue
        named_by_label = bool(control.get("id") and control["id"] in parser.labels_for)
        unnamed = not control["has_name"] and not control.get("implicit_label") and not named_by_label
        if unnamed and (control["tag"] != "button" or not control.get("has_text")):
            result["issues"].append({"rule_id": "HTML-A11Y", "detector_id": "HTML-CONTROL-NAME", "kind": "potential_unlabeled_control", "tag": control["tag"], "line": control["line"]})
    for item in parser.external_resources:
        result["issues"].append({"rule_id": "HTML-OFFLINE", "detector_id": "HTML-EXTERNAL-RESOURCE", "kind": "external_resource", **item})
    if parser.inline_events:
        result["issues"].append({"rule_id": "HTML-RUNTIME", "detector_id": "HTML-INLINE-EVENTS", "kind": "inline_event_handlers", "count": len(parser.inline_events), "locations": parser.inline_events[:50]})
    if parser.module_scripts:
        result["issues"].append({"rule_id": "HTML-OFFLINE", "detector_id": "HTML-FILE-MODULE", "kind": "module_script_file_protocol_risk", "lines": parser.module_scripts})
    for pattern_id, pattern in [*SECRET_PATTERNS, *SLOP_PATTERNS]:
        matches = secret_matches(pattern, text) if pattern_id.startswith("SECRET-") else list(pattern.finditer(text))
        lines = [text.count("\n", 0, match.start()) + 1 for match in matches]
        if lines:
            result["issues"].append({
                "rule_id": "CORE-SECRET" if pattern_id.startswith("SECRET-") else "SLOP-LEFTOVER",
                "detector_id": pattern_id,
                "kind": "secret_candidate" if pattern_id.startswith("SECRET-") else "slop_signal",
                "count": len(lines), "lines": lines[:100], "values_redacted": True,
            })
    sink_lines = [text.count("\n", 0, match.start()) + 1 for match in re.finditer(r"(?:\.innerHTML\s*=|\bdocument\.write\s*\()", text)]
    if sink_lines:
        result["issues"].append({"rule_id": "HTML-INJECTION", "kind": "dynamic_html_sink", "count": len(sink_lines), "lines": sink_lines[:100]})
    fetch_lines = [text.count("\n", 0, match.start()) + 1 for match in re.finditer(r"\bfetch\s*\(", text)]
    if fetch_lines:
        result["issues"].append({"rule_id": "HTML-OFFLINE", "detector_id": "HTML-FETCH-FILE", "kind": "file_protocol_fetch_risk", "lines": fetch_lines})
    result["inventory"] = {
        "bytes": len(text.encode("utf-8")), "tags": dict(sorted(parser.tags.items())),
        "controls": len(parser.controls), "forms": len(parser.forms),
        "external_resources": len(parser.external_resources), "ids": len(parser.ids),
    }
    result.update({"result": "candidates" if result["issues"] else "holds", "completed_at": utc_now()})
    return result


def analyze_zip(archive: zipfile.ZipFile) -> tuple[dict[str, Any], list[dict[str, Any]], list[str]]:
    """Inventory a ZIP container without extracting it and enforce parser budgets."""
    infos = archive.infolist()
    total_size = sum(info.file_size for info in infos)
    limit_errors: list[str] = []
    if len(infos) > MAX_ZIP_ENTRIES:
        limit_errors.append(f"entry_count={len(infos)}")
    if total_size > MAX_ZIP_TOTAL_BYTES:
        limit_errors.append(f"uncompressed_bytes={total_size}")
    issues: list[dict[str, Any]] = []
    names = Counter(info.filename for info in infos)
    duplicates = sorted(name for name, count in names.items() if count > 1)
    if duplicates:
        issues.append({"rule_id": "BIN-STRUCTURE", "kind": "duplicate_archive_paths", "count": len(duplicates), "paths": [sanitize_evidence_path(name) for name in duplicates[:100]]})
    traversal: list[str] = []
    links: list[str] = []
    encrypted: list[str] = []
    special: list[str] = []
    for info in infos:
        name = info.filename
        normalized = name.replace("\\", "/")
        parts = [part for part in normalized.split("/") if part not in {"", "."}]
        if normalized.startswith("/") or re.match(r"^[A-Za-z]:/", normalized) or ".." in parts or "\x00" in name:
            traversal.append(name)
        mode = (info.external_attr >> 16) & 0xFFFF
        file_type = mode & 0o170000
        if file_type == 0o120000:
            links.append(name)
        elif file_type not in {0, 0o040000, 0o100000}:
            special.append(name)
        if info.flag_bits & 0x1:
            encrypted.append(name)
        ratio = info.file_size / max(info.compress_size, 1)
        if info.file_size > MAX_ZIP_ENTRY_BYTES:
            limit_errors.append(f"entry_too_large:{sanitize_evidence_path(name)}:{info.file_size}")
        if info.file_size > 1024 * 1024 and ratio > MAX_ZIP_RATIO:
            limit_errors.append(f"compression_ratio:{sanitize_evidence_path(name)}:{ratio:.1f}")
    if traversal:
        issues.append({"rule_id": "BIN-CONTAIN", "kind": "archive_path_escape", "count": len(traversal), "paths": [sanitize_evidence_path(name) for name in traversal[:100]]})
    if links or special:
        issues.append({"rule_id": "BIN-CONTAIN", "kind": "archive_link_or_special_entry", "count": len(links) + len(special), "links": [sanitize_evidence_path(name) for name in links[:100]], "special": [sanitize_evidence_path(name) for name in special[:100]]})
    if encrypted:
        issues.append({"rule_id": "BIN-STRUCTURE", "kind": "encrypted_entries", "count": len(encrypted), "paths": [sanitize_evidence_path(name) for name in encrypted[:100]]})
    inventory = {
        "archive_entries": len(infos),
        "uncompressed_bytes": total_size,
        "compressed_bytes": sum(info.compress_size for info in infos),
        "encrypted_entries": len(encrypted),
        "link_entries": len(links),
        "special_entries": len(special),
    }
    return inventory, issues, sorted(set(limit_errors))


def receipt_exception(result: dict[str, Any], exc: Exception) -> None:
    size_limited = isinstance(exc, ValueError) and "size limit" in str(exc)
    execution = "could_not_run" if size_limited else "failed"
    if size_limited:
        message = str(exc)
    else:
        message = f"{type(exc).__name__}: adapter exception [{short_hash(type(exc).__name__, str(exc), length=12)}]"
    result.update({"execution_status": execution, "result": "unknown", "error": message})


def enforce_zip_limits(archive: zipfile.ZipFile) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    inventory, issues, limit_errors = analyze_zip(archive)
    if limit_errors:
        raise ValueError("archive safety limit exceeded: " + ", ".join(limit_errors[:20]))
    return inventory, issues


def xml_root(archive: zipfile.ZipFile, name: str) -> ET.Element | None:
    try:
        return ET.fromstring(archive.read(name))
    except KeyError:
        return None
    except ET.ParseError:
        return None


def inspect_xlsx(path: Path) -> dict[str, Any]:
    result: dict[str, Any] = {"format": path.suffix.lower().lstrip("."), "sheets": [], "issues": [], "inventory": {}}
    with zipfile.ZipFile(path) as archive:
        zip_inventory, archive_issues = enforce_zip_limits(archive)
        result["issues"].extend(archive_issues)
        names = set(archive.namelist())
        workbook = xml_root(archive, "xl/workbook.xml")
        rels = xml_root(archive, "xl/_rels/workbook.xml.rels")
        rel_map: dict[str, str] = {}
        sheet_source_paths: list[str] = []
        if rels is not None:
            for rel in rels.findall("{*}Relationship"):
                rel_map[rel.attrib.get("Id", "")] = rel.attrib.get("Target", "")
        if workbook is not None:
            calc = workbook.find("{*}calcPr")
            if calc is not None and calc.attrib.get("calcMode") == "manual":
                result["issues"].append({"rule_id": "SHEET-CALC", "detector_id": "SHEET-MANUAL-CALC", "kind": "manual_calculation_mode"})
            for sheet in workbook.findall(".//{*}sheet"):
                rel_id = next((v for k, v in sheet.attrib.items() if k.endswith("}id")), "")
                target = rel_map.get(rel_id, "")
                if target.startswith("/"):
                    sheet_path = target.lstrip("/")
                else:
                    sheet_path = "xl/" + target.lstrip("/") if target else ""
                info = {"name": sanitize_evidence_label(sheet.attrib.get("name", "")), "state": sheet.attrib.get("state", "visible"), "path": sanitize_evidence_path(sheet_path)}
                result["sheets"].append(info)
                sheet_source_paths.append(sheet_path)
                if info["state"] != "visible":
                    result["issues"].append({"rule_id": "SHEET-HIDDEN", "detector_id": "SHEET-HIDDEN-SHEET", "kind": "hidden_sheet", "sheet": info["name"], "state": info["state"]})
        formula_count = 0
        error_cells: list[dict[str, str]] = []
        external_formula_cells: list[dict[str, str]] = []
        formula_cells: list[dict[str, str]] = []
        raw_formulas: list[dict[str, str]] = []
        sheet_cell_refs: dict[str, set[str]] = {}
        formula_gaps: list[dict[str, str]] = []
        sheet_metrics: list[dict[str, Any]] = []
        cell_ref_pattern = re.compile(r"^([A-Z]{1,3})([1-9][0-9]*)$")
        for sheet, source_path in zip(result["sheets"], sheet_source_paths):
            if not source_path or source_path not in names:
                continue
            root = xml_root(archive, source_path)
            if root is None:
                continue
            cells = root.findall(".//{*}c")
            formulas = root.findall(".//{*}f")
            formula_count += len(formulas)
            populated: set[str] = set()
            formulas_by_column: dict[str, set[int]] = defaultdict(set)
            for cell in cells:
                ref = cell.attrib.get("r", "")
                match = cell_ref_pattern.fullmatch(ref)
                formula = cell.find("{*}f")
                value = cell.find("{*}v")
                inline = cell.find(".//{*}t")
                if match and (formula is not None or value is not None or inline is not None):
                    populated.add(ref)
                if cell.attrib.get("t") == "e":
                    error_cells.append({"sheet": sheet["name"], "cell": ref})
                if formula is not None and formula.text:
                    formula_text = formula.text
                    if match:
                        formulas_by_column[match.group(1)].add(int(match.group(2)))
                    safe_formula = f"[redacted-formula-{short_hash(formula_text, length=10)}]" if detected_secret_ids(formula_text) else sanitize_evidence_label(formula_text, 500)
                    formula_cells.append({"sheet": sheet["name"], "cell": ref, "formula": safe_formula})
                    raw_formulas.append({"sheet": sheet["name"], "cell": ref, "formula": formula_text})
                    if "[" in formula_text:
                        external_formula_cells.append({"sheet": sheet["name"], "cell": ref})
            sheet_cell_refs[sheet["name"]] = populated
            for column, rows in formulas_by_column.items():
                if len(rows) < 2:
                    continue
                for row in range(min(rows) + 1, max(rows)):
                    ref = f"{column}{row}"
                    if ref in populated and row not in rows:
                        formula_gaps.append({"sheet": sheet["name"], "cell": ref})
            sheet_metrics.append({"sheet": sheet["name"], "cells": len(cells), "formulas": len(formulas), "merged_ranges": len(root.findall(".//{*}mergeCell"))})
        omitted_adjacent_cells: list[dict[str, str]] = []
        hidden_dependencies: list[dict[str, str]] = []
        range_pattern = re.compile(r"(?:(?:'([^']+)'|([A-Za-z_][A-Za-z0-9_ ]*))!)?\$?([A-Z]{1,3})\$?([1-9][0-9]*):\$?([A-Z]{1,3})\$?([1-9][0-9]*)")
        hidden_names = {sheet["name"] for sheet in result["sheets"] if sheet["state"] != "visible"}
        for record in raw_formulas:
            formula_text = record["formula"]
            for hidden_name in hidden_names:
                if re.search(rf"(?<![A-Za-z0-9_\]])(?:'{re.escape(hidden_name)}'|{re.escape(hidden_name)})!", formula_text, re.I):
                    hidden_dependencies.append({"sheet": record["sheet"], "cell": record["cell"], "hidden_sheet": hidden_name})
            for match in range_pattern.finditer(formula_text):
                referenced_sheet = (match.group(1) or match.group(2) or record["sheet"]).strip()
                start_column, start_row, end_column, end_row = match.group(3), int(match.group(4)), match.group(5), int(match.group(6))
                if start_column != end_column or end_row < start_row:
                    continue
                adjacent = f"{end_column}{end_row + 1}"
                if adjacent in sheet_cell_refs.get(referenced_sheet, set()):
                    omitted_adjacent_cells.append({
                        "formula_sheet": record["sheet"], "formula_cell": record["cell"],
                        "range": f"{referenced_sheet}!{start_column}{start_row}:{end_column}{end_row}",
                        "adjacent_populated_cell": f"{referenced_sheet}!{adjacent}",
                    })
        if error_cells:
            result["issues"].append({"rule_id": "SHEET-TYPE", "detector_id": "SHEET-ERROR-CELL", "kind": "formula_error_cells", "count": len(error_cells), "locations": error_cells[:100]})
        if formula_gaps:
            result["issues"].append({"rule_id": "SHEET-FORMULA", "detector_id": "SHEET-FORMULA-GAP", "kind": "hardcoded_cells_inside_formula_region", "count": len(formula_gaps), "locations": formula_gaps[:100]})
        if omitted_adjacent_cells:
            result["issues"].append({"rule_id": "SHEET-RANGE", "detector_id": "SHEET-RANGE-ADJACENT", "kind": "formula_range_omits_adjacent_populated_cell", "count": len(omitted_adjacent_cells), "locations": omitted_adjacent_cells[:100]})
        if hidden_dependencies:
            result["issues"].append({"rule_id": "SHEET-HIDDEN", "detector_id": "SHEET-HIDDEN-DEPENDENCY", "kind": "visible_formula_references_hidden_sheet", "count": len(hidden_dependencies), "locations": hidden_dependencies[:100]})
        if external_formula_cells:
            result["issues"].append({"rule_id": "SHEET-EXTERNAL", "detector_id": "SHEET-EXTERNAL-FORMULA", "kind": "external_formula_references", "count": len(external_formula_cells), "locations": external_formula_cells[:100]})
        if any(name.startswith("xl/externalLinks/") for name in names):
            result["issues"].append({"rule_id": "SHEET-EXTERNAL", "detector_id": "SHEET-EXTERNAL-LINK", "kind": "external_link_parts"})
        if "xl/vbaProject.bin" in names:
            macro_info = archive.getinfo("xl/vbaProject.bin")
            macro_sha256 = hashlib.sha256(archive.read("xl/vbaProject.bin")).hexdigest()
            result["issues"].append({"rule_id": "SHEET-STRUCTURE", "detector_id": "SHEET-MACRO", "kind": "embedded_vba", "sha256": macro_sha256, "size": macro_info.file_size})
        defined_names = []
        if workbook is not None:
            for item in workbook.findall(".//{*}definedName"):
                defined_names.append({"name": sanitize_evidence_label(item.attrib.get("name", "")), "hidden": item.attrib.get("hidden") == "1", "has_external_reference": bool(item.text and "[" in item.text)})
        result["inventory"] = {
            **zip_inventory, "sheet_count": len(result["sheets"]),
            "formula_count": formula_count, "formula_cells": formula_cells[:1000], "sheet_metrics": sheet_metrics,
            "defined_names": defined_names, "has_macros": "xl/vbaProject.bin" in names,
            "has_external_links": any(name.startswith("xl/externalLinks/") for name in names),
        }
    return result


def inspect_ods(path: Path) -> dict[str, Any]:
    result: dict[str, Any] = {"format": "ods", "sheets": [], "issues": [], "inventory": {}}
    with zipfile.ZipFile(path) as archive:
        zip_inventory, archive_issues = enforce_zip_limits(archive)
        result["issues"].extend(archive_issues)
        root = xml_root(archive, "content.xml")
        if root is None:
            raise ValueError("content.xml missing or invalid")
        formula_count = 0
        external_links = 0
        for table in root.findall(".//{*}table"):
            name = next((v for k, v in table.attrib.items() if k.endswith("}name")), "")
            visibility = next((v for k, v in table.attrib.items() if k.endswith("}visibility")), "visible")
            safe_name = sanitize_evidence_label(name)
            result["sheets"].append({"name": safe_name, "state": visibility})
            if visibility not in {"visible", ""}:
                result["issues"].append({"rule_id": "SHEET-HIDDEN", "detector_id": "SHEET-HIDDEN-SHEET", "kind": "hidden_sheet", "sheet": safe_name, "state": visibility})
        for element in root.iter():
            for key, value in element.attrib.items():
                if key.endswith("}formula"):
                    formula_count += 1
                    if "[" in value or "http:" in value or "https:" in value:
                        external_links += 1
                if key.endswith("}href") and value.startswith(("http://", "https://", "file://")):
                    external_links += 1
        if external_links:
            result["issues"].append({"rule_id": "SHEET-EXTERNAL", "detector_id": "SHEET-EXTERNAL-LINK", "kind": "external_references", "count": external_links})
        result["inventory"] = {**zip_inventory, "sheet_count": len(result["sheets"]), "formula_count": formula_count, "external_reference_count": external_links}
    return result


def delimited_formula_candidate(value: str) -> bool:
    value = value.lstrip()
    if not value or value[0] not in "=+-@":
        return False
    if value[0] in "+-" and re.fullmatch(r"[+-](?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", value):
        return False
    return True


def inspect_delimited(path: Path) -> dict[str, Any]:
    delimiter = "\t" if path.suffix.lower() == ".tsv" else ","
    rows = 0
    widths = Counter()
    formula_rows: list[int] = []
    with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as handle:
        sample = handle.read(8192)
        handle.seek(0)
        if path.suffix.lower() != ".tsv":
            try:
                delimiter = csv.Sniffer().sniff(sample, delimiters=",;|\t").delimiter
            except csv.Error:
                delimiter = ","
        reader = csv.reader(handle, delimiter=delimiter)
        for row_number, row in enumerate(reader, 1):
            rows += 1
            widths[len(row)] += 1
            if any(delimited_formula_candidate(cell) for cell in row):
                formula_rows.append(row_number)
    issues: list[dict[str, Any]] = []
    if len(widths) > 1:
        issues.append({"rule_id": "SHEET-STRUCTURE", "detector_id": "SHEET-RAGGED-ROWS", "kind": "inconsistent_column_count", "widths": dict(widths)})
    if formula_rows:
        issues.append({"rule_id": "SHEET-TYPE", "detector_id": "SHEET-FORMULA-CELLS", "kind": "formula_or_csv_injection_candidates", "count": len(formula_rows), "rows": formula_rows[:100]})
    return {"format": path.suffix.lower().lstrip("."), "sheets": [{"name": path.name, "state": "visible"}], "issues": issues, "inventory": {"rows": rows, "column_widths": dict(widths), "delimiter": "TAB" if delimiter == "\t" else delimiter}}


def inspect_workbook(path: Path) -> dict[str, Any]:
    path = path.expanduser().resolve(strict=False)
    result = receipt_base(
        "workbook", path,
        ["structural inspection only; semantic business correctness and recalculation remain separate checks"],
    )
    try:
        bind_receipt(result, path, 100 * 1024 * 1024)
        suffix = path.suffix.lower()
        if suffix in {".xlsx", ".xlsm"}:
            detail = inspect_xlsx(path)
        elif suffix == ".ods":
            detail = inspect_ods(path)
        elif suffix in {".csv", ".tsv"}:
            detail = inspect_delimited(path)
        elif suffix == ".xls":
            result.update({"execution_status": "could_not_run", "result": "unknown", "error": "legacy .xls requires a dedicated parser", "completed_at": utc_now()})
            return result
        else:
            raise ValueError(f"unsupported workbook format: {suffix or 'none'}")
        result.update(detail)
        result["result"] = "candidates" if result["issues"] else "holds"
    except Exception as exc:
        receipt_exception(result, exc)
    result["completed_at"] = utc_now()
    return result


def inspect_archive_binary(path: Path) -> dict[str, Any]:
    """Safely inventory ZIP containers and identify other binaries without execution."""
    path = path.expanduser().resolve(strict=False)
    result = receipt_base(
        "archive_binary", path,
        ["no archive content was executed or extracted; non-ZIP formats require a dedicated parser for deep integrity claims"],
    )
    try:
        bind_receipt(result, path, 512 * 1024 * 1024)
        suffix = path.suffix.lower()
        result["inventory"] = {"extension": suffix, "magic": magic_kind(path)}
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as archive:
                inventory, issues = enforce_zip_limits(archive)
                result["inventory"].update(inventory)
                result["issues"].extend(issues)
                names = archive.namelist()
                active_suffixes = {".app", ".bat", ".cmd", ".com", ".dll", ".dylib", ".exe", ".jar", ".js", ".msi", ".ps1", ".py", ".scr", ".sh", ".so"}
                nested_suffixes = ARCHIVE_EXTENSIONS | {".apk", ".ipa", ".whl"}
                active = [name for name in names if Path(name).suffix.lower() in active_suffixes]
                nested = [name for name in names if Path(name).suffix.lower() in nested_suffixes]
                if active:
                    result["issues"].append({"rule_id": "BIN-ACTIVE", "kind": "active_archive_entries", "count": len(active), "paths": [sanitize_evidence_path(name) for name in active[:100]]})
                if nested:
                    result["issues"].append({"rule_id": "BIN-STRUCTURE", "kind": "nested_archives", "count": len(nested), "paths": [sanitize_evidence_path(name) for name in nested[:100]]})
                bad_entry = None
                if not inventory["encrypted_entries"]:
                    bad_entry = archive.testzip()
                    if bad_entry:
                        result["issues"].append({"rule_id": "BIN-STRUCTURE", "kind": "crc_failure", "path": bad_entry})
                result["inventory"].update({"active_entries": len(active), "nested_archives": len(nested), "crc_checked": not bool(inventory["encrypted_entries"])})
        elif suffix in {".zip", ".docx", ".xlsx", ".xlsm", ".ods", ".epub"}:
            result["issues"].append({"rule_id": "BIN-STRUCTURE", "kind": "claimed_zip_container_is_invalid"})
        else:
            result["limitations"].append(f"{suffix or 'unknown'} structure was not parsed by the standard-library baseline")
        result["result"] = "candidates" if result["issues"] else "holds"
    except Exception as exc:
        receipt_exception(result, exc)
    result["completed_at"] = utc_now()
    return result


def inspect_document(path: Path) -> dict[str, Any]:
    """Inspect PDF, OOXML/EPUB ZIP, and RTF structure without rendering or execution."""
    path = path.expanduser().resolve(strict=False)
    result = receipt_base(
        "document", path,
        ["structural inspection only; visual rendering, reading order, claim accuracy, signatures, and assistive use remain separate checks"],
    )
    try:
        bind_receipt(result, path, 100 * 1024 * 1024)
        suffix = path.suffix.lower()
        if suffix == ".pdf" or magic_kind(path) == "pdf":
            data = path.read_bytes()
            if not data.startswith(b"%PDF-") or b"%%EOF" not in data[-4096:]:
                result["issues"].append({"rule_id": "DOC-STRUCTURE", "kind": "invalid_or_truncated_pdf_markers"})
            active_tokens = {
                "javascript": (b"/JavaScript", b"/JS"), "open_action": (b"/OpenAction",),
                "launch_action": (b"/Launch",), "embedded_files": (b"/EmbeddedFile",),
            }
            active = {name: sum(data.count(token) for token in tokens) for name, tokens in active_tokens.items()}
            for name, count in active.items():
                if count:
                    result["issues"].append({"rule_id": "DOC-SECURITY", "kind": name, "count": count})
            result["inventory"] = {
                "format": "pdf", "version": data[5:12].decode("ascii", "replace").splitlines()[0],
                "page_markers": len(re.findall(rb"/Type\s*/Page\b", data)),
                "encrypted": b"/Encrypt" in data, "forms": data.count(b"/AcroForm"),
                "structure_tree_present": b"/StructTreeRoot" in data,
                "language_present": b"/Lang" in data, "uri_markers": data.count(b"/URI"),
                "active_content": active,
            }
            if b"/Encrypt" in data:
                result["issues"].append({"rule_id": "DOC-SECURITY", "kind": "encrypted_pdf"})
        elif suffix in {".docx", ".epub", ".pages"} and zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as archive:
                inventory, issues = enforce_zip_limits(archive)
                result["issues"].extend(issues)
                names = set(archive.namelist())
                macros = [name for name in names if name.lower().endswith("vbaproject.bin")]
                scripts = [name for name in names if Path(name).suffix.lower() in {".js", ".vbs", ".sh", ".exe"}]
                external_relations = 0
                revision_markers = 0
                for name in names:
                    if name.endswith(".rels"):
                        info = archive.getinfo(name)
                        if info.file_size <= MAX_ZIP_ENTRY_BYTES:
                            external_relations += archive.read(name).count(b'TargetMode="External"')
                    if name == "word/document.xml":
                        info = archive.getinfo(name)
                        if info.file_size <= MAX_ZIP_ENTRY_BYTES:
                            content = archive.read(name)
                            revision_markers += content.count(b"<w:ins") + content.count(b"<w:del")
                if macros or scripts:
                    result["issues"].append({"rule_id": "DOC-SECURITY", "kind": "active_package_content", "count": len(macros) + len(scripts), "paths": [sanitize_evidence_path(name) for name in sorted(macros + scripts)[:100]]})
                if external_relations:
                    result["issues"].append({"rule_id": "DOC-SECURITY", "kind": "external_package_relationships", "count": external_relations})
                if revision_markers or any("comments" in name.lower() for name in names):
                    result["issues"].append({"rule_id": "DOC-METADATA", "kind": "comments_or_tracked_revisions", "revision_markers": revision_markers})
                result["inventory"] = {
                    **inventory, "format": suffix.lstrip("."), "macros": len(macros),
                    "scripts": len(scripts), "external_relationships": external_relations,
                    "revision_markers": revision_markers,
                    "has_core_properties": "docProps/core.xml" in names or "meta.xml" in names,
                }
        elif suffix == ".rtf":
            text = path.read_text(encoding="latin-1", errors="replace")
            if not text.startswith("{\\rtf") or text.count("{") != text.count("}"):
                result["issues"].append({"rule_id": "DOC-STRUCTURE", "kind": "invalid_or_unbalanced_rtf"})
            active = {token: text.lower().count(token) for token in ("\\object", "\\field", "\\htmltag")}
            if any(active.values()):
                result["issues"].append({"rule_id": "DOC-SECURITY", "kind": "active_rtf_controls", "counts": active})
            result["inventory"] = {"format": "rtf", "active_controls": active, "hidden_controls": text.lower().count("\\v")}
        else:
            result.update({"execution_status": "could_not_run", "result": "unknown", "error": f"no first-party structural parser for {suffix or 'this document'}"})
            result["completed_at"] = utc_now()
            return result
        result["result"] = "candidates" if result["issues"] else "holds"
    except Exception as exc:
        receipt_exception(result, exc)
    result["completed_at"] = utc_now()
    return result


def jpeg_dimensions(data: bytes) -> tuple[int, int] | None:
    index = 2
    while index + 9 < len(data):
        if data[index] != 0xFF:
            index += 1
            continue
        marker = data[index + 1]
        index += 2
        if marker in {0xD8, 0xD9} or 0xD0 <= marker <= 0xD7:
            continue
        if index + 2 > len(data):
            return None
        length = struct.unpack(">H", data[index:index + 2])[0]
        if length < 2 or index + length > len(data):
            return None
        if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF} and length >= 7:
            height, width = struct.unpack(">HH", data[index + 3:index + 7])
            return width, height
        index += length
    return None


def inspect_media(path: Path) -> dict[str, Any]:
    """Inspect selected image and WAV structures without decoding active content."""
    path = path.expanduser().resolve(strict=False)
    result = receipt_base(
        "media", path,
        ["semantic content, rights, provenance, accessibility, visual/audio quality, and delivery variants require separate human or codec-backed checks"],
    )
    try:
        bind_receipt(result, path, 100 * 1024 * 1024)
        suffix = path.suffix.lower()
        detected_magic = magic_kind(path)
        if suffix == ".svg":
            text = read_text_local(path)
            root = ET.fromstring(text)
            scripts = len(root.findall(".//{*}script"))
            external = 0
            for element in root.iter():
                for key, value in element.attrib.items():
                    if key.endswith("href") and value.startswith(("http://", "https://", "//")):
                        external += 1
            if scripts or external:
                result["issues"].append({"rule_id": "MEDIA-INTEGRITY", "kind": "active_or_external_svg_content", "scripts": scripts, "external_references": external})
            for pattern_id, pattern in SECRET_PATTERNS:
                lines = [text.count("\n", 0, match.start()) + 1 for match in secret_matches(pattern, text)]
                if lines:
                    result["issues"].append({"rule_id": "CORE-SECRET", "detector_id": pattern_id, "kind": "secret_candidate", "count": len(lines), "lines": lines[:100], "values_redacted": True})
            result["inventory"] = {
                "format": "svg", "width": root.attrib.get("width"), "height": root.attrib.get("height"),
                "view_box_present": any(key.lower().endswith("viewbox") for key in root.attrib),
                "title_elements": len(root.findall(".//{*}title")), "description_elements": len(root.findall(".//{*}desc")),
                "scripts": scripts, "external_references": external,
            }
        elif suffix == ".png" or detected_magic == "png":
            data = path.read_bytes()
            if not data.startswith(b"\x89PNG\r\n\x1a\n"):
                raise ValueError("invalid PNG signature")
            offset, chunks, metadata_chunks, width, height, ended = 8, 0, 0, None, None, False
            while offset + 12 <= len(data):
                length = struct.unpack(">I", data[offset:offset + 4])[0]
                chunk_type = data[offset + 4:offset + 8]
                end = offset + 12 + length
                if end > len(data):
                    raise ValueError("truncated PNG chunk")
                payload = data[offset + 8:offset + 8 + length]
                expected_crc = struct.unpack(">I", data[offset + 8 + length:end])[0]
                if zlib.crc32(chunk_type + payload) & 0xFFFFFFFF != expected_crc:
                    result["issues"].append({"rule_id": "MEDIA-INTEGRITY", "kind": "png_crc_failure", "chunk": chunk_type.decode("ascii", "replace")})
                    break
                chunks += 1
                if chunk_type == b"IHDR" and len(payload) >= 8:
                    width, height = struct.unpack(">II", payload[:8])
                if chunk_type in {b"tEXt", b"zTXt", b"iTXt", b"eXIf"}:
                    metadata_chunks += 1
                if chunk_type == b"IEND":
                    ended = True
                    break
                offset = end
            if not ended:
                result["issues"].append({"rule_id": "MEDIA-INTEGRITY", "kind": "png_missing_iend"})
            result["inventory"] = {"format": "png", "width": width, "height": height, "chunks": chunks, "metadata_chunks": metadata_chunks}
        elif suffix in {".jpg", ".jpeg"} or detected_magic == "jpeg":
            data = path.read_bytes()
            dimensions = jpeg_dimensions(data)
            if not data.startswith(b"\xff\xd8") or not data.endswith(b"\xff\xd9") or dimensions is None:
                result["issues"].append({"rule_id": "MEDIA-INTEGRITY", "kind": "invalid_or_truncated_jpeg"})
            result["inventory"] = {"format": "jpeg", "width": dimensions[0] if dimensions else None, "height": dimensions[1] if dimensions else None, "exif_present": b"Exif\x00\x00" in data, "xmp_present": b"http://ns.adobe.com/xap/1.0/" in data}
        elif suffix == ".gif" or detected_magic == "gif":
            data = path.read_bytes()
            if len(data) < 13 or data[:6] not in {b"GIF87a", b"GIF89a"}:
                raise ValueError("invalid GIF structure")
            width, height = struct.unpack("<HH", data[6:10])
            result["inventory"] = {"format": "gif", "width": width, "height": height, "trailer_present": data.endswith(b";")}
            if not data.endswith(b";"):
                result["issues"].append({"rule_id": "MEDIA-INTEGRITY", "kind": "gif_missing_trailer"})
        elif suffix == ".wav":
            with wave.open(str(path), "rb") as audio:
                result["inventory"] = {
                    "format": "wav", "channels": audio.getnchannels(), "sample_width_bytes": audio.getsampwidth(),
                    "sample_rate": audio.getframerate(), "frames": audio.getnframes(),
                    "duration_seconds": round(audio.getnframes() / audio.getframerate(), 6) if audio.getframerate() else None,
                    "compression": audio.getcomptype(),
                }
        else:
            result.update({"execution_status": "could_not_run", "result": "unknown", "error": f"no first-party decoder baseline for {suffix or 'this media'}"})
            result["completed_at"] = utc_now()
            return result
        result["result"] = "candidates" if result["issues"] else "holds"
    except Exception as exc:
        receipt_exception(result, exc)
    result["completed_at"] = utc_now()
    return result


def inspect_text(path: Path, max_bytes: int = 5 * 1024 * 1024) -> dict[str, Any]:
    path = path.expanduser().resolve(strict=False)
    result = receipt_base(
        "local_text_probe", path,
        ["candidate generation only; each match requires contextual adjudication"],
    )
    try:
        try:
            bind_receipt(result, path, max_bytes)
        except ValueError as exc:
            if "size limit" in str(exc):
                result.update({"execution_status": "could_not_run", "result": "unknown", "error": str(exc), "completed_at": utc_now()})
                return result
            raise
        text = read_text_local(path)
        for pattern_id, pattern in [*SECRET_PATTERNS, *SLOP_PATTERNS]:
            matches = secret_matches(pattern, text) if pattern_id.startswith("SECRET-") else list(pattern.finditer(text))
            lines = [text.count("\n", 0, match.start()) + 1 for match in matches]
            if lines:
                result["issues"].append({
                    "rule_id": "CORE-SECRET" if pattern_id.startswith("SECRET-") else "SLOP-LEFTOVER",
                    "detector_id": pattern_id,
                    "kind": "secret_candidate" if pattern_id.startswith("SECRET-") else "slop_signal",
                    "count": len(lines), "lines": lines[:100], "values_redacted": True,
                })
        result.update({"result": "candidates" if result["issues"] else "holds", "inventory": {"bytes": len(text.encode("utf-8")), "lines": text.count("\n") + 1}})
    except Exception as exc:
        receipt_exception(result, exc)
    result["completed_at"] = utc_now()
    return result


def verify_surface_binding(surface: dict[str, Any], path: Path) -> None:
    """Fail closed when target bytes changed after the manifest was created."""
    if surface.get("content_source") == "git_blob":
        git_root = Path(surface["git_root"])
        content, oid = read_git_blob(git_root, surface["content_ref"], surface["path"], surface.get("blob_oid"))
        entry = git_tree_entry(git_root, surface["content_ref"], surface["path"])
        if len(content) != surface.get("size") or hashlib.sha256(content).hexdigest() != surface.get("sha256") or oid != surface.get("blob_oid") or (entry and entry["mode"] != surface.get("git_mode")):
            raise ValueError(f"Git snapshot changed since manifest: {surface['path']}")
        return
    if surface.get("change", {}).get("status") == "D":
        return
    if surface.get("adapter") == "symlink":
        if not path.is_symlink():
            raise ValueError(f"target changed since manifest (symlink missing): {surface['path']}")
        if surface.get("file_mode") is not None and statlib.S_IMODE(path.lstat().st_mode) != surface["file_mode"]:
            raise ValueError(f"target changed since manifest (mode): {surface['path']}")
        current = short_hash(os.readlink(path), length=64)
    else:
        if not path.is_file():
            raise ValueError(f"target changed since manifest (file missing or replaced): {surface['path']}")
        current_stat = path.stat()
        current_size = current_stat.st_size
        if surface.get("file_mode") is not None and statlib.S_IMODE(current_stat.st_mode) != surface["file_mode"]:
            raise ValueError(f"target changed since manifest (mode): {surface['path']}")
        if surface.get("size") != current_size:
            raise ValueError(f"target changed since manifest (size): {surface['path']}")
        current = sha256_file(path)
    if surface.get("sha256") != current:
        raise ValueError(f"target changed since manifest (hash): {surface['path']}")


def receipt_check(surface: dict[str, Any], receipt: dict[str, Any], receipt_path: Path) -> dict[str, Any]:
    return {
        "id": "CHK-" + short_hash(surface["id"], receipt["adapter"], length=12).upper(),
        "kind": receipt["adapter"], "required": True, "blocking": False,
        "execution_status": receipt.get("execution_status", "failed"),
        "result": receipt.get("result", "unknown"),
        "scope": surface["path"], "surface_ids": [surface["id"]],
        "evidence": [str(receipt_path)], "started_at": receipt.get("started_at"),
        "completed_at": receipt.get("completed_at"),
        "candidate_count": len(receipt.get("issues", [])),
        "artifact_sha256": receipt.get("artifact", {}).get("sha256"),
        "error": receipt.get("error"),
    }


def probe_manifest(manifest_path: Path, output_path: Path | None, receipts_dir: Path) -> dict[str, Any]:
    manifest = load_json(manifest_path)
    validate_manifest(manifest)
    if current_target_fingerprint(manifest) != manifest["target"]["fingerprint"]:
        raise ValueError("target changed since manifest (scope or content)")
    root = Path(manifest["target"]["root"])
    receipts_dir = receipts_dir.expanduser().resolve()
    designated = Path(manifest["target"]["designated_path"])
    manifest_destination = output_path.expanduser().resolve() if output_path is not None else manifest_path.expanduser().resolve()
    assert_output_outside_target(manifest_destination, designated, manifest["target"]["kind"], "updated manifest output")
    assert_output_outside_target(receipts_dir, designated, manifest["target"]["kind"], "receipts directory")
    if manifest["target"]["kind"] == "directory":
        target_directory = designated.resolve()
        destinations = [(receipts_dir, "receipts directory")]
        destinations.append((manifest_destination, "updated manifest output"))
        for destination, label in destinations:
            try:
                destination.relative_to(target_directory)
            except ValueError:
                continue
            raise ValueError(f"{label} must be outside the reviewed directory")
    if receipts_dir.exists() and not receipts_dir.is_dir():
        raise ValueError("receipts destination must be a directory")
    if receipts_dir.exists() and any(receipts_dir.iterdir()):
        raise ValueError("receipts directory must be empty; use a fresh path to preserve bound evidence")
    receipts_dir.mkdir(parents=True, exist_ok=True)
    new_checks: list[dict[str, Any]] = []
    supported = {"html", "workbook", "document", "media", "archive-binary", "generic-file", "code", "data-config", "instruction", "generic-text"}
    for surface in manifest["surfaces"]:
        has_snapshot = surface.get("content_source") == "git_blob" and surface.get("sha256")
        if surface["state"] in {"excluded", "cannot_verify"} or (not surface.get("exists", True) and not has_snapshot):
            continue
        adapter = surface.get("adapter")
        if adapter not in supported and surface.get("handling") != "local_only":
            continue
        path = ensure_within(root / surface["path"], root)
        verify_surface_binding(surface, path)
        probe_path = path
        temporary_path: Path | None = None
        if surface.get("content_source") == "git_blob":
            content, _ = read_git_blob(Path(surface["git_root"]), surface["content_ref"], surface["path"], surface.get("blob_oid"))
            with tempfile.NamedTemporaryFile(prefix=f".{surface['id']}-", suffix=Path(surface["path"]).suffix, dir=receipts_dir, delete=False) as handle:
                handle.write(content)
                temporary_path = Path(handle.name)
            probe_path = temporary_path
        receipt: dict[str, Any] | None = None
        try:
            if adapter == "html":
                receipt = inspect_html(probe_path)
            elif adapter == "workbook":
                receipt = inspect_workbook(probe_path)
            elif adapter == "document":
                receipt = inspect_document(probe_path)
            elif adapter == "media":
                receipt = inspect_media(probe_path)
            elif adapter in {"archive-binary", "generic-file"}:
                receipt = inspect_archive_binary(probe_path)
            elif adapter in {"code", "data-config", "instruction", "generic-text"} or surface.get("handling") == "local_only":
                receipt = inspect_text(probe_path)
        finally:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
        if receipt is None:
            continue
        if surface.get("content_source") == "git_blob":
            coordinate = f"git:{surface['content_ref']}:{sanitize_evidence_path(surface['path'])}"
            receipt["path"] = coordinate
            if receipt.get("artifact"):
                receipt["artifact"]["path"] = coordinate
        if surface.get("extension_magic_mismatch"):
            receipt.setdefault("issues", []).append({
                "rule_id": "BIN-TYPE", "kind": "extension_magic_mismatch",
                "extension": surface.get("extension"), "magic": surface.get("magic"),
            })
            if receipt.get("execution_status") == "completed":
                receipt["result"] = "candidates"
        validate_receipt(receipt)
        if receipt.get("execution_status") == "completed" and receipt.get("artifact", {}).get("sha256") != surface.get("sha256"):
            raise ValueError(f"receipt hash does not match manifest surface: {surface['path']}")
        receipt_name = f"{surface['id']}-{receipt['adapter']}.json"
        receipt_path = receipts_dir / receipt_name
        atomic_json(receipt_path, receipt)
        new_checks.append(receipt_check(surface, receipt, receipt_path))
        surface.setdefault("evidence", []).append(str(receipt_path))
    existing = {check["id"]: check for check in manifest.get("checks", [])}
    for check in new_checks:
        existing[check["id"]] = check
    manifest["checks"] = list(existing.values())
    manifest["updated_at"] = utc_now()
    manifest["status"] = derive_manifest_status(manifest["surfaces"], manifest["checks"])
    manifest["stats"] = manifest_stats(manifest["surfaces"], manifest["checks"])
    validate_manifest(manifest)
    atomic_json(output_path or manifest_path, manifest)
    return manifest


def validate_manifest(manifest: dict[str, Any]) -> None:
    required = ["schema_version", "engine_version", "run_id", "created_at", "updated_at", "status", "target", "track", "evidence_ceiling", "mode", "adapters", "rule_packs", "surfaces", "exclusions", "checks", "warnings", "sampling", "stats"]
    missing = [key for key in required if key not in manifest]
    if missing:
        raise ValueError("manifest missing keys: " + ", ".join(missing))
    if manifest["schema_version"] != SCHEMA_VERSION:
        raise ValueError(f"unsupported manifest schema: {manifest['schema_version']}")
    if manifest["status"] not in {"planned", "in_progress", "complete", "partial", "failed"}:
        raise ValueError(f"invalid manifest status: {manifest['status']}")
    if manifest["mode"] not in {"full", "workspace", "commit", "range"}:
        raise ValueError(f"invalid manifest mode: {manifest['mode']}")
    if manifest["track"] not in TRACKS:
        raise ValueError(f"invalid track: {manifest['track']}")
    if manifest["evidence_ceiling"] not in EVIDENCE_CEILINGS:
        raise ValueError(f"invalid evidence ceiling: {manifest['evidence_ceiling']}")
    target = manifest["target"]
    target_missing = [key for key in ("designated_path", "resolved_path", "root", "kind", "fingerprint") if key not in target]
    if target_missing:
        raise ValueError("manifest target missing keys: " + ", ".join(target_missing))
    if target["kind"] not in {"file", "directory", "symlink", "missing"}:
        raise ValueError(f"invalid target kind: {target['kind']}")
    if not re.fullmatch(r"[0-9a-f]{64}", target["fingerprint"]):
        raise ValueError("invalid target fingerprint")
    if not isinstance(manifest["adapters"], list) or len(manifest["adapters"]) != len(set(manifest["adapters"])):
        raise ValueError("manifest adapters must be a unique array")
    if not isinstance(manifest["rule_packs"], list) or len(manifest["rule_packs"]) != len(set(manifest["rule_packs"])):
        raise ValueError("manifest rule_packs must be a unique array")
    if "gauntlet.core" not in manifest["rule_packs"]:
        raise ValueError("manifest cannot remove gauntlet.core")
    available_packs = set(load_rule_packs())
    missing_packs = sorted(set(manifest["rule_packs"]) - available_packs)
    if missing_packs:
        raise ValueError("manifest references unavailable rule packs: " + ", ".join(missing_packs))
    sampling = manifest["sampling"]
    if not isinstance(sampling, dict) or not sampling.get("method") or not isinstance(sampling.get("sampled"), bool) or not sampling.get("declaration"):
        raise ValueError("manifest requires an explicit sampling declaration")
    for key in ("max_file_bytes", "max_surfaces"):
        if key in sampling and (not isinstance(sampling[key], int) or sampling[key] <= 0):
            raise ValueError(f"sampling.{key} must be a positive integer")
    ids: set[str] = set()
    paths: set[str] = set()
    for surface in manifest["surfaces"]:
        for key in ("id", "path", "state", "mandatory", "coverage_method", "adapter"):
            if key not in surface:
                raise ValueError(f"surface missing {key}: {surface}")
        if not re.fullmatch(r"S-[0-9a-f]{12}", surface["id"]):
            raise ValueError(f"invalid surface id: {surface['id']}")
        if surface["id"] in ids:
            raise ValueError(f"duplicate surface id: {surface['id']}")
        if surface["path"] in paths:
            raise ValueError(f"duplicate surface path: {surface['path']}")
        if Path(surface["path"].rstrip("/")).is_absolute() or ".." in Path(surface["path"].rstrip("/")).parts:
            raise ValueError(f"unsafe surface path: {surface['path']}")
        if not isinstance(surface["mandatory"], bool):
            raise ValueError(f"surface mandatory must be boolean: {surface['id']}")
        if surface["coverage_method"] not in {"exhaustive", "sampled", "metadata_only", "excluded"}:
            raise ValueError(f"invalid coverage method for {surface['id']}")
        if surface["state"] not in SURFACE_STATES:
            raise ValueError(f"invalid surface state {surface['state']} for {surface['id']}")
        if surface["state"] in {"excluded", "cannot_verify", "failed"} and not surface.get("reason"):
            raise ValueError(f"surface {surface['id']} requires a reason for state {surface['state']}")
        if not isinstance(surface.get("evidence"), list):
            raise ValueError(f"surface {surface['id']} evidence must be an array")
        if surface["state"] == "reviewed" and not surface["evidence"]:
            raise ValueError(f"reviewed surface {surface['id']} requires evidence")
        if surface.get("sha256") is not None and not re.fullmatch(r"[0-9a-f]{64}", surface["sha256"]):
            raise ValueError(f"invalid surface hash: {surface['id']}")
        ids.add(surface["id"])
        paths.add(surface["path"])
    check_ids: set[str] = set()
    for check in manifest["checks"]:
        if not check.get("id"):
            raise ValueError("check missing id")
        if check["id"] in check_ids:
            raise ValueError(f"duplicate check id: {check['id']}")
        for key in ("kind", "required", "blocking", "scope", "evidence"):
            if key not in check:
                raise ValueError(f"check {check['id']} missing {key}")
        if not isinstance(check["required"], bool) or not isinstance(check["blocking"], bool):
            raise ValueError(f"check {check['id']} required/blocking must be boolean")
        if not isinstance(check["evidence"], list):
            raise ValueError(f"check {check['id']} evidence must be an array")
        execution = check.get("execution_status")
        result = check.get("result")
        if execution not in EXECUTION_STATES:
            raise ValueError(f"invalid check execution status for {check['id']}")
        if result not in CHECK_RESULTS:
            raise ValueError(f"invalid check result for {check['id']}")
        if execution == "completed" and result == "unknown":
            raise ValueError(f"completed check {check['id']} cannot have unknown result")
        if execution in {"pending", "failed", "could_not_run"} and result != "unknown":
            raise ValueError(f"incomplete check {check['id']} must have unknown result")
        if execution == "skipped" and result not in {"unknown", "not_applicable"}:
            raise ValueError(f"skipped check {check['id']} has incompatible result")
        if execution == "completed" and not check["evidence"]:
            raise ValueError(f"completed check {check['id']} requires evidence")
        if execution in {"failed", "could_not_run", "skipped"} and not check.get("reason") and not check.get("error"):
            raise ValueError(f"check {check['id']} requires a failure or skip reason")
        check_ids.add(check["id"])


def validate_receipt(receipt: dict[str, Any]) -> None:
    required = ["schema_version", "adapter", "adapter_version", "path", "artifact", "started_at", "completed_at", "execution_status", "result", "issues", "limitations"]
    missing = [key for key in required if key not in receipt]
    if missing:
        raise ValueError("receipt missing keys: " + ", ".join(missing))
    if receipt["schema_version"] != SCHEMA_VERSION:
        raise ValueError(f"unsupported receipt schema: {receipt['schema_version']}")
    if receipt["execution_status"] not in {"completed", "failed", "could_not_run"}:
        raise ValueError("invalid receipt execution status")
    if receipt["result"] not in {"holds", "candidates", "fails", "unknown"}:
        raise ValueError("invalid receipt result")
    if receipt["execution_status"] == "completed" and receipt["result"] == "unknown":
        raise ValueError("completed receipt cannot have unknown result")
    if receipt["result"] == "holds" and receipt.get("issues"):
        raise ValueError("receipt with candidate issues cannot report holds")
    if receipt["result"] == "candidates" and not receipt.get("issues"):
        raise ValueError("candidate receipt requires at least one issue")
    if receipt["execution_status"] != "completed" and receipt["result"] != "unknown":
        raise ValueError("incomplete receipt must have unknown result")
    artifact = receipt["artifact"]
    if not isinstance(artifact, dict) or "sha256" not in artifact or "size" not in artifact:
        raise ValueError("receipt requires an artifact binding object")
    if receipt["execution_status"] == "completed":
        if not re.fullmatch(r"[0-9a-f]{64}", artifact.get("sha256") or ""):
            raise ValueError("completed receipt requires an artifact SHA-256 binding")
        if not isinstance(artifact.get("size"), int) or artifact["size"] < 0:
            raise ValueError("completed receipt requires a non-negative artifact size")
    if not isinstance(receipt["issues"], list) or not isinstance(receipt["limitations"], list):
        raise ValueError("receipt issues and limitations must be arrays")
    rule_ids = {rule["id"] for pack in load_rule_packs().values() for rule in pack["rules"]}
    for issue in receipt["issues"]:
        if issue.get("rule_id") not in rule_ids:
            raise ValueError(f"receipt issue references unknown rule: {issue.get('rule_id')}")
        if not issue.get("kind"):
            raise ValueError("receipt issue requires a kind")


def validate_ledger(ledger: dict[str, Any], strict_v7: bool = True, verify_fingerprints: bool = True) -> None:
    if "findings" not in ledger or not isinstance(ledger["findings"], list):
        raise ValueError("ledger requires a findings array")
    serialized = json.dumps(ledger, ensure_ascii=False)
    secret_detectors = detected_secret_ids(serialized)
    if secret_detectors:
        raise ValueError("ledger contains raw secret candidates; redact values and use local evidence references: " + ", ".join(secret_detectors))
    is_v7 = str(ledger.get("schema_version", "")).startswith("7")
    if strict_v7 and not is_v7:
        raise ValueError("strict ledger validation requires schema_version 7.x")
    if strict_v7:
        missing_identity = [key for key in ("run_id", "target_fingerprint", "manifest_path") if not ledger.get(key)]
        if missing_identity:
            raise ValueError("v7 ledger missing identity fields: " + ", ".join(missing_identity))
        if not re.fullmatch(r"[0-9a-f]{64}", ledger["target_fingerprint"]):
            raise ValueError("v7 ledger has invalid target_fingerprint")
    ids: set[str] = set()
    fingerprints: set[str] = set()
    for finding in ledger["findings"]:
        for key in ("id", "title", "severity", "status"):
            if key not in finding:
                raise ValueError(f"finding missing {key}: {finding.get('id', '?')}")
        if finding["id"] in ids:
            raise ValueError(f"duplicate finding id: {finding['id']}")
        ids.add(finding["id"])
        if finding["severity"] not in {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"}:
            raise ValueError(f"invalid severity for {finding['id']}")
        if finding["status"] not in {"open", "fixed", "regressed", "accepted", "withdrawn", "not_rechecked"}:
            raise ValueError(f"invalid status for {finding['id']}")
        if strict_v7 and is_v7:
            required = (
                "fingerprint", "rule_id", "surface_ids", "criteria", "evidence",
                "evidence_class", "evidence_method", "evidence_scope", "evidence_refs", "confidence",
                "location", "anchor", "quote", "horizon", "root_cause", "counter", "disposition",
                "regression", "verification", "first_seen_revision",
            )
            missing = [key for key in required if key not in finding or finding[key] is None or finding[key] == ""]
            if missing:
                raise ValueError(f"v7 finding {finding['id']} missing {', '.join(missing)}")
            if not isinstance(finding["surface_ids"], list) or not finding["surface_ids"]:
                raise ValueError(f"v7 finding {finding['id']} requires surface_ids")
            if not isinstance(finding["criteria"], list) or not finding["criteria"]:
                raise ValueError(f"v7 finding {finding['id']} requires criteria")
            if finding["evidence_class"] not in {"verified_fact", "derived_inference", "judgment", "unverifiable_risk"}:
                raise ValueError(f"invalid evidence class for {finding['id']}")
            if not isinstance(finding["evidence_refs"], list) or not finding["evidence_refs"]:
                raise ValueError(f"v7 finding {finding['id']} requires evidence_refs")
            if finding["confidence"] not in {"high", "moderate", "low"}:
                raise ValueError(f"invalid confidence for {finding['id']}")
            anchor = finding["anchor"]
            if not isinstance(anchor, dict) or not anchor.get("type") or not anchor.get("coordinate") or not isinstance(anchor.get("resolved"), bool):
                raise ValueError(f"invalid anchor for {finding['id']}")
            if finding["disposition"] not in {"FIX", "WAIVE", "ASK", "BLOCK", "INFO"}:
                raise ValueError(f"invalid disposition for {finding['id']}")
        if finding.get("fingerprint"):
            if not re.fullmatch(r"GF-[0-9a-f]{24}", finding["fingerprint"]):
                raise ValueError(f"invalid finding fingerprint: {finding['fingerprint']}")
            if strict_v7 and verify_fingerprints and finding["fingerprint"] != finding_fingerprint(finding):
                raise ValueError(f"stale or invalid finding fingerprint: {finding['id']}")
            if finding["fingerprint"] in fingerprints:
                raise ValueError(f"duplicate finding fingerprint: {finding['fingerprint']}")
            fingerprints.add(finding["fingerprint"])


def validate_rule_pack(pack: dict[str, Any]) -> None:
    for key in ("id", "version", "title", "applies_to", "rules"):
        if key not in pack:
            raise ValueError(f"rule pack missing {key}")
    if not re.fullmatch(r"gauntlet\.[a-z0-9-]+", pack["id"]):
        raise ValueError(f"invalid rule pack id: {pack['id']}")
    if not re.fullmatch(r"\d+\.\d+\.\d+", pack["version"]):
        raise ValueError(f"invalid rule pack version: {pack['id']}")
    if not isinstance(pack["applies_to"], list) or not pack["applies_to"] or len(pack["applies_to"]) != len(set(pack["applies_to"])):
        raise ValueError(f"invalid applies_to for {pack['id']}")
    if not isinstance(pack["rules"], list) or not pack["rules"]:
        raise ValueError(f"rule pack has no rules: {pack['id']}")
    seen: set[str] = set()
    severities = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "CONTEXTUAL"}
    for rule in pack["rules"]:
        for key in ("id", "title", "question", "evidence_required"):
            if not rule.get(key):
                raise ValueError(f"rule in {pack['id']} missing {key}")
        if rule["id"] in seen:
            raise ValueError(f"duplicate rule id {rule['id']} in {pack['id']}")
        if rule.get("default_severity") and rule["default_severity"] not in severities:
            raise ValueError(f"invalid default severity for {rule['id']}")
        if "tags" in rule and not isinstance(rule["tags"], list):
            raise ValueError(f"invalid tags for {rule['id']}")
        seen.add(rule["id"])


def verify_findings(manifest: dict[str, Any], ledger: dict[str, Any], ledger_sha256: str) -> dict[str, Any]:
    """Independently recheck mechanical finding claims without deciding semantics."""
    started = utc_now()
    validate_manifest(manifest)
    if current_target_fingerprint(manifest) != manifest["target"]["fingerprint"]:
        raise ValueError("target changed since manifest; create a fresh review epoch")
    validate_ledger(ledger, strict_v7=True, verify_fingerprints=False)
    if ledger["target_fingerprint"] != manifest["target"]["fingerprint"]:
        raise ValueError("ledger target fingerprint does not match manifest")
    surfaces = {surface["id"]: surface for surface in manifest["surfaces"]}
    root = Path(manifest["target"]["root"])
    results: list[dict[str, Any]] = []
    for finding in ledger["findings"]:
        checks: list[dict[str, Any]] = []
        failed = False
        unresolved = False
        expected = finding_fingerprint(finding)
        fingerprint_holds = finding["fingerprint"] == expected
        checks.append({"name": "fingerprint", "status": "holds" if fingerprint_holds else "fails"})
        failed = failed or not fingerprint_holds

        unknown_surfaces = sorted(set(finding["surface_ids"]) - set(surfaces))
        checks.append({
            "name": "surface_binding", "status": "fails" if unknown_surfaces else "holds",
            "unknown_surface_ids": unknown_surfaces,
        })
        failed = failed or bool(unknown_surfaces)

        anchor_status = "unresolved"
        anchor_mode = "none"
        if not unknown_surfaces:
            readable_text: list[str] = []
            binding_failed = False
            for surface_id_value in finding["surface_ids"]:
                surface = surfaces[surface_id_value]
                has_snapshot = surface.get("content_source") == "git_blob" and surface.get("sha256")
                if (not surface.get("exists", True) and not has_snapshot) or surface.get("state") == "excluded":
                    continue
                if surface.get("kind") == "symlink" or surface.get("sha256") is None:
                    continue
                try:
                    path = ensure_within(root / surface["path"], root)
                    verify_surface_binding(surface, path)
                    if has_snapshot:
                        content, _ = read_git_blob(Path(surface["git_root"]), surface["content_ref"], surface["path"], surface.get("blob_oid"))
                        if looks_text_bytes(content):
                            readable_text.append(decode_text_local(content))
                    elif looks_text(path):
                        readable_text.append(read_text_local(path))
                except (OSError, ValueError):
                    binding_failed = True
                    continue
            if binding_failed:
                anchor_status = "fails"
                anchor_mode = "surface_hash_changed"
                failed = True
            else:
                quote = str(finding.get("quote") or "")
                for text in readable_text:
                    if quote and quote in text:
                        anchor_status = "holds"
                        anchor_mode = "exact_quote"
                        break
                if anchor_status != "holds" and finding.get("anchor", {}).get("resolved") is True:
                    anchor_status = "holds"
                    anchor_mode = "artifact_native_attestation"
                elif anchor_status != "holds":
                    unresolved = True
        checks.append({"name": "anchor", "status": anchor_status, "mode": anchor_mode})

        protected = finding["severity"] in {"CRITICAL", "HIGH"}
        human_checks = ["factual_consequence", "counter_evidence", "severity", "confidence", "root_cause", "duplication", "regression"]
        mechanical_status = "fails" if failed else "unresolved" if unresolved else "holds"
        results.append({
            "id": finding["id"], "fingerprint": finding["fingerprint"],
            "protected": protected, "mechanical_status": mechanical_status,
            "checks": checks, "human_checks_required": human_checks,
        })
    counts = Counter(item["mechanical_status"] for item in results)
    human_count = sum(len(item["human_checks_required"]) for item in results)
    if counts.get("fails"):
        overall = "fails"
    elif counts.get("unresolved") or human_count:
        overall = "candidates"
    else:
        overall = "holds"
    return {
        "$schema": "https://miancore.local/gauntlet/verifier-receipt-schema.json",
        "schema_version": SCHEMA_VERSION,
        "verifier_version": ENGINE_VERSION,
        "started_at": started,
        "completed_at": utc_now(),
        "execution_status": "completed",
        "result": overall,
        "manifest_fingerprint": manifest["target"]["fingerprint"],
        "ledger_sha256": ledger_sha256,
        "findings_total": len(results),
        "findings": results,
        "summary": {
            "holds": counts.get("holds", 0), "fails": counts.get("fails", 0),
            "unresolved": counts.get("unresolved", 0), "human_checks_required": human_count,
        },
        "limitations": [
            "mechanical verification does not decide factual consequence, counter-evidence, severity, confidence, root cause, duplication, or regression",
            "artifact-native attestations require independent human or specialized-adapter review",
        ],
    }


def validate_verifier_receipt(receipt: dict[str, Any]) -> None:
    required = ["schema_version", "verifier_version", "started_at", "completed_at", "execution_status", "result", "manifest_fingerprint", "ledger_sha256", "findings_total", "findings", "summary", "limitations"]
    missing = [key for key in required if key not in receipt]
    if missing:
        raise ValueError("verifier receipt missing keys: " + ", ".join(missing))
    if receipt["schema_version"] != SCHEMA_VERSION or receipt["execution_status"] != "completed":
        raise ValueError("invalid verifier receipt version or execution state")
    if receipt["result"] not in {"holds", "candidates", "fails"}:
        raise ValueError("invalid verifier receipt result")
    for key in ("manifest_fingerprint", "ledger_sha256"):
        if not re.fullmatch(r"[0-9a-f]{64}", receipt[key]):
            raise ValueError(f"invalid verifier receipt {key}")
    if receipt["findings_total"] != len(receipt["findings"]):
        raise ValueError("verifier finding count mismatch")
    statuses = Counter()
    human_checks = 0
    identities: set[tuple[str, str]] = set()
    for finding in receipt["findings"]:
        status = finding.get("mechanical_status")
        if status not in {"holds", "fails", "unresolved"}:
            raise ValueError("invalid verifier finding status")
        identity = (str(finding.get("id", "")), str(finding.get("fingerprint", "")))
        if not identity[0] or not re.fullmatch(r"GF-[0-9a-f]{24}", identity[1]) or identity in identities:
            raise ValueError("invalid or duplicate verifier finding identity")
        identities.add(identity)
        statuses[status] += 1
        required_human = finding.get("human_checks_required", [])
        if not isinstance(required_human, list):
            raise ValueError("invalid verifier human check list")
        human_checks += len(required_human)
    expected_summary = {
        "holds": statuses.get("holds", 0), "fails": statuses.get("fails", 0),
        "unresolved": statuses.get("unresolved", 0), "human_checks_required": human_checks,
    }
    if any(receipt["summary"].get(key) != value for key, value in expected_summary.items()):
        raise ValueError("verifier summary does not match finding results")
    expected_result = "fails" if expected_summary["fails"] else "candidates" if expected_summary["unresolved"] or human_checks else "holds"
    if receipt["result"] != expected_result:
        raise ValueError("verifier result does not match finding results")


def validate_bound_verifier(
    manifest: dict[str, Any], report_ledger: dict[str, Any], base_dir: Path,
) -> dict[str, Any]:
    """Resolve and validate the exact candidate ledger and verifier receipt bound to a run."""
    verifier_checks = [
        check for check in manifest["checks"]
        if check.get("id") == "CHK-FINDINGS-VERIFIER" or check.get("kind") == "finding_verifier"
    ]
    if len(verifier_checks) != 1:
        raise ValueError("exactly one findings verifier check is required")
    check = verifier_checks[0]
    if check.get("execution_status") != "completed" or check.get("result") != "holds":
        raise ValueError("findings verifier check is not completed with result holds")
    records: list[tuple[Path, dict[str, Any]]] = []
    for reference in check.get("evidence", []):
        location = str(reference).split("#", 1)[0]
        if not location:
            continue
        path = Path(location).expanduser()
        if not path.is_absolute():
            path = base_dir / path
        try:
            if path.is_file():
                record = load_json(path)
                records.append((path.resolve(), record))
        except (OSError, ValueError, json.JSONDecodeError):
            continue
    verifier_records = [(path, data) for path, data in records if "verifier_version" in data and "manifest_fingerprint" in data]
    candidate_records = [(path, data) for path, data in records if "findings" in data and "target_fingerprint" in data and "manifest_path" in data and "report_id" not in data]
    if len(verifier_records) != 1 or len(candidate_records) != 1:
        raise ValueError("verifier evidence must resolve one receipt and one candidate ledger")
    verifier_path, verifier = verifier_records[0]
    candidate_path, candidate = candidate_records[0]
    validate_verifier_receipt(verifier)
    validate_ledger(candidate, strict_v7=True)
    if candidate.get("run_id") != manifest["run_id"] or report_ledger.get("run_id") != manifest["run_id"]:
        raise ValueError("verifier run identity does not match manifest")
    fingerprint = manifest["target"]["fingerprint"]
    if candidate.get("target_fingerprint") != fingerprint or report_ledger.get("target_fingerprint") != fingerprint:
        raise ValueError("verifier target fingerprint does not match manifest")
    if verifier["manifest_fingerprint"] != fingerprint:
        raise ValueError("verifier receipt manifest fingerprint mismatch")
    bound_manifest_path = Path(candidate["manifest_path"]).expanduser()
    if not bound_manifest_path.is_absolute():
        bound_manifest_path = candidate_path.parent / bound_manifest_path
    try:
        bound_manifest = load_json(bound_manifest_path)
    except (OSError, ValueError, json.JSONDecodeError):
        raise ValueError("candidate ledger manifest is unavailable") from None
    if bound_manifest != manifest:
        raise ValueError("candidate ledger does not bind the current manifest")
    candidate_sha256 = sha256_file(candidate_path)
    if verifier["ledger_sha256"] != candidate_sha256:
        raise ValueError("verifier receipt ledger hash mismatch")
    if verifier["findings_total"] != len(candidate["findings"]):
        raise ValueError("verifier receipt finding count does not match candidate ledger")
    candidate_identities = {(item["id"], item["fingerprint"]) for item in candidate["findings"]}
    verifier_identities = {(item["id"], item["fingerprint"]) for item in verifier["findings"]}
    if verifier_identities != candidate_identities:
        raise ValueError("verifier receipt findings do not match candidate ledger")
    if report_ledger.get("findings") != candidate["findings"]:
        raise ValueError("report findings do not match the independently verified candidate ledger")
    if detected_secret_ids(str(candidate_path)) or detected_secret_ids(str(verifier_path)):
        raise ValueError("verifier evidence path contains a raw secret candidate; relocate the run artifacts")
    return {
        "candidate_ledger_path": str(candidate_path), "candidate_ledger_sha256": candidate_sha256,
        "verifier_receipt_path": str(verifier_path), "verifier_receipt_sha256": sha256_file(verifier_path),
    }


def mark_surface(manifest_path: Path, surface_ref: str, state: str, reason: str | None, evidence: list[str]) -> dict[str, Any]:
    manifest = load_json(manifest_path)
    validate_manifest(manifest)
    if current_target_fingerprint(manifest) != manifest["target"]["fingerprint"]:
        raise ValueError("target changed since manifest; create a fresh review epoch")
    matches = [s for s in manifest["surfaces"] if s["id"] == surface_ref or s["path"] == surface_ref]
    if len(matches) != 1:
        raise ValueError(f"surface reference matched {len(matches)} items: {surface_ref}")
    surface = matches[0]
    if state in {"excluded", "cannot_verify", "failed"} and not reason:
        raise ValueError(f"state {state} requires --reason")
    if state == "reviewed" and not evidence:
        raise ValueError("state reviewed requires at least one --evidence reference")
    surface["state"] = state
    surface["reason"] = reason
    surface.setdefault("evidence", []).extend(item for item in evidence if item not in surface["evidence"])
    manifest["updated_at"] = utc_now()
    manifest["status"] = derive_manifest_status(manifest["surfaces"], manifest["checks"])
    manifest["stats"] = manifest_stats(manifest["surfaces"], manifest["checks"])
    validate_manifest(manifest)
    atomic_json(manifest_path, manifest)
    return manifest


def record_check(manifest_path: Path, check_id: str, execution: str, result: str, required: bool, blocking: bool, scope: str, evidence: list[str], reason: str | None) -> dict[str, Any]:
    manifest = load_json(manifest_path)
    validate_manifest(manifest)
    if current_target_fingerprint(manifest) != manifest["target"]["fingerprint"]:
        raise ValueError("target changed since manifest; create a fresh review epoch")
    if execution == "completed" and not evidence:
        raise ValueError("completed check requires at least one --evidence reference")
    if execution in {"failed", "could_not_run", "skipped"} and not reason:
        raise ValueError(f"check execution {execution} requires --reason")
    by_id = {item["id"]: item for item in manifest["checks"]}
    previous = by_id.get(check_id, {})
    check = {
        **previous,
        "id": check_id, "kind": previous.get("kind", "manual_or_external"),
        "required": required, "blocking": blocking,
        "execution_status": execution, "result": result, "scope": scope,
        "evidence": evidence, "reason": reason,
        "started_at": previous.get("started_at"),
        "completed_at": utc_now() if execution != "pending" else None,
    }
    if previous:
        check["adjudication_kind"] = "manual_or_external"
        check["prior_result"] = previous.get("prior_result", previous.get("result"))
    by_id[check_id] = check
    manifest["checks"] = list(by_id.values())
    manifest["updated_at"] = utc_now()
    manifest["status"] = derive_manifest_status(manifest["surfaces"], manifest["checks"])
    manifest["stats"] = manifest_stats(manifest["surfaces"], manifest["checks"])
    validate_manifest(manifest)
    atomic_json(manifest_path, manifest)
    return manifest


def canonical_finding_location(value: Any) -> str:
    """Normalize volatile source line suffixes while preserving native coordinates."""
    location = str(value or "").replace("\\", "/").strip().lower()
    location = re.sub(r"#l\d+(?:-l\d+)?$", "", location)
    match = re.fullmatch(r"(.+\.[a-z0-9]{1,12}):\d+(?::\d+)?(?:-\d+)?", location)
    if match:
        location = match.group(1)
    return location


def finding_fingerprint(finding: dict[str, Any]) -> str:
    quote = re.sub(r"\s+", " ", str(finding.get("quote") or finding.get("found") or "")).strip().lower()
    location = canonical_finding_location(finding.get("location"))
    surfaces = ",".join(sorted(str(item) for item in finding.get("surface_ids", [])))
    rule = str(finding.get("rule_id") or finding.get("domain") or "").lower()
    root_cause = re.sub(r"\s+", " ", str(finding.get("root_cause") or finding.get("title") or "")).strip().lower()
    return "GF-" + short_hash(location, surfaces, rule, quote, root_cause, length=24)


def compare_ledgers(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    validate_ledger(old, strict_v7=False)
    validate_ledger(new, strict_v7=False)
    old_map = {(f.get("fingerprint") or finding_fingerprint(f)): f for f in old["findings"]}
    new_map = {(f.get("fingerprint") or finding_fingerprint(f)): f for f in new["findings"]}
    buckets: dict[str, list[dict[str, Any]]] = {key: [] for key in ("new", "persisting", "fixed", "regressed", "accepted", "withdrawn", "not_rechecked")}
    for fingerprint, finding in new_map.items():
        previous = old_map.get(fingerprint)
        item = {"fingerprint": fingerprint, "id": finding.get("id"), "previous_id": previous.get("id") if previous else None, "title": finding.get("title")}
        status = finding.get("status")
        if previous is None:
            bucket = "new"
        elif status == "not_rechecked":
            bucket = "not_rechecked"
        elif status == "regressed" or (previous.get("status") == "fixed" and status == "open"):
            bucket = "regressed"
        elif status == "fixed" and previous.get("status") != "fixed":
            bucket = "fixed"
        elif status == "fixed":
            bucket = "persisting"
        elif status == "accepted":
            bucket = "accepted"
        elif status == "withdrawn":
            bucket = "withdrawn"
        else:
            bucket = "persisting"
        buckets[bucket].append(item)
    for fingerprint, finding in old_map.items():
        if fingerprint not in new_map:
            buckets["not_rechecked"].append({"fingerprint": fingerprint, "id": finding.get("id"), "previous_id": finding.get("id"), "title": finding.get("title")})
    return {
        "schema_version": SCHEMA_VERSION, "generated_at": utc_now(),
        "old_run_id": old.get("run_id") or old.get("report_id"),
        "new_run_id": new.get("run_id") or new.get("report_id"),
        **{key: [item["fingerprint"] for item in value] for key, value in buckets.items()},
        "counts": {key: len(value) for key, value in buckets.items()},
        "buckets": buckets,
        "rule": "absence from a later ledger is not resolution; it remains not_rechecked until explicit evidence changes its state",
    }


def current_target_fingerprint(manifest: dict[str, Any]) -> str:
    target_record = {key: value for key, value in manifest["target"].items() if key != "fingerprint"}
    target = Path(manifest["target"]["designated_path"])
    max_file_bytes = int(manifest.get("sampling", {}).get("max_file_bytes", DEFAULT_MAX_FILE_BYTES))
    max_surfaces = int(manifest.get("sampling", {}).get("max_surfaces", DEFAULT_MAX_SURFACES))
    if manifest["mode"] == "full":
        _, surfaces, _ = inventory_full(target, max_file_bytes, max_surfaces)
        return target_fingerprint(target_record, surfaces, None)
    if manifest["mode"] == "workspace":
        _, surfaces, _, git_meta = inventory_git(target, "workspace", None, None, None, max_file_bytes, max_surfaces)
        return target_fingerprint(target_record, surfaces, git_meta)
    for surface in manifest["surfaces"]:
        if surface.get("sha256") is None or surface.get("state") == "excluded":
            continue
        root = Path(manifest["target"]["root"])
        verify_surface_binding(surface, ensure_within(root / surface["path"], root))
    return manifest["target"]["fingerprint"]


def validate_gate_receipt(receipt: dict[str, Any], require_bindings: bool = False) -> None:
    required = [
        "schema_version", "generated_at", "run_id", "target_fingerprint", "track", "verdict",
        "coverage_rate", "coverage", "mandatory_surfaces", "reviewed_mandatory_surfaces",
        "open_critical", "open_high", "accepted_critical", "accepted_high", "not_rechecked_material", "reasons",
        "manifest_sha256", "candidate_ledger_path", "candidate_ledger_sha256",
        "verifier_receipt_path", "verifier_receipt_sha256",
    ]
    missing = [key for key in required if key not in receipt]
    if missing:
        raise ValueError("gate receipt missing keys: " + ", ".join(missing))
    if receipt["schema_version"] != SCHEMA_VERSION or receipt["track"] not in TRACKS:
        raise ValueError("invalid gate receipt version or track")
    if receipt["verdict"] not in {"READY", "CONDITIONAL", "NOT_READY", "BLOCKED"}:
        raise ValueError("invalid gate receipt verdict")
    if not re.fullmatch(r"[0-9a-f]{64}", receipt["target_fingerprint"]):
        raise ValueError("invalid gate target fingerprint")
    coverage = receipt["coverage"]
    keys = ("reviewed", "excluded", "cannot_verify", "failed", "pending")
    if sum(coverage.get(key, -1) for key in keys) != coverage.get("mandatory_total"):
        raise ValueError("gate coverage counts do not account for mandatory_total")
    calculated = 1.0 if coverage["mandatory_total"] == 0 else coverage["reviewed"] / coverage["mandatory_total"]
    if abs(calculated - coverage.get("rate", -1)) > 0.000001 or abs(receipt["coverage_rate"] - coverage["rate"]) > 0.000001:
        raise ValueError("gate coverage rate mismatch")
    if receipt["mandatory_surfaces"] != coverage["mandatory_total"] or receipt["reviewed_mandatory_surfaces"] != coverage["reviewed"]:
        raise ValueError("gate summary count mismatch")
    if receipt["verdict"] == "READY" and receipt["reasons"]:
        raise ValueError("READY gate cannot retain reasons")
    for key in ("manifest_sha256", "candidate_ledger_sha256", "verifier_receipt_sha256"):
        value = receipt.get(key)
        if value is not None and not re.fullmatch(r"[0-9a-f]{64}", value):
            raise ValueError(f"invalid gate receipt {key}")
    for key in ("candidate_ledger_path", "verifier_receipt_path"):
        if receipt.get(key) is not None and not isinstance(receipt[key], str):
            raise ValueError(f"invalid gate receipt {key}")
    if require_bindings and receipt["verdict"] == "READY":
        binding_keys = ("manifest_sha256", "candidate_ledger_path", "candidate_ledger_sha256", "verifier_receipt_path", "verifier_receipt_sha256")
        if any(not receipt.get(key) for key in binding_keys):
            raise ValueError("READY gate requires manifest, candidate-ledger, and verifier bindings")


def coverage_gate(manifest: dict[str, Any], ledger: dict[str, Any] | None) -> dict[str, Any]:
    validate_manifest(manifest)
    if ledger is not None:
        validate_ledger(ledger, strict_v7=True)
        if ledger["target_fingerprint"] != manifest["target"]["fingerprint"]:
            raise ValueError("ledger target fingerprint does not match manifest")
        surface_ids = {surface["id"] for surface in manifest["surfaces"]}
        for finding in ledger["findings"]:
            unknown = sorted(set(finding["surface_ids"]) - surface_ids)
            if unknown:
                raise ValueError(f"finding {finding['id']} references unknown surfaces: {', '.join(unknown)}")
    reasons: list[dict[str, Any]] = []
    hard_failure = False
    uncertainty = False
    try:
        current_fingerprint = current_target_fingerprint(manifest)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        hard_failure = True
        reasons.append({"code": "TARGET_RECHECK_FAILED", "error_type": type(exc).__name__})
    else:
        if current_fingerprint != manifest["target"]["fingerprint"]:
            hard_failure = True
            reasons.append({"code": "TARGET_CHANGED_SINCE_MANIFEST"})
    if manifest["track"] == "UNDECIDED":
        uncertainty = True
        reasons.append({"code": "TRACK_UNDECIDED"})
    if ledger is None:
        uncertainty = True
        reasons.append({"code": "LEDGER_MISSING"})
    for surface in manifest["surfaces"]:
        if not surface.get("mandatory", True):
            continue
        state = surface["state"]
        if state == "pending":
            uncertainty = True
            reasons.append({"code": "SURFACE_PENDING", "surface_id": surface["id"], "path": surface["path"]})
        elif state == "cannot_verify":
            uncertainty = True
            reasons.append({"code": "SURFACE_UNVERIFIABLE", "surface_id": surface["id"], "path": surface["path"], "reason": surface.get("reason")})
        elif state == "failed":
            hard_failure = True
            reasons.append({"code": "SURFACE_FAILED", "surface_id": surface["id"], "path": surface["path"], "reason": surface.get("reason")})
        elif state == "excluded":
            uncertainty = True
            reasons.append({"code": "MANDATORY_SURFACE_EXCLUDED", "surface_id": surface["id"], "path": surface["path"], "reason": surface.get("reason")})
    if ledger is not None and not any(check.get("kind") == "finding_verifier" or check.get("id") == "CHK-FINDINGS-VERIFIER" for check in manifest["checks"]):
        uncertainty = True
        reasons.append({"code": "FINDINGS_VERIFIER_MISSING"})
    for check in manifest["checks"]:
        if not check.get("required", False):
            continue
        execution = check.get("execution_status")
        result = check.get("result")
        if execution in {"pending", "could_not_run", "skipped"}:
            uncertainty = True
            reasons.append({"code": "REQUIRED_CHECK_INCOMPLETE", "check_id": check["id"], "status": execution})
        elif execution == "failed":
            hard_failure = True
            reasons.append({"code": "REQUIRED_CHECK_FAILED_TO_EXECUTE", "check_id": check["id"]})
        if result == "candidates":
            uncertainty = True
            reasons.append({"code": "REQUIRED_CHECK_CANDIDATES_UNADJUDICATED", "check_id": check["id"]})
        if result == "fails" and check.get("blocking", False):
            hard_failure = True
            reasons.append({"code": "BLOCKING_CHECK_FAILED", "check_id": check["id"]})
        elif result == "fails":
            uncertainty = True
            reasons.append({"code": "REQUIRED_CHECK_FAILED", "check_id": check["id"]})
    open_critical = 0
    open_high = 0
    accepted_critical = 0
    accepted_high = 0
    not_rechecked_material = 0
    if ledger is not None:
        for finding in ledger["findings"]:
            status = finding.get("status")
            severity = finding.get("severity")
            if status in {"open", "regressed"} and severity == "CRITICAL":
                open_critical += 1
            elif status in {"open", "regressed"} and severity == "HIGH":
                open_high += 1
            elif status == "accepted" and severity == "CRITICAL":
                accepted_critical += 1
            elif status == "accepted" and severity == "HIGH":
                accepted_high += 1
            elif status == "not_rechecked" and severity in {"CRITICAL", "HIGH"}:
                not_rechecked_material += 1
        if open_critical:
            hard_failure = True
            reasons.append({"code": "OPEN_CRITICAL", "count": open_critical})
        if open_high:
            hard_failure = True
            reasons.append({"code": "OPEN_HIGH", "count": open_high})
        if accepted_critical:
            hard_failure = True
            reasons.append({"code": "ACCEPTED_CRITICAL", "count": accepted_critical})
        if accepted_high:
            uncertainty = True
            reasons.append({"code": "ACCEPTED_HIGH", "count": accepted_high})
        if not_rechecked_material:
            hard_failure = True
            reasons.append({"code": "MATERIAL_FINDING_NOT_RECHECKED", "count": not_rechecked_material})
    track = manifest["track"]
    if hard_failure:
        verdict = "NOT_READY" if track in {"REPORT", "HYBRID", "DIFFERENTIAL"} else "BLOCKED"
    elif uncertainty:
        verdict = "CONDITIONAL"
    else:
        verdict = "READY"
    mandatory = [s for s in manifest["surfaces"] if s.get("mandatory", True)]
    state_counts = Counter(surface["state"] for surface in mandatory)
    reviewed = state_counts.get("reviewed", 0)
    coverage = 1.0 if not mandatory else reviewed / len(mandatory)
    coverage_record = {
        "mandatory_total": len(mandatory),
        "reviewed": reviewed,
        "excluded": state_counts.get("excluded", 0),
        "cannot_verify": state_counts.get("cannot_verify", 0),
        "failed": state_counts.get("failed", 0),
        "pending": state_counts.get("pending", 0),
        "rate": round(coverage, 6),
        "notes": [],
    }
    receipt = {
        "schema_version": SCHEMA_VERSION, "generated_at": utc_now(), "run_id": manifest["run_id"],
        "target_fingerprint": manifest["target"]["fingerprint"],
        "track": track, "verdict": verdict, "coverage_rate": round(coverage, 6),
        "coverage": coverage_record,
        "mandatory_surfaces": len(mandatory), "reviewed_mandatory_surfaces": reviewed,
        "open_critical": open_critical, "open_high": open_high,
        "accepted_critical": accepted_critical, "accepted_high": accepted_high,
        "not_rechecked_material": not_rechecked_material,
        "reasons": reasons,
        "manifest_sha256": None,
        "candidate_ledger_path": None, "candidate_ledger_sha256": None,
        "verifier_receipt_path": None, "verifier_receipt_sha256": None,
    }
    validate_gate_receipt(receipt)
    return receipt


def load_rule_packs() -> dict[str, dict[str, Any]]:
    packs: dict[str, dict[str, Any]] = {}
    rule_ids: set[str] = set()
    if not RULES_DIR.exists():
        return packs
    for path in sorted(RULES_DIR.glob("*.json")):
        pack = load_json(path)
        validate_rule_pack(pack)
        if pack["id"] in packs:
            raise ValueError(f"duplicate rule pack id: {pack['id']}")
        overlap = rule_ids & {rule["id"] for rule in pack["rules"]}
        if overlap:
            raise ValueError("duplicate rule ids across packs: " + ", ".join(sorted(overlap)))
        rule_ids.update(rule["id"] for rule in pack["rules"])
        packs[pack["id"]] = pack
    return packs


def assert_output_outside_target(output: Path | None, target_path: Path, target_kind: str, label: str) -> None:
    if output is None:
        return
    output = output.expanduser().resolve(strict=False)
    target = target_path.expanduser().resolve(strict=False)
    if output == target:
        raise ValueError(f"{label} cannot overwrite the reviewed target")
    if target_kind in {"directory", "missing"}:
        try:
            output.relative_to(target)
        except ValueError:
            return
        raise ValueError(f"{label} must be outside the reviewed directory")


def assert_output_not_bound_evidence(
    output: Path | None, manifest: dict[str, Any], base_dir: Path, label: str,
    extra_references: Iterable[Any] = (),
) -> None:
    if output is None:
        return
    destination = output.expanduser().resolve(strict=False)
    references = [
        str(reference)
        for record in [*manifest.get("surfaces", []), *manifest.get("checks", [])]
        for reference in record.get("evidence", [])
    ] + [str(reference) for reference in extra_references]
    for reference in references:
        location = reference.split("#", 1)[0]
        if not location or re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", location):
            continue
        evidence = Path(location).expanduser()
        if not evidence.is_absolute():
            evidence = base_dir / evidence
        if destination == evidence.resolve(strict=False):
            raise ValueError(f"{label} cannot overwrite bound evidence")


def output_data(data: Any, output: Path | None) -> None:
    if output:
        atomic_json(output, data)
        print(output.resolve())
    else:
        print(json.dumps(data, indent=2, ensure_ascii=True))


def command_manifest(args: argparse.Namespace) -> None:
    target = Path(os.path.abspath(os.path.expanduser(args.target)))
    output = Path(args.output).expanduser().resolve()
    if output == target.resolve(strict=False):
        raise ValueError("manifest output cannot overwrite the review target")
    try:
        output.relative_to(target.resolve(strict=False))
    except ValueError:
        pass
    else:
        raise ValueError("manifest output must be outside the reviewed target scope")
    manifest = build_manifest(target, args.mode, args.track, args.evidence_ceiling, args.max_file_bytes, args.ref, args.base, args.head, args.max_surfaces)
    atomic_json(output, manifest)
    print(output.resolve())


def command_probe(args: argparse.Namespace) -> None:
    manifest = probe_manifest(Path(args.manifest), Path(args.output) if args.output else None, Path(args.receipts))
    print(json.dumps({"run_id": manifest["run_id"], "checks": len(manifest["checks"]), "receipts": str(Path(args.receipts).resolve())}, indent=2))


def command_validate(args: argparse.Namespace) -> None:
    path = Path(args.path)
    data = load_json(path)
    kind = args.kind
    if kind == "auto":
        if "surfaces" in data and "target" in data:
            kind = "manifest"
        elif "findings" in data:
            kind = "ledger"
        elif "rules" in data and "applies_to" in data:
            kind = "rules"
        elif "verifier_version" in data and "manifest_fingerprint" in data:
            kind = "verifier"
        elif "target_fingerprint" in data and "coverage" in data and "verdict" in data and "reasons" in data:
            kind = "gate"
        elif "adapter" in data and "artifact" in data and "execution_status" in data:
            kind = "receipt"
        else:
            raise ValueError("could not infer JSON kind")
    if kind == "manifest":
        validate_manifest(data)
    elif kind == "ledger":
        validate_ledger(data, strict_v7=args.strict)
    elif kind == "rules":
        validate_rule_pack(data)
    elif kind == "receipt":
        validate_receipt(data)
    elif kind == "verifier":
        validate_verifier_receipt(data)
    elif kind == "gate":
        validate_gate_receipt(data, require_bindings=True)
    else:
        raise ValueError(f"unknown validation kind: {kind}")
    print(f"VALID {kind}: {path.resolve()}")


def command_mark(args: argparse.Namespace) -> None:
    manifest = mark_surface(Path(args.manifest), args.surface, args.state, args.reason, args.evidence or [])
    print(json.dumps(manifest["stats"], indent=2))


def command_check(args: argparse.Namespace) -> None:
    manifest = record_check(Path(args.manifest), args.id, args.execution, args.result, args.required, args.blocking, args.scope, args.evidence or [], args.reason)
    print(json.dumps(manifest["stats"], indent=2))


def command_gate(args: argparse.Namespace) -> None:
    manifest_path = Path(args.manifest).expanduser().resolve()
    ledger_path = Path(args.ledger).expanduser().resolve() if args.ledger else None
    output = Path(args.output).expanduser().resolve() if args.output else None
    if output is not None and output in {manifest_path, ledger_path}:
        raise ValueError("gate output cannot overwrite its manifest or ledger")
    manifest = load_json(manifest_path)
    assert_output_outside_target(output, Path(manifest["target"]["designated_path"]), manifest["target"]["kind"], "gate output")
    assert_output_not_bound_evidence(output, manifest, manifest_path.parent, "gate output")
    ledger = load_json(ledger_path) if ledger_path else None
    gate = coverage_gate(manifest, ledger)
    gate["manifest_sha256"] = sha256_file(manifest_path)
    if ledger is not None:
        verifier_checks = [
            check for check in manifest["checks"]
            if check.get("id") == "CHK-FINDINGS-VERIFIER" or check.get("kind") == "finding_verifier"
        ]
        if len(verifier_checks) == 1 and verifier_checks[0].get("execution_status") == "completed" and verifier_checks[0].get("result") == "holds":
            gate.update(validate_bound_verifier(manifest, ledger, manifest_path.parent))
    validate_gate_receipt(gate, require_bindings=True)
    output_data(gate, output)


def command_compare(args: argparse.Namespace) -> None:
    old_path = Path(args.old).expanduser().resolve()
    new_path = Path(args.new).expanduser().resolve()
    output = Path(args.output).expanduser().resolve() if args.output else None
    if output is not None and output in {old_path, new_path}:
        raise ValueError("delta output cannot overwrite an input ledger")
    old_ledger = load_json(old_path)
    new_ledger = load_json(new_path)
    for ledger, ledger_path in ((old_ledger, old_path), (new_ledger, new_path)):
        finding_evidence = [reference for finding in ledger.get("findings", []) for reference in finding.get("evidence_refs", [])]
        assert_output_not_bound_evidence(
            output, {"surfaces": [], "checks": ledger.get("checks", [])}, ledger_path.parent,
            "delta output", finding_evidence,
        )
        artifact_value = ledger.get("artifact_path")
        if artifact_value:
            artifact = Path(artifact_value).expanduser()
            assert_output_outside_target(output, artifact, "directory" if artifact.is_dir() else "file", "delta output")
        manifest_value = ledger.get("manifest_path")
        if manifest_value:
            manifest_candidate = Path(manifest_value).expanduser()
            if not manifest_candidate.is_absolute():
                manifest_candidate = ledger_path.parent / manifest_candidate
            if manifest_candidate.is_file():
                bound = load_json(manifest_candidate)
                assert_output_outside_target(output, Path(bound["target"]["designated_path"]), bound["target"]["kind"], "delta output")
                assert_output_not_bound_evidence(output, bound, manifest_candidate.parent, "delta output")
    delta = compare_ledgers(old_ledger, new_ledger)
    output_data(delta, output)


def command_verify(args: argparse.Namespace) -> None:
    manifest_path = Path(args.manifest).expanduser().resolve()
    ledger_path = Path(args.ledger).expanduser().resolve()
    output = Path(args.output).expanduser().resolve()
    if output in {manifest_path, ledger_path}:
        raise ValueError("verifier receipt cannot overwrite its manifest or ledger")
    manifest = load_json(manifest_path)
    designated = Path(manifest["target"]["designated_path"])
    assert_output_outside_target(output, designated, manifest["target"]["kind"], "verifier receipt")
    assert_output_not_bound_evidence(output, manifest, manifest_path.parent, "verifier receipt")
    receipt = verify_findings(manifest, load_json(ledger_path), sha256_file(ledger_path))
    validate_verifier_receipt(receipt)
    atomic_json(output, receipt)
    if args.update_manifest:
        check = {
            "id": "CHK-FINDINGS-VERIFIER", "kind": "finding_verifier",
            "required": True, "blocking": True, "execution_status": "completed",
            "result": receipt["result"], "scope": f"{receipt['findings_total']} ledger findings",
            "evidence": [str(output), str(ledger_path)], "started_at": receipt["started_at"],
            "completed_at": receipt["completed_at"],
        }
        by_id = {item["id"]: item for item in manifest["checks"]}
        by_id[check["id"]] = check
        manifest["checks"] = list(by_id.values())
        manifest["updated_at"] = utc_now()
        manifest["status"] = derive_manifest_status(manifest["surfaces"], manifest["checks"])
        manifest["stats"] = manifest_stats(manifest["surfaces"], manifest["checks"])
        validate_manifest(manifest)
        atomic_json(manifest_path, manifest)
    print(output)


def command_fingerprint(args: argparse.Namespace) -> None:
    data = {"location": args.location, "rule_id": args.rule, "quote": args.quote, "root_cause": args.root_cause, "title": args.title}
    print(finding_fingerprint(data))


def command_inspect_html(args: argparse.Namespace) -> None:
    target = Path(args.path).expanduser().resolve(strict=False)
    output = Path(args.output).expanduser().resolve() if args.output else None
    if output == target:
        raise ValueError("receipt output cannot overwrite the inspected artifact")
    output_data(inspect_html(target), output)


def command_inspect_workbook(args: argparse.Namespace) -> None:
    target = Path(args.path).expanduser().resolve(strict=False)
    output = Path(args.output).expanduser().resolve() if args.output else None
    if output == target:
        raise ValueError("receipt output cannot overwrite the inspected artifact")
    output_data(inspect_workbook(target), output)


def command_inspect_artifact(args: argparse.Namespace) -> None:
    target = Path(args.path).expanduser().resolve(strict=False)
    output = Path(args.output).expanduser().resolve() if args.output else None
    if output == target:
        raise ValueError("receipt output cannot overwrite the inspected artifact")
    classification = classify_file(target)
    adapter = classification["adapter"]
    inspectors = {
        "html": inspect_html, "workbook": inspect_workbook, "document": inspect_document,
        "media": inspect_media, "archive-binary": inspect_archive_binary,
        "generic-file": inspect_archive_binary, "code": inspect_text,
        "data-config": inspect_text, "instruction": inspect_text, "generic-text": inspect_text,
    }
    inspector = inspectors.get(adapter)
    if inspector is None:
        raise ValueError(f"no static artifact inspector for adapter {adapter}")
    receipt = inspector(target)
    if classification.get("extension_magic_mismatch"):
        receipt.setdefault("issues", []).append({
            "rule_id": "BIN-TYPE", "kind": "extension_magic_mismatch",
            "extension": classification.get("extension"), "magic": classification.get("magic"),
        })
        if receipt.get("execution_status") == "completed":
            receipt["result"] = "candidates"
    validate_receipt(receipt)
    output_data(receipt, output)


def command_rules(args: argparse.Namespace) -> None:
    packs = load_rule_packs()
    output = Path(args.output).expanduser().resolve() if args.output else None
    if output is not None and output in {path.resolve() for path in RULES_DIR.glob("*.json")}:
        raise ValueError("rules output cannot overwrite a first-party rule pack")
    selected: list[str]
    if args.manifest:
        manifest_path = Path(args.manifest).expanduser().resolve()
        if output == manifest_path:
            raise ValueError("rules output cannot overwrite the manifest")
        manifest = load_json(manifest_path)
        validate_manifest(manifest)
        assert_output_outside_target(output, Path(manifest["target"]["designated_path"]), manifest["target"]["kind"], "rules output")
        assert_output_not_bound_evidence(output, manifest, manifest_path.parent, "rules output")
        selected = manifest.get("rule_packs", [])
    elif args.adapter:
        selected = PACKS_BY_ADAPTER.get(args.adapter, ["gauntlet.core"])
    else:
        selected = sorted(packs)
    data = [{"id": pack_id, "available": pack_id in packs, "version": packs.get(pack_id, {}).get("version"), "rules": len(packs.get(pack_id, {}).get("rules", []))} for pack_id in selected]
    output_data(data, output)


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="gauntlet-engine", description=__doc__)
    root.add_argument("--version", action="version", version=f"Gauntlet engine {ENGINE_VERSION}")
    sub = root.add_subparsers(dest="command", required=True)

    p = sub.add_parser("manifest", help="create a universal review manifest")
    p.add_argument("target")
    p.add_argument("-o", "--output", required=True)
    p.add_argument("--mode", choices=["auto", "full", "workspace", "commit", "range"], default="full")
    p.add_argument("--track", choices=sorted(TRACKS), default="UNDECIDED")
    p.add_argument("--evidence-ceiling", choices=sorted(EVIDENCE_CEILINGS), default="shell")
    p.add_argument("--ref", help="commit for commit mode")
    p.add_argument("--base", help="base ref for range mode")
    p.add_argument("--head", help="head ref for range mode")
    p.add_argument("--max-file-bytes", type=int, default=DEFAULT_MAX_FILE_BYTES)
    p.add_argument("--max-surfaces", type=int, default=DEFAULT_MAX_SURFACES)
    p.set_defaults(func=command_manifest)

    p = sub.add_parser("probe", help="run safe static probes and update a manifest")
    p.add_argument("manifest")
    p.add_argument("--receipts", required=True)
    p.add_argument("-o", "--output")
    p.set_defaults(func=command_probe)

    p = sub.add_parser("validate", help="validate a manifest, ledger, rule pack, check receipt, or verifier receipt")
    p.add_argument("path")
    p.add_argument("--kind", choices=["auto", "manifest", "ledger", "rules", "receipt", "verifier", "gate"], default="auto")
    p.add_argument("--strict", action=argparse.BooleanOptionalAction, default=True)
    p.set_defaults(func=command_validate)

    p = sub.add_parser("mark", help="set a manifest surface state")
    p.add_argument("manifest")
    p.add_argument("--surface", required=True, help="surface id or exact manifest path")
    p.add_argument("--state", choices=sorted(SURFACE_STATES), required=True)
    p.add_argument("--reason")
    p.add_argument("--evidence", action="append")
    p.set_defaults(func=command_mark)

    p = sub.add_parser("check", help="record or replace a check result")
    p.add_argument("manifest")
    p.add_argument("--id", required=True)
    p.add_argument("--execution", choices=sorted(EXECUTION_STATES), required=True)
    p.add_argument("--result", choices=sorted(CHECK_RESULTS), required=True)
    p.add_argument("--required", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--blocking", action=argparse.BooleanOptionalAction, default=False)
    p.add_argument("--scope", required=True)
    p.add_argument("--evidence", action="append")
    p.add_argument("--reason")
    p.set_defaults(func=command_check)

    p = sub.add_parser("gate", help="compute a coverage-aware release gate")
    p.add_argument("manifest")
    p.add_argument("--ledger")
    p.add_argument("-o", "--output")
    p.set_defaults(func=command_gate)

    p = sub.add_parser("compare", help="compare two finding ledgers")
    p.add_argument("old")
    p.add_argument("new")
    p.add_argument("-o", "--output")
    p.set_defaults(func=command_compare)

    p = sub.add_parser("verify", help="mechanically verify candidate findings and record the receipt")
    p.add_argument("manifest")
    p.add_argument("ledger")
    p.add_argument("-o", "--output", required=True)
    p.add_argument("--update-manifest", action=argparse.BooleanOptionalAction, default=True)
    p.set_defaults(func=command_verify)

    p = sub.add_parser("fingerprint", help="compute a stable finding fingerprint")
    p.add_argument("--location", required=True)
    p.add_argument("--rule", default="")
    p.add_argument("--quote", default="")
    p.add_argument("--root-cause", default="")
    p.add_argument("--title", default="")
    p.set_defaults(func=command_fingerprint)

    p = sub.add_parser("inspect-html", help="run the standalone HTML static adapter")
    p.add_argument("path")
    p.add_argument("-o", "--output")
    p.set_defaults(func=command_inspect_html)

    p = sub.add_parser("inspect-workbook", help="run the workbook structural adapter")
    p.add_argument("path")
    p.add_argument("-o", "--output")
    p.set_defaults(func=command_inspect_workbook)

    p = sub.add_parser("inspect-artifact", help="detect a file and run its safe first-party static adapter")
    p.add_argument("path")
    p.add_argument("-o", "--output")
    p.set_defaults(func=command_inspect_artifact)

    p = sub.add_parser("rules", help="show first-party rule packs")
    p.add_argument("--adapter")
    p.add_argument("--manifest")
    p.add_argument("-o", "--output")
    p.set_defaults(func=command_rules)
    return root


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        args.func(args)
        return 0
    except (ValueError, OSError, subprocess.SubprocessError, zipfile.BadZipFile) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
