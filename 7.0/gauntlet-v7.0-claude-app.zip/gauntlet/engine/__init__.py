"""First-party deterministic support engine for Gauntlet."""

__version__ = "7.0.0"
