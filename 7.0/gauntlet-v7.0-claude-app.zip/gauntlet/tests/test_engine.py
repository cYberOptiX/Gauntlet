from __future__ import annotations

import hashlib
import json
import os
import struct
import subprocess
import sys
import tempfile
import unittest
import zipfile
import zlib
from pathlib import Path
from types import SimpleNamespace

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT))

from engine import gauntlet


class TempCase(unittest.TestCase):
    def setUp(self):
        self._temp = tempfile.TemporaryDirectory()
        self.root = Path(self._temp.name)

    def tearDown(self):
        self._temp.cleanup()


class ManifestTests(TempCase):
    def test_full_manifest_accounts_for_files_sensitive_paths_and_excluded_trees(self):
        (self.root / "app.py").write_text("print('ok')\n")
        (self.root / "page.html").write_text("<!doctype html><title>x</title>")
        (self.root / ".env").write_text("TOKEN='example-value-not-real'\n")
        (self.root / "node_modules" / "pkg").mkdir(parents=True)
        (self.root / "node_modules" / "pkg" / "index.js").write_text("module.exports = 1")
        (self.root / "large.bin").write_bytes(b"x" * 128)

        manifest = gauntlet.build_manifest(
            self.root, "full", "REPORT", "full", 64, None, None, None
        )
        gauntlet.validate_manifest(manifest)
        by_path = {item["path"]: item for item in manifest["surfaces"]}

        self.assertEqual(by_path["app.py"]["adapter"], "code")
        self.assertEqual(by_path["page.html"]["adapter"], "html")
        self.assertEqual(by_path[".env"]["handling"], "local_only")
        self.assertEqual(by_path["large.bin"]["state"], "cannot_verify")
        self.assertEqual(by_path["large.bin"]["reason"], "size_limit")
        self.assertEqual(by_path["node_modules/"]["state"], "excluded")
        self.assertTrue(by_path["node_modules/"]["covers_subtree"])
        self.assertNotIn("node_modules/pkg/index.js", by_path)
        self.assertEqual(len(manifest["target"]["fingerprint"]), 64)
        self.assertIn("gauntlet.html", manifest["rule_packs"])
        self.assertIn("gauntlet.code", manifest["rule_packs"])

    def test_symlink_outside_root_is_not_followed(self):
        outside = self.root.parent / f"outside-{self.root.name}.txt"
        outside.write_text("private")
        try:
            (self.root / "outside-link").symlink_to(outside)
            manifest = gauntlet.build_manifest(self.root, "full", "REPORT", "shell", 1000, None, None, None)
            surface = next(item for item in manifest["surfaces"] if item["path"] == "outside-link")
            self.assertEqual(surface["adapter"], "symlink")
            self.assertTrue(surface["link_outside_root"])
            self.assertNotEqual(surface["sha256"], gauntlet.sha256_file(outside))
        finally:
            outside.unlink(missing_ok=True)

    def test_manifest_round_trip_validation(self):
        (self.root / "readme.md").write_text("# Target\n")
        manifest = gauntlet.build_manifest(self.root, "full", "REBUILD", "shell", 1000, None, None, None)
        path = self.root / "manifest.json"
        gauntlet.atomic_json(path, manifest)
        gauntlet.validate_manifest(gauntlet.load_json(path))

    def test_target_fingerprint_does_not_change_with_review_state(self):
        path = self.root / "target.md"
        path.write_text("target\n")
        manifest = gauntlet.build_manifest(path, "full", "REPORT", "shell", 1000, None, None, None)
        surface = manifest["surfaces"][0]
        before = manifest["target"]["fingerprint"]
        surface.update({"state": "reviewed", "evidence": ["semantic:test"]})
        target_data = {key: value for key, value in manifest["target"].items() if key != "fingerprint"}
        after = gauntlet.target_fingerprint(target_data, manifest["surfaces"], manifest["git"])
        self.assertEqual(before, after)

    def test_manifest_status_is_derived_from_surface_and_check_state(self):
        target = self.root / "target.md"
        target.write_text("target\n")
        manifest = gauntlet.build_manifest(target, "full", "REPORT", "shell", 1000, None, None, None)
        manifest_path = self.root / "run-manifest.json"
        gauntlet.atomic_json(manifest_path, manifest)
        gauntlet.mark_surface(manifest_path, manifest["surfaces"][0]["id"], "reviewed", None, ["semantic:test"])
        self.assertEqual(gauntlet.load_json(manifest_path)["status"], "in_progress")
        gauntlet.record_check(manifest_path, "CHK-FINDINGS-VERIFIER", "completed", "holds", True, True, "ledger", ["verifier:test"], None)
        self.assertEqual(gauntlet.load_json(manifest_path)["status"], "complete")

    def test_record_check_preserves_probe_metadata_during_adjudication(self):
        target = self.root / "target.md"
        target.write_text("target\n")
        manifest = gauntlet.build_manifest(target, "full", "REPORT", "shell", 1000, None, None, None)
        surface_id = manifest["surfaces"][0]["id"]
        manifest["checks"].insert(0, {
            "id": "CHK-STATIC-TEST", "kind": "adapter:text", "required": True, "blocking": False,
            "execution_status": "completed", "result": "candidates", "scope": "target.md",
            "surface_ids": [surface_id], "candidate_count": 1, "started_at": "2026-01-01T00:00:00Z",
            "completed_at": "2026-01-01T00:00:01Z", "evidence": ["receipt:test"],
        })
        manifest_path = self.root / "run-manifest.json"
        gauntlet.atomic_json(manifest_path, manifest)

        gauntlet.record_check(
            manifest_path, "CHK-STATIC-TEST", "completed", "holds", True, False,
            "target.md", ["receipt:test", "adjudication:test"], "candidates adjudicated",
        )
        check = next(item for item in gauntlet.load_json(manifest_path)["checks"] if item["id"] == "CHK-STATIC-TEST")
        self.assertEqual(check["kind"], "adapter:text")
        self.assertEqual(check["surface_ids"], [surface_id])
        self.assertEqual(check["candidate_count"], 1)
        self.assertEqual(check["prior_result"], "candidates")
        self.assertEqual(check["adjudication_kind"], "manual_or_external")

        gauntlet.record_check(
            manifest_path, "CHK-STATIC-TEST", "completed", "holds", True, False,
            "target.md", ["receipt:test", "adjudication:test"], "adjudication re-recorded",
        )
        check = next(item for item in gauntlet.load_json(manifest_path)["checks"] if item["id"] == "CHK-STATIC-TEST")
        self.assertEqual(check["prior_result"], "candidates")

    def test_gate_command_hash_binds_manifest_candidate_ledger_and_verifier(self):
        target = self.root / "target"
        run = self.root / "run"
        target.mkdir()
        run.mkdir()
        (target / "artifact.txt").write_text("reviewed\n")
        manifest = gauntlet.build_manifest(target, "full", "REPORT", "shell", 1000, None, None, None)
        manifest["surfaces"][0].update({"state": "reviewed", "evidence": ["semantic:test"]})
        manifest["status"] = gauntlet.derive_manifest_status(manifest["surfaces"], manifest["checks"])
        manifest["stats"] = gauntlet.manifest_stats(manifest["surfaces"], manifest["checks"])
        manifest_path = run / "manifest.json"
        ledger_path = run / "candidate-ledger.json"
        verifier_path = run / "verifier.json"
        gate_path = run / "gate.json"
        gauntlet.atomic_json(manifest_path, manifest)
        gauntlet.atomic_json(ledger_path, {
            "schema_version": "7.0", "run_id": manifest["run_id"],
            "target_fingerprint": manifest["target"]["fingerprint"],
            "manifest_path": str(manifest_path), "findings": [],
        })
        gauntlet.command_verify(SimpleNamespace(
            manifest=str(manifest_path), ledger=str(ledger_path), output=str(verifier_path), update_manifest=True,
        ))
        gauntlet.command_gate(SimpleNamespace(
            manifest=str(manifest_path), ledger=str(ledger_path), output=str(gate_path),
        ))
        gate = gauntlet.load_json(gate_path)
        self.assertEqual(gate["verdict"], "READY")
        self.assertEqual(gate["manifest_sha256"], gauntlet.sha256_file(manifest_path))
        self.assertEqual(gate["candidate_ledger_sha256"], gauntlet.sha256_file(ledger_path))
        self.assertEqual(gate["verifier_receipt_sha256"], gauntlet.sha256_file(verifier_path))
        with self.assertRaisesRegex(ValueError, "cannot overwrite bound evidence"):
            gauntlet.command_gate(SimpleNamespace(
                manifest=str(manifest_path), ledger=str(ledger_path), output=str(verifier_path),
            ))

        candidate = gauntlet.load_json(ledger_path)
        candidate["tampered"] = True
        gauntlet.atomic_json(ledger_path, candidate)
        with self.assertRaisesRegex(ValueError, "ledger hash mismatch"):
            gauntlet.command_gate(SimpleNamespace(
                manifest=str(manifest_path), ledger=str(ledger_path), output=str(gate_path),
            ))

    def test_output_guard_rejects_target_and_directory_descendant(self):
        target = self.root / "target"
        target.mkdir()
        with self.assertRaisesRegex(ValueError, "outside the reviewed directory"):
            gauntlet.assert_output_outside_target(target / "receipt.json", target, "directory", "receipt")
        reviewed_file = target / "artifact.txt"
        reviewed_file.write_text("artifact")
        with self.assertRaisesRegex(ValueError, "cannot overwrite"):
            gauntlet.assert_output_outside_target(reviewed_file, reviewed_file, "file", "receipt")

    def test_unreadable_directory_is_accounted_for_or_explicitly_accessible(self):
        restricted = self.root / "restricted"
        restricted.mkdir()
        (restricted / "inside.txt").write_text("inside")
        restricted.chmod(0)
        try:
            manifest = gauntlet.build_manifest(self.root, "full", "REPORT", "shell", 1000, None, None, None)
        finally:
            restricted.chmod(0o700)
        paths = {surface["path"]: surface for surface in manifest["surfaces"]}
        if "restricted/" in paths:
            self.assertEqual(paths["restricted/"]["state"], "cannot_verify")
            self.assertTrue(paths["restricted/"]["covers_subtree"])
        else:
            self.assertIn("restricted/inside.txt", paths)

    def test_manifest_surface_budget_fails_closed(self):
        (self.root / "one.txt").write_text("one")
        (self.root / "two.txt").write_text("two")
        with self.assertRaisesRegex(ValueError, "surface limit exceeded"):
            gauntlet.build_manifest(self.root, "full", "REPORT", "shell", 1000, None, None, None, 1)

    def test_probe_requires_a_fresh_receipts_directory(self):
        target = self.root / "target"
        run = self.root / "run"
        target.mkdir()
        run.mkdir()
        (target / "app.py").write_text("value = 1\n")
        manifest = gauntlet.build_manifest(target, "full", "REPORT", "shell", 1000, None, None, None)
        manifest_path = run / "manifest.json"
        gauntlet.atomic_json(manifest_path, manifest)
        gauntlet.probe_manifest(manifest_path, None, run / "receipts")
        with self.assertRaisesRegex(ValueError, "receipts directory must be empty"):
            gauntlet.probe_manifest(manifest_path, None, run / "receipts")

    def test_probe_rejects_target_changed_after_manifest(self):
        target = self.root / "target"
        run = self.root / "run"
        target.mkdir()
        run.mkdir()
        source = target / "app.py"
        source.write_text("value = 1\n")
        manifest = gauntlet.build_manifest(target, "full", "REPORT", "shell", 1000, None, None, None)
        manifest_path = run / "manifest.json"
        gauntlet.atomic_json(manifest_path, manifest)
        source.write_text("value = 2\n")
        with self.assertRaisesRegex(ValueError, "target changed since manifest"):
            gauntlet.probe_manifest(manifest_path, None, run / "receipts")


class GitScopeTests(TempCase):
    def git(self, *args: str) -> str:
        result = subprocess.run(["git", "-C", str(self.root), *args], check=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return result.stdout.strip()

    def setUp(self):
        super().setUp()
        self.git("init", "-q")
        self.git("config", "user.email", "fixture@example.invalid")
        self.git("config", "user.name", "Fixture")
        (self.root / "kept.txt").write_text("one\n")
        (self.root / "deleted.txt").write_text("delete me\n")
        self.git("add", ".")
        self.git("commit", "-qm", "base")
        self.base = self.git("rev-parse", "HEAD")

    def test_workspace_mode_includes_modified_deleted_and_untracked(self):
        (self.root / "kept.txt").write_text("two\n")
        (self.root / "deleted.txt").unlink()
        (self.root / "new.py").write_text("value = 1\n")
        manifest = gauntlet.build_manifest(self.root, "workspace", "DIFFERENTIAL", "full", 1000, None, None, None)
        by_path = {item["path"]: item for item in manifest["surfaces"]}
        self.assertEqual(set(by_path), {"deleted.txt", "kept.txt", "new.py"})
        self.assertEqual(by_path["deleted.txt"]["change"]["status"], "D")
        self.assertEqual(by_path["new.py"]["change"]["sources"], ["untracked"])
        self.assertEqual(manifest["git"]["mode"], "workspace")

    def test_range_mode_uses_merge_base_and_exact_changed_files(self):
        (self.root / "feature.py").write_text("first = True\n")
        self.git("add", ".")
        self.git("commit", "-qm", "feature")
        head = self.git("rev-parse", "HEAD")
        (self.root / "feature.py").write_text("dirty_worktree = True\n")
        manifest = gauntlet.build_manifest(self.root, "range", "DIFFERENTIAL", "full", 1000, None, self.base, head)
        self.assertEqual([item["path"] for item in manifest["surfaces"]], ["feature.py"])
        surface = manifest["surfaces"][0]
        self.assertEqual(manifest["git"]["merge_base"], self.base)
        self.assertEqual(surface["content_source"], "git_blob")
        self.assertEqual(surface["sha256"], hashlib.sha256(b"first = True\n").hexdigest())
        self.assertNotEqual(surface["sha256"], gauntlet.sha256_file(self.root / "feature.py"))
        with tempfile.TemporaryDirectory() as run_dir:
            run = Path(run_dir)
            manifest_path = run / "manifest.json"
            gauntlet.atomic_json(manifest_path, manifest)
            probed = gauntlet.probe_manifest(manifest_path, None, run / "receipts")
            check = next(check for check in probed["checks"] if check["kind"] == "local_text_probe")
            self.assertEqual(check["artifact_sha256"], surface["sha256"])
            self.assertFalse(any(path.name.startswith(f".{surface['id']}-") for path in (run / "receipts").iterdir()))

    def test_scoped_workspace_keeps_rename_out_as_deletion(self):
        scoped = self.root / "scoped"
        scoped.mkdir()
        (scoped / "move.txt").write_text("move me\n")
        self.git("add", ".")
        self.git("commit", "-qm", "add scoped file")
        self.git("mv", "scoped/move.txt", "moved-out.txt")
        manifest = gauntlet.build_manifest(scoped, "workspace", "DIFFERENTIAL", "full", 1000, None, None, None)
        self.assertEqual(len(manifest["surfaces"]), 1)
        surface = manifest["surfaces"][0]
        self.assertEqual(surface["path"], "scoped/move.txt")
        self.assertEqual(surface["change"]["status"], "D")
        self.assertEqual(surface["change"]["renamed_to"], "moved-out.txt")
        self.assertEqual(surface["content_source"], "git_blob")

    @unittest.skipIf(os.name == "nt", "byte filenames are POSIX-specific")
    def test_non_utf8_git_path_is_preserved_in_valid_json(self):
        raw_path = os.fsencode(self.root) + b"/byte-\xff.txt"
        try:
            descriptor = os.open(raw_path, os.O_WRONLY | os.O_CREAT, 0o600)
        except OSError as exc:
            self.skipTest(f"filesystem rejects non-UTF-8 names: {type(exc).__name__}")
        os.write(descriptor, b"one\n")
        os.close(descriptor)
        self.git("add", "-A")
        self.git("commit", "-qm", "byte path")
        descriptor = os.open(raw_path, os.O_WRONLY | os.O_TRUNC)
        os.write(descriptor, b"two\n")
        os.close(descriptor)
        manifest = gauntlet.build_manifest(self.root, "workspace", "DIFFERENTIAL", "full", 1000, None, None, None)
        surface = next(item for item in manifest["surfaces"] if os.fsencode(item["path"]) == b"byte-\xff.txt")
        output = self.root.parent / "byte-path-manifest.json"
        try:
            gauntlet.atomic_json(output, manifest)
            loaded = gauntlet.load_json(output)
            self.assertTrue(any(os.fsencode(item["path"]) == b"byte-\xff.txt" for item in loaded["surfaces"]))
            self.assertEqual(surface["sha256"], hashlib.sha256(b"two\n").hexdigest())
        finally:
            output.unlink(missing_ok=True)

    def test_workspace_mode_preserves_rename_identity_and_space_in_path(self):
        self.git("mv", "kept.txt", "renamed file.txt")
        manifest = gauntlet.build_manifest(self.root, "workspace", "DIFFERENTIAL", "full", 1000, None, None, None)
        renamed = next(item for item in manifest["surfaces"] if item["path"] == "renamed file.txt")
        self.assertEqual(renamed["change"]["status"], "R")
        self.assertEqual(renamed["change"]["old_path"], "kept.txt")
        self.assertIn("staged", renamed["change"]["sources"])


class HTMLAdapterTests(TempCase):
    def test_url_evidence_removes_credentials_queries_and_opaque_segments(self):
        value = gauntlet.sanitize_url("https://user:password@example.invalid/assets/abcdefghijklmnopqrstuvwxyz123456?token=secret#part")
        self.assertEqual(value, "https://example.invalid/assets/[redacted]")
        self.assertNotIn("password", value)
        self.assertNotIn("token", value)

    def test_adapter_size_limit_is_could_not_run_not_failure(self):
        page = self.root / "oversized.html"
        with page.open("wb") as handle:
            handle.truncate(gauntlet.MAX_STATIC_TEXT_BYTES + 1)
        receipt = gauntlet.inspect_html(page)
        self.assertEqual(receipt["execution_status"], "could_not_run")
        self.assertEqual(receipt["result"], "unknown")
        gauntlet.validate_receipt(receipt)

    def test_static_html_probe_finds_structural_and_delivery_candidates(self):
        page = self.root / "target.html"
        page.write_text("""<!doctype html>
<html><body>
<div id="same"></div><span id="same"></span>
<input id="email">
<script type="module" src="https://cdn.example.invalid/app.js"></script>
<script>fetch('/data.json'); console.log('TODO');</script>
</body></html>""")
        receipt = gauntlet.inspect_html(page)
        ids = {item["rule_id"] for item in receipt["issues"]}
        detectors = {item.get("detector_id") for item in receipt["issues"]}
        self.assertEqual(receipt["execution_status"], "completed")
        self.assertEqual(receipt["result"], "candidates")
        self.assertIn("HTML-A11Y", ids)
        self.assertIn("HTML-OFFLINE", ids)
        self.assertIn("SLOP-LEFTOVER", ids)
        for detector in ("HTML-DUPLICATE-ID", "HTML-CONTROL-NAME", "HTML-EXTERNAL-RESOURCE", "HTML-FILE-MODULE", "HTML-FETCH-FILE", "SLOP-PLACEHOLDER", "SLOP-DEBUG-LOG"):
            self.assertIn(detector, detectors)
        gauntlet.validate_receipt(receipt)

    def test_html_probe_detects_secret_and_dynamic_html_without_exporting_value(self):
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        page = self.root / "target.html"
        page.write_text(f'<div id="out"></div><script>const key="{secret}"; out.innerHTML=location.hash;</script>')
        receipt = gauntlet.inspect_html(page)
        ids = {item["rule_id"] for item in receipt["issues"]}
        detectors = {item.get("detector_id") for item in receipt["issues"]}
        self.assertIn("CORE-SECRET", ids)
        self.assertIn("SECRET-STRIPE-LIVE", detectors)
        self.assertIn("HTML-INJECTION", ids)
        self.assertNotIn(secret, json.dumps(receipt))

    def test_utf16_text_probe_detects_and_redacts_secret(self):
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        path = self.root / "utf16.txt"
        path.write_bytes(f'key={secret}\n'.encode("utf-16"))
        receipt = gauntlet.inspect_text(path)
        self.assertTrue(any(issue.get("detector_id") == "SECRET-STRIPE-LIVE" for issue in receipt["issues"]))
        self.assertNotIn(secret, json.dumps(receipt))

    def test_environment_secret_assignment_is_detected_without_flagging_normal_variable(self):
        path = self.root / ".env"
        path.write_text("STRIPE_SECRET=fixturevalue123456\nsecret = bool(detected_secret_ids(text))\n")
        receipt = gauntlet.inspect_text(path)
        matches = [issue for issue in receipt["issues"] if issue.get("detector_id") == "SECRET-ENV-ASSIGNMENT"]
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["count"], 1)

    def test_explicitly_redacted_assignment_is_not_a_secret_candidate(self):
        path = self.root / "redacted.txt"
        path.write_text('password = "[REDACTED]"\n')
        receipt = gauntlet.inspect_text(path)
        self.assertFalse(any(issue.get("rule_id") == "CORE-SECRET" for issue in receipt["issues"]))

    def test_local_text_probe_redacts_secret_values(self):
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        path = self.root / "config.js"
        url_secret = "postgres://admin:FixturePassword@example.invalid/db"
        path.write_text(f'const key = "{secret}";\nconst database = "{url_secret}";\n')
        receipt = gauntlet.inspect_text(path)
        serialized = json.dumps(receipt)
        self.assertNotIn(secret, serialized)
        self.assertNotIn("FixturePassword", serialized)
        self.assertTrue(any(item["rule_id"] == "CORE-SECRET" and item.get("detector_id") == "SECRET-STRIPE-LIVE" for item in receipt["issues"]))
        self.assertTrue(any(item["rule_id"] == "CORE-SECRET" and item.get("detector_id") == "SECRET-URL-CREDENTIALS" for item in receipt["issues"]))
        self.assertTrue(all(item.get("values_redacted") for item in receipt["issues"]))
        self.assertEqual(receipt["artifact"]["sha256"], gauntlet.sha256_file(path))
        gauntlet.validate_receipt(receipt)


class WorkbookAdapterTests(TempCase):
    def make_xlsx(self, path: Path):
        workbook = """<?xml version="1.0" encoding="UTF-8"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="HiddenCalc" sheetId="1" state="hidden" r:id="rId1"/></sheets>
  <definedNames><definedName name="ExternalName">[1]Sheet1!$A$1</definedName></definedNames>
  <calcPr calcMode="manual"/>
</workbook>"""
        rels = """<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>"""
        sheet = """<?xml version="1.0" encoding="UTF-8"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">
<c r="A1"><f>SUM(B1:B3)</f><v>3</v></c><c r="B1" t="e"><v>#REF!</v></c><c r="C1"><f>[1]Other!A1</f><v>1</v></c>
</row></sheetData><mergeCells count="1"><mergeCell ref="A1:C1"/></mergeCells></worksheet>"""
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("xl/workbook.xml", workbook)
            archive.writestr("xl/_rels/workbook.xml.rels", rels)
            archive.writestr("xl/worksheets/sheet1.xml", sheet)
            archive.writestr("xl/externalLinks/externalLink1.xml", "<externalLink/>")
            archive.writestr("xl/vbaProject.bin", b"fixture")

    def test_xlsx_probe_finds_hidden_external_macro_error_and_manual_calc(self):
        path = self.root / "target.xlsm"
        self.make_xlsx(path)
        receipt = gauntlet.inspect_workbook(path)
        ids = {item["rule_id"] for item in receipt["issues"]}
        detectors = {item.get("detector_id") for item in receipt["issues"]}
        self.assertEqual(receipt["execution_status"], "completed")
        for rule in ("SHEET-HIDDEN", "SHEET-CALC", "SHEET-TYPE", "SHEET-EXTERNAL"):
            self.assertIn(rule, ids)
        for detector in ("SHEET-MANUAL-CALC", "SHEET-ERROR-CELL", "SHEET-EXTERNAL-FORMULA", "SHEET-EXTERNAL-LINK", "SHEET-MACRO"):
            self.assertIn(detector, detectors)
        self.assertEqual(receipt["inventory"]["formula_count"], 2)

    def test_formula_inventory_redacts_secret_candidates(self):
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        path = self.root / "secret-formula.xlsx"
        workbook = '''<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>'''
        rels = '''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="worksheet" Target="worksheets/sheet1.xml"/></Relationships>'''
        sheet = f'''<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1"><f>\"{secret}\"</f><v>0</v></c></row></sheetData></worksheet>'''
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("xl/workbook.xml", workbook)
            archive.writestr("xl/_rels/workbook.xml.rels", rels)
            archive.writestr("xl/worksheets/sheet1.xml", sheet)
        receipt = gauntlet.inspect_workbook(path)
        self.assertNotIn(secret, json.dumps(receipt))
        self.assertIn("[redacted-formula-", receipt["inventory"]["formula_cells"][0]["formula"])

    def test_csv_negative_numbers_are_not_formula_candidates(self):
        path = self.root / "numbers.csv"
        path.write_text("name,value\na,-1\nb,+2.5\n")
        receipt = gauntlet.inspect_workbook(path)
        self.assertFalse(any(item.get("detector_id") == "SHEET-FORMULA-CELLS" for item in receipt["issues"]))

    def test_csv_probe_finds_ragged_rows_and_formula_candidates(self):
        path = self.root / "target.csv"
        path.write_text("name,value\na,1\nb,=1+1,extra\n")
        receipt = gauntlet.inspect_workbook(path)
        ids = {item["rule_id"] for item in receipt["issues"]}
        detectors = {item.get("detector_id") for item in receipt["issues"]}
        self.assertIn("SHEET-STRUCTURE", ids)
        self.assertIn("SHEET-TYPE", ids)
        self.assertIn("SHEET-RAGGED-ROWS", detectors)
        self.assertIn("SHEET-FORMULA-CELLS", detectors)


class ArtifactAdapterTests(TempCase):
    def test_adapter_exceptions_are_fingerprinted_without_raw_values(self):
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        receipt = {}
        gauntlet.receipt_exception(receipt, ValueError(f"parser failed near {secret}"))
        self.assertEqual(receipt["execution_status"], "failed")
        self.assertNotIn(secret, json.dumps(receipt))
        self.assertIn("adapter exception", receipt["error"])

    def test_archive_entry_names_are_secret_safe(self):
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        path = self.root / "named.zip"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr(f"scripts/{secret}.sh", "echo fixture")
        receipt = gauntlet.inspect_archive_binary(path)
        serialized = json.dumps(receipt)
        self.assertNotIn(secret, serialized)
        self.assertIn("[redacted-", serialized)

    def test_archive_probe_finds_escape_and_active_entries_without_extracting(self):
        path = self.root / "payload.zip"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("../escape.sh", "echo no")
            archive.writestr("safe/readme.txt", "read me")
        receipt = gauntlet.inspect_archive_binary(path)
        ids = {issue["rule_id"] for issue in receipt["issues"]}
        self.assertIn("BIN-CONTAIN", ids)
        self.assertIn("BIN-ACTIVE", ids)
        self.assertFalse((self.root.parent / "escape.sh").exists())
        gauntlet.validate_receipt(receipt)

    def test_pdf_probe_finds_active_content(self):
        path = self.root / "active.pdf"
        path.write_bytes(b"%PDF-1.7\n1 0 obj << /Type /Page /JavaScript /EmbeddedFile >> endobj\n%%EOF")
        receipt = gauntlet.inspect_document(path)
        kinds = {issue["kind"] for issue in receipt["issues"]}
        self.assertIn("javascript", kinds)
        self.assertIn("embedded_files", kinds)
        self.assertEqual(receipt["inventory"]["page_markers"], 1)
        gauntlet.validate_receipt(receipt)

    def test_docx_probe_finds_macro_external_relationship_and_revision(self):
        path = self.root / "review.docx"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("word/document.xml", '<w:document xmlns:w="urn:test"><w:ins/></w:document>')
            archive.writestr("word/_rels/document.xml.rels", '<Relationship TargetMode="External" Target="https://example.invalid"/>')
            archive.writestr("word/vbaProject.bin", b"fixture")
            archive.writestr("docProps/core.xml", "<core/>")
        receipt = gauntlet.inspect_document(path)
        kinds = {issue["kind"] for issue in receipt["issues"]}
        self.assertIn("active_package_content", kinds)
        self.assertIn("external_package_relationships", kinds)
        self.assertIn("comments_or_tracked_revisions", kinds)

    def test_svg_probe_finds_active_external_content_and_redacts_secret(self):
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        path = self.root / "active.svg"
        path.write_text(f'<svg xmlns="http://www.w3.org/2000/svg"><script>const key="{secret}"</script><image href="https://example.invalid/a.png"/></svg>')
        receipt = gauntlet.inspect_media(path)
        ids = {issue["rule_id"] for issue in receipt["issues"]}
        detectors = {issue.get("detector_id") for issue in receipt["issues"]}
        self.assertIn("MEDIA-INTEGRITY", ids)
        self.assertIn("CORE-SECRET", ids)
        self.assertIn("SECRET-STRIPE-LIVE", detectors)
        self.assertNotIn(secret, json.dumps(receipt))

    def test_png_probe_validates_dimensions_and_crc(self):
        def chunk(kind, payload):
            return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)
        path = self.root / "pixel.png"
        path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0)) + chunk(b"IEND", b""))
        receipt = gauntlet.inspect_media(path)
        self.assertEqual(receipt["result"], "holds")
        self.assertEqual((receipt["inventory"]["width"], receipt["inventory"]["height"]), (1, 1))

        disguised = self.root / "pixel.txt"
        disguised.write_bytes(path.read_bytes())
        classification = gauntlet.classify_file(disguised)
        self.assertEqual(classification["adapter"], "media")
        self.assertTrue(classification["extension_magic_mismatch"])


class GateAndDeltaTests(TempCase):
    def manifest(self, track="REPORT"):
        (self.root / "target.md").write_text("target\n")
        return gauntlet.build_manifest(self.root / "target.md", "full", track, "shell", 1000, None, None, None)

    def ledger(self, findings=None, manifest=None):
        return {
            "schema_version": "7.0", "run_id": "run",
            "target_fingerprint": manifest["target"]["fingerprint"] if manifest else "0" * 64,
            "manifest_path": "review-manifest.json", "findings": findings or [],
        }

    def finding(self, identifier="F-01", severity="HIGH", status="open", title="Defect"):
        item = {
            "id": identifier, "title": title, "severity": severity, "status": status,
            "rule_id": "TEST-RULE", "surface_ids": [gauntlet.surface_id("target.md")],
            "criteria": ["C1"], "evidence": "verified: fixture",
            "evidence_class": "verified_fact", "evidence_method": "fixture inspection",
            "evidence_scope": "target.md", "evidence_refs": ["target.md:1"], "confidence": "high",
            "location": "target.md:1", "anchor": {"type": "line", "coordinate": "target.md:1", "resolved": True},
            "quote": "target", "horizon": "active",
            "root_cause": title, "counter": "No counter-control exists in the fixture.",
            "disposition": "FIX", "regression": "Recheck the target behavior.",
            "verification": "Repeat the fixture assertion.", "first_seen_revision": "fixture",
        }
        item["fingerprint"] = gauntlet.finding_fingerprint(item)
        return item

    def test_target_change_after_review_fails_gate_closed(self):
        manifest = self.manifest()
        manifest["surfaces"][0].update({"state": "reviewed", "evidence": ["semantic-review:test"]})
        verifier = next(check for check in manifest["checks"] if check["id"] == "CHK-FINDINGS-VERIFIER")
        verifier.update({"execution_status": "completed", "result": "holds", "evidence": ["verifier:test"], "completed_at": gauntlet.utc_now()})
        (self.root / "target.md").write_text("changed after review\n")
        gate = gauntlet.coverage_gate(manifest, self.ledger(manifest=manifest))
        self.assertEqual(gate["verdict"], "NOT_READY")
        self.assertTrue(any(reason["code"] == "TARGET_CHANGED_SINCE_MANIFEST" for reason in gate["reasons"]))

    def test_pending_surface_prevents_ready(self):
        manifest = self.manifest()
        gate = gauntlet.coverage_gate(manifest, self.ledger(manifest=manifest))
        self.assertEqual(gate["verdict"], "CONDITIONAL")
        self.assertEqual(gate["coverage_rate"], 0.0)

    def test_reviewed_surface_with_complete_checks_is_ready(self):
        manifest = self.manifest()
        manifest["surfaces"][0]["state"] = "reviewed"
        manifest["surfaces"][0]["evidence"] = ["semantic-review:test"]
        verifier = next(check for check in manifest["checks"] if check["id"] == "CHK-FINDINGS-VERIFIER")
        verifier.update({"execution_status": "completed", "result": "holds", "evidence": ["verifier:test"], "completed_at": gauntlet.utc_now()})
        gate = gauntlet.coverage_gate(manifest, self.ledger(manifest=manifest))
        self.assertEqual(gate["verdict"], "READY")
        self.assertEqual(gate["coverage_rate"], 1.0)
        self.assertEqual(gate["target_fingerprint"], manifest["target"]["fingerprint"])
        gauntlet.validate_gate_receipt(gate)

    def test_nonblocking_required_check_failure_prevents_ready(self):
        manifest = self.manifest()
        manifest["surfaces"][0].update({"state": "reviewed", "evidence": ["semantic-review:test"]})
        verifier = next(check for check in manifest["checks"] if check["id"] == "CHK-FINDINGS-VERIFIER")
        verifier.update({"execution_status": "completed", "result": "holds", "evidence": ["verifier:test"], "completed_at": gauntlet.utc_now()})
        manifest["checks"].append({
            "id": "CHK-NONBLOCKING", "kind": "fixture", "required": True, "blocking": False,
            "execution_status": "completed", "result": "fails", "scope": "fixture",
            "evidence": ["fixture:failure"],
        })
        gate = gauntlet.coverage_gate(manifest, self.ledger(manifest=manifest))
        self.assertEqual(gate["verdict"], "CONDITIONAL")
        self.assertTrue(any(reason["code"] == "REQUIRED_CHECK_FAILED" for reason in gate["reasons"]))

    def test_open_high_is_not_ready_for_report(self):
        manifest = self.manifest()
        manifest["surfaces"][0]["state"] = "reviewed"
        manifest["surfaces"][0]["evidence"] = ["semantic-review:test"]
        gate = gauntlet.coverage_gate(manifest, self.ledger([self.finding()], manifest))
        self.assertEqual(gate["verdict"], "NOT_READY")
        self.assertEqual(gate["open_high"], 1)

    def test_open_critical_blocks_rebuild(self):
        manifest = self.manifest(track="REBUILD")
        manifest["surfaces"][0]["state"] = "reviewed"
        manifest["surfaces"][0]["evidence"] = ["semantic-review:test"]
        gate = gauntlet.coverage_gate(manifest, self.ledger([self.finding(severity="CRITICAL")], manifest))
        self.assertEqual(gate["verdict"], "BLOCKED")

    def test_accepted_high_caps_at_conditional(self):
        manifest = self.manifest()
        manifest["surfaces"][0]["state"] = "reviewed"
        manifest["surfaces"][0]["evidence"] = ["semantic-review:test"]
        gate = gauntlet.coverage_gate(manifest, self.ledger([self.finding(status="accepted")], manifest))
        self.assertEqual(gate["verdict"], "CONDITIONAL")

    def test_accepted_critical_is_not_ready(self):
        manifest = self.manifest()
        manifest["surfaces"][0].update({"state": "reviewed", "evidence": ["semantic-review:test"]})
        finding = self.finding(severity="CRITICAL", status="accepted")
        gate = gauntlet.coverage_gate(manifest, self.ledger([finding], manifest))
        self.assertEqual(gate["verdict"], "NOT_READY")
        self.assertEqual(gate["accepted_critical"], 1)

    def test_material_finding_not_rechecked_is_not_ready(self):
        manifest = self.manifest()
        manifest["surfaces"][0].update({"state": "reviewed", "evidence": ["semantic-review:test"]})
        finding = self.finding(status="not_rechecked")
        gate = gauntlet.coverage_gate(manifest, self.ledger([finding], manifest))
        self.assertEqual(gate["verdict"], "NOT_READY")
        self.assertEqual(gate["not_rechecked_material"], 1)

    def test_fingerprint_survives_harmless_line_movement(self):
        first = self.finding()
        second = dict(first, location="target.md:200")
        self.assertEqual(gauntlet.finding_fingerprint(first), gauntlet.finding_fingerprint(second))

    def test_missing_later_finding_is_not_rechecked_not_fixed(self):
        old = self.ledger([self.finding()])
        new = self.ledger([])
        delta = gauntlet.compare_ledgers(old, new)
        self.assertEqual(delta["counts"]["not_rechecked"], 1)
        self.assertEqual(delta["counts"]["fixed"], 0)

    def test_already_fixed_finding_is_not_counted_as_newly_fixed(self):
        fixed = self.finding(status="fixed")
        delta = gauntlet.compare_ledgers(self.ledger([fixed]), self.ledger([dict(fixed)]))
        self.assertEqual(delta["counts"]["fixed"], 0)
        self.assertEqual(delta["counts"]["persisting"], 1)

    def test_fixed_finding_that_reopens_is_regressed(self):
        old_finding = self.finding(status="fixed")
        new_finding = self.finding(status="open")
        old = self.ledger([old_finding])
        new = self.ledger([new_finding])
        delta = gauntlet.compare_ledgers(old, new)
        self.assertEqual(delta["counts"]["regressed"], 1)


class FindingsVerifierTests(TempCase):
    def setUp(self):
        super().setUp()
        self.target = self.root / "target.md"
        self.target.write_text("# Target\nunsafe value\n")
        self.manifest = gauntlet.build_manifest(self.target, "full", "REPORT", "shell", 1000, None, None, None)

    def finding(self):
        finding = {
            "id": "F-01", "rule_id": "TEST-RULE",
            "surface_ids": [self.manifest["surfaces"][0]["id"]], "criteria": ["C1"],
            "title": "Unsafe value", "severity": "HIGH", "horizon": "active",
            "evidence": "verified: exact source", "evidence_class": "verified_fact",
            "evidence_method": "exact source inspection", "evidence_scope": "target.md", "evidence_refs": ["target.md:2"],
            "confidence": "high", "location": "target.md:2",
            "anchor": {"type": "line", "coordinate": "target.md:2", "resolved": True},
            "quote": "unsafe value", "status": "open",
            "root_cause": "Unsafe value remains active.",
            "counter": "No counter-control appears in the target.", "disposition": "FIX",
            "regression": "Recheck surrounding content.", "verification": "Remove the unsafe value and repeat the check.",
            "first_seen_revision": "fixture",
        }
        finding["fingerprint"] = gauntlet.finding_fingerprint(finding)
        return finding

    def ledger(self, findings):
        return {
            "schema_version": "7.0", "run_id": self.manifest["run_id"],
            "target_fingerprint": self.manifest["target"]["fingerprint"],
            "manifest_path": "manifest.json", "findings": findings,
        }

    def test_exact_anchor_holds_mechanically_but_requires_human_adjudication(self):
        receipt = gauntlet.verify_findings(self.manifest, self.ledger([self.finding()]), "b" * 64)
        gauntlet.validate_verifier_receipt(receipt)
        self.assertEqual(receipt["findings"][0]["mechanical_status"], "holds")
        self.assertEqual(receipt["result"], "candidates")
        self.assertGreater(receipt["summary"]["human_checks_required"], 0)

    def test_empty_ledger_can_hold(self):
        receipt = gauntlet.verify_findings(self.manifest, self.ledger([]), "c" * 64)
        self.assertEqual(receipt["result"], "holds")

    def test_stale_fingerprint_fails_verifier(self):
        finding = self.finding()
        finding["fingerprint"] = "GF-" + "0" * 24
        receipt = gauntlet.verify_findings(self.manifest, self.ledger([finding]), "d" * 64)
        self.assertEqual(receipt["result"], "fails")
        self.assertEqual(receipt["findings"][0]["mechanical_status"], "fails")

    def test_ledger_rejects_raw_secret_without_echoing_it(self):
        finding = self.finding()
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        finding["quote"] = secret
        finding["fingerprint"] = gauntlet.finding_fingerprint(finding)
        with self.assertRaises(ValueError) as raised:
            gauntlet.validate_ledger(self.ledger([finding]))
        self.assertIn("raw secret", str(raised.exception))
        self.assertNotIn(secret, str(raised.exception))


class RulePackTests(unittest.TestCase):
    def test_all_routed_packs_exist_and_validate(self):
        packs = gauntlet.load_rule_packs()
        routed = {pack for values in gauntlet.PACKS_BY_ADAPTER.values() for pack in values}
        self.assertEqual(routed - set(packs), set())
        self.assertGreaterEqual(sum(len(pack["rules"]) for pack in packs.values()), 100)

    def test_rule_ids_are_unique_across_packs(self):
        packs = gauntlet.load_rule_packs()
        ids = [rule["id"] for pack in packs.values() for rule in pack["rules"]]
        self.assertEqual(len(ids), len(set(ids)))


if __name__ == "__main__":
    unittest.main()
