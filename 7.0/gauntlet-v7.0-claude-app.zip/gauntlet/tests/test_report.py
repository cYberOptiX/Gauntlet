from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT))
from engine import gauntlet
from engine.gauntlet import finding_fingerprint

GENERATOR = SKILL_ROOT / "templates" / "generate_report.py"


def valid_ledger():
    ledger = {
        "schema_version": "7.0",
        "run_id": "GNT-TEST",
        "report_id": "TEST-001",
        "title": "Fixture report",
        "artifact": "Fixture",
        "artifact_path": "/tmp/fixture",
        "target_fingerprint": "a" * 64,
        "manifest_path": "/tmp/review-manifest.json",
        "gate_receipt_path": "/tmp/gate-receipt.json",
        "gate_receipt_sha256": "b" * 64,
        "revision": "1.0",
        "report_date": "2026-10-06",
        "client_name": "Fixture client",
        "executor_tier": "frontier",
        "evidence_ceiling": "full",
        "meta": {
            "prepared_for": "Fixture client",
            "prepared_by": "Gauntlet",
            "report_date": "2026-10-06",
            "artifact": "Fixture",
            "classification": "Code file",
            "track": "REPORT"
        },
        "verdict": {
            "status": "NOT_READY",
            "badge": "Not ready",
            "headline": "One material defect remains",
            "body": "The finding below blocks release."
        },
        "stats": [
            {"n": "1", "label": "High"},
            {"n": "100%", "label": "Coverage", "tone": "ok"}
        ],
        "coverage": {
            "mandatory_total": 1,
            "reviewed": 1,
            "excluded": 0,
            "cannot_verify": 0,
            "failed": 0,
            "pending": 0,
            "rate": 1.0,
            "notes": []
        },
        "checks": [{
            "id": "CHK-FINDINGS-VERIFIER",
            "kind": "finding_verifier",
            "required": True,
            "blocking": True,
            "execution_status": "completed",
            "result": "holds",
            "scope": "fixture",
            "evidence": ["receipt.json"],
            "reason": None
        }],
        "gate": {
            "verdict": "NOT_READY",
            "target_fingerprint": "a" * 64,
            "coverage_rate": 1.0,
            "reasons": [{"code": "OPEN_HIGH", "count": 1}]
        },
        "delta": {
            "new": ["GF-111111111111111111111111"],
            "persisting": [],
            "fixed": [],
            "regressed": [],
            "accepted": [],
            "withdrawn": [],
            "not_rechecked": []
        },
        "sections": {
            "executive": "<p>The fixture has one release blocker.</p>",
            "scope": "<p>One file was read and checked.</p>",
            "strengths": "<p>The target is small and direct.</p>",
            "future_risks": "<p>No separate future risk was found.</p>",
            "actions": "<p>Correct F-01 before release.</p>",
            "verification": "<p>Repeat the failing check after correction.</p>"
        },
        "findings": [{
            "id": "F-01",
            "fingerprint": "GF-111111111111111111111111",
            "rule_id": "CODE-ERROR",
            "surface_ids": ["S-111111111111"],
            "criteria": ["C1"],
            "title": "Unsafe <img src=x onerror=alert(1)> output",
            "severity": "HIGH",
            "horizon": "active",
            "evidence": "verified by fixture",
            "evidence_class": "verified_fact",
            "evidence_method": "fixture inspection",
            "evidence_scope": "fixture.js",
            "evidence_refs": ["receipt.json#F-01"],
            "confidence": "high",
            "location": "fixture.js:1",
            "anchor": {"type": "line", "coordinate": "fixture.js:1", "resolved": True},
            "quote": "output = input",
            "status": "open",
            "found": "Untrusted input reaches output.",
            "why": "A user can alter rendered content.",
            "risk": "The delivered page can execute unwanted markup.",
            "root_cause": "Output encoding is absent.",
            "manifestations": ["Primary render path"],
            "counter": "No sanitizer or text-only sink exists.",
            "disposition": "FIX",
            "remediation": "Use a text-only sink for untrusted content.",
            "regression": "Retest intended formatting and plain text.",
            "verification": "Submit hostile markup and inspect the DOM.",
            "first_seen_revision": "1.0"
        }],
        "revisions": [{"rev": "1.0", "date": "2026-10-06", "change": "Initial fixture report", "author": "Gauntlet"}]
    }
    fingerprint = finding_fingerprint(ledger["findings"][0])
    ledger["findings"][0]["fingerprint"] = fingerprint
    ledger["delta"]["new"] = [fingerprint]
    return ledger


class ReportGeneratorTests(unittest.TestCase):
    def setUp(self):
        self._temp = tempfile.TemporaryDirectory()
        self.root = Path(self._temp.name)
        self.target = self.root / "target"
        self.target.mkdir()
        (self.target / "fixture.js").write_text("output = input\n")
        self.manifest = gauntlet.build_manifest(self.target, "full", "REPORT", "full", 1000, None, None, None)
        self.manifest["surfaces"][0].update({"state": "reviewed", "evidence": ["semantic-review:test"]})
        self.manifest["status"] = gauntlet.derive_manifest_status(self.manifest["surfaces"], self.manifest["checks"])
        self.manifest["stats"] = gauntlet.manifest_stats(self.manifest["surfaces"], self.manifest["checks"])
        self.manifest_path = self.root / "review-manifest.json"
        self.candidate_path = self.root / "candidate-ledger.json"
        self.verifier_path = self.root / "findings-verifier.json"
        self.gate_path = self.root / "gate-receipt.json"
        gauntlet.atomic_json(self.manifest_path, self.manifest)

    def ledger(self):
        ledger = valid_ledger()
        surface = self.manifest["surfaces"][0]
        ledger["run_id"] = self.manifest["run_id"]
        ledger["artifact_path"] = str(self.target)
        ledger["target_fingerprint"] = self.manifest["target"]["fingerprint"]
        ledger["manifest_path"] = str(self.manifest_path)
        ledger["findings"][0]["surface_ids"] = [surface["id"]]
        ledger["findings"][0]["fingerprint"] = finding_fingerprint(ledger["findings"][0])
        ledger["delta"]["new"] = [ledger["findings"][0]["fingerprint"]]

        candidate = {
            "schema_version": "7.0", "run_id": self.manifest["run_id"],
            "target_fingerprint": self.manifest["target"]["fingerprint"],
            "manifest_path": str(self.manifest_path),
            "findings": json.loads(json.dumps(ledger["findings"])),
        }
        gauntlet.atomic_json(self.candidate_path, candidate)
        finding = candidate["findings"][0]
        verifier_receipt = {
            "$schema": "https://miancore.local/gauntlet/verifier-receipt-schema.json",
            "schema_version": "7.0", "verifier_version": "fixture-independent-1",
            "started_at": gauntlet.utc_now(), "completed_at": gauntlet.utc_now(),
            "execution_status": "completed", "result": "holds",
            "manifest_fingerprint": self.manifest["target"]["fingerprint"],
            "ledger_sha256": gauntlet.sha256_file(self.candidate_path),
            "findings_total": 1,
            "findings": [{
                "id": finding["id"], "fingerprint": finding["fingerprint"], "protected": True,
                "mechanical_status": "holds", "checks": [{"name": "fixture", "status": "holds"}],
                "human_checks_required": [],
            }],
            "summary": {"holds": 1, "fails": 0, "unresolved": 0, "human_checks_required": 0},
            "limitations": ["Fixture receipt for report binding tests."],
        }
        gauntlet.validate_verifier_receipt(verifier_receipt)
        gauntlet.atomic_json(self.verifier_path, verifier_receipt)
        verifier = next(check for check in self.manifest["checks"] if check["id"] == "CHK-FINDINGS-VERIFIER")
        verifier.update({
            "execution_status": "completed", "result": "holds",
            "evidence": [str(self.verifier_path), str(self.candidate_path)],
            "started_at": verifier_receipt["started_at"], "completed_at": verifier_receipt["completed_at"],
        })
        self.manifest["status"] = gauntlet.derive_manifest_status(self.manifest["surfaces"], self.manifest["checks"])
        self.manifest["stats"] = gauntlet.manifest_stats(self.manifest["surfaces"], self.manifest["checks"])
        gauntlet.atomic_json(self.manifest_path, self.manifest)

        ledger["checks"] = json.loads(json.dumps(self.manifest["checks"]))
        gate = gauntlet.coverage_gate(self.manifest, ledger)
        gate["manifest_sha256"] = gauntlet.sha256_file(self.manifest_path)
        gate.update(gauntlet.validate_bound_verifier(self.manifest, ledger, self.root))
        gauntlet.validate_gate_receipt(gate, require_bindings=True)
        gauntlet.atomic_json(self.gate_path, gate)
        ledger["gate"] = gate
        ledger["gate_receipt_path"] = str(self.gate_path)
        ledger["gate_receipt_sha256"] = gauntlet.sha256_file(self.gate_path)
        ledger["coverage"] = gate["coverage"]
        return ledger

    def tearDown(self):
        self._temp.cleanup()

    def run_generator(self, ledger):
        ledger_path = self.root / "ledger.json"
        output_path = self.root / "report.html"
        ledger_path.write_text(json.dumps(ledger))
        result = subprocess.run(
            ["python3", str(GENERATOR), str(ledger_path), str(output_path)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        return result, output_path

    def test_v7_report_contains_coverage_delta_and_escaped_structured_fields(self):
        result, output = self.run_generator(self.ledger())
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        document = output.read_text()
        self.assertIn("Coverage 100.0%", document)
        self.assertIn("Re-review delta", document)
        self.assertIn("Check receipts", document)
        self.assertIn("CHK-FINDINGS-VERIFIER", document)
        self.assertIn(self.ledger()["findings"][0]["fingerprint"], document)
        self.assertIn("Unsafe &lt;img src=x onerror=alert(1)&gt; output", document)
        self.assertNotIn("<img src=x onerror=alert(1)>", document)

    def test_ready_with_incomplete_coverage_is_rejected(self):
        ledger = self.ledger()
        ledger["verdict"]["status"] = "READY"
        ledger["gate"]["verdict"] = "READY"
        ledger["coverage"].update({"reviewed": 0, "pending": 1, "rate": 0.0})
        ledger["gate"]["coverage_rate"] = 0.0
        ledger["findings"] = []
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("READY cannot contain incomplete mandatory coverage", result.stdout + result.stderr)

    def test_ready_with_pending_required_check_is_rejected(self):
        ledger = self.ledger()
        ledger["findings"] = []
        ledger["verdict"].update({"status": "READY", "badge": "Ready", "headline": "Checks hold", "body": "Bound checks hold."})
        ledger["gate"].update({"verdict": "READY", "reasons": []})
        verifier = next(check for check in ledger["checks"] if check["id"] == "CHK-FINDINGS-VERIFIER")
        verifier.update({"execution_status": "pending", "result": "unknown", "evidence": []})
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("independent findings verifier", result.stdout + result.stderr)

    def test_gate_and_human_verdict_must_agree(self):
        ledger = self.ledger()
        ledger["gate"]["verdict"] = "CONDITIONAL"
        result, _ = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("disagree", result.stdout + result.stderr)

    def test_raw_secret_is_rejected_without_echoing_value(self):
        ledger = self.ledger()
        secret = "sk_live_51ABCdefEXAMPLEkeyDoNotUse00xyz"
        ledger["findings"][0]["quote"] = secret
        ledger["findings"][0]["fingerprint"] = finding_fingerprint(ledger["findings"][0])
        result, output = self.run_generator(ledger)
        combined = result.stdout + result.stderr
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("raw secret candidate", combined)
        self.assertNotIn(secret, combined)

    def test_target_change_after_gate_blocks_report_generation(self):
        ledger = self.ledger()
        (self.target / "fixture.js").write_text("changed after gate\n")
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("recorded gate is stale", result.stdout + result.stderr)

    def test_missing_bound_verifier_receipt_is_rejected(self):
        ledger = self.ledger()
        self.verifier_path.unlink()
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("bound findings verifier evidence", result.stdout + result.stderr)

    def test_tampered_candidate_ledger_is_rejected(self):
        ledger = self.ledger()
        candidate = json.loads(self.candidate_path.read_text())
        candidate["findings"] = []
        gauntlet.atomic_json(self.candidate_path, candidate)
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("bound findings verifier evidence", result.stdout + result.stderr)

    def test_stale_gate_binding_is_rejected(self):
        ledger = self.ledger()
        ledger["gate"]["verifier_receipt_sha256"] = "0" * 64
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("gate hashes", result.stdout + result.stderr)

    def test_missing_gate_receipt_is_rejected(self):
        ledger = self.ledger()
        self.gate_path.unlink()
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("bound gate receipt", result.stdout + result.stderr)

    def test_report_cannot_overwrite_gate_receipt(self):
        ledger = self.ledger()
        ledger_path = self.root / "ledger.json"
        ledger_path.write_text(json.dumps(ledger))
        before = self.gate_path.read_bytes()
        result = subprocess.run(
            ["python3", str(GENERATOR), str(ledger_path), str(self.gate_path)],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.gate_path.read_bytes(), before)
        self.assertIn("gate_receipt_path", result.stdout + result.stderr)

    def test_report_cannot_overwrite_bound_evidence(self):
        ledger = self.ledger()
        ledger_path = self.root / "ledger.json"
        evidence_path = self.root / "receipt.json"
        evidence_path.write_text('{"evidence":true}')
        ledger_path.write_text(json.dumps(ledger))
        result = subprocess.run(
            ["python3", str(GENERATOR), str(ledger_path), str(evidence_path)],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(json.loads(evidence_path.read_text()), {"evidence": True})
        self.assertIn("bound evidence", result.stdout + result.stderr)

    def test_report_cannot_overwrite_its_ledger(self):
        ledger_path = self.root / "ledger.json"
        ledger_path.write_text(json.dumps(self.ledger()))
        result = subprocess.run(
            ["python3", str(GENERATOR), str(ledger_path), str(ledger_path)],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(json.loads(ledger_path.read_text())["report_id"], "TEST-001")
        self.assertIn("cannot overwrite", result.stdout + result.stderr)

    def test_external_resource_markup_in_authored_section_is_rejected(self):
        ledger = self.ledger()
        ledger["sections"]["executive"] = '<p style="background:url(https://tracker.invalid/x)">Assessment</p><img src="https://tracker.invalid/pixel">'
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("active HTML", result.stdout + result.stderr)

    def test_active_html_in_authored_section_is_rejected(self):
        ledger = self.ledger()
        ledger["sections"]["executive"] = '<p>Assessment</p><script>alert(1)</script>'
        result, output = self.run_generator(ledger)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(output.exists())
        self.assertIn("active HTML", result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
