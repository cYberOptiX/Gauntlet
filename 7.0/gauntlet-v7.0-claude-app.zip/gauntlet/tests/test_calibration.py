from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import unittest
from collections import Counter
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SKILL_ROOT))

from engine import gauntlet

SUITE_ROOT = SKILL_ROOT / "fixtures" / "universal"
SUITE_MANIFEST = SUITE_ROOT / "manifest.json"


class CalibrationFixtureTests(unittest.TestCase):
    def test_locked_fixture_hashes_match_manifest(self):
        suite = json.loads(SUITE_MANIFEST.read_text())
        self.assertEqual(suite["schema_version"], "2.0")
        for family in suite["families"]:
            target = (SUITE_ROOT / family["target"]).resolve()
            self.assertTrue(target.is_file(), family["id"])
            self.assertEqual(gauntlet.sha256_file(target), family["sha256"], family["id"])
            if family.get("answer_key"):
                answer_key = (SUITE_ROOT / family["answer_key"]).resolve()
                self.assertTrue(answer_key.is_file(), family["id"])
                self.assertEqual(gauntlet.sha256_file(answer_key), family["answer_key_sha256"], family["id"])

    def test_declared_severity_counts_match_sealed_answer_keys(self):
        suite = json.loads(SUITE_MANIFEST.read_text())
        for family in suite["families"]:
            if not family.get("answer_key"):
                continue
            answer_key = (SUITE_ROOT / family["answer_key"]).resolve()
            counts = Counter(re.findall(r"^\|\s*\d+\s*\|\s*(CRITICAL|HIGH|MEDIUM)\s*\|", answer_key.read_text(), re.M))
            self.assertEqual(counts["CRITICAL"], family["critical"], family["id"])
            self.assertEqual(counts["HIGH"], family["high"], family["id"])
            self.assertEqual(counts["MEDIUM"], family["medium"], family["id"])

    def test_workbook_generator_is_byte_deterministic(self):
        generator = SUITE_ROOT / "workbook" / "generate_fixture.py"
        with tempfile.TemporaryDirectory() as directory:
            first = Path(directory) / "first.xlsm"
            second = Path(directory) / "second.xlsm"
            subprocess.run(["python3", str(generator), str(first)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["python3", str(generator), str(second)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.assertEqual(first.read_bytes(), second.read_bytes())
            suite = json.loads(SUITE_MANIFEST.read_text())
            expected = next(item["sha256"] for item in suite["families"] if item["id"] == "workbook")
            self.assertEqual(gauntlet.sha256_file(first), expected)

    def test_static_clean_controls_remain_clean(self):
        html_receipt = gauntlet.inspect_html(SUITE_ROOT / "clean" / "clean.html")
        spec_receipt = gauntlet.inspect_text(SUITE_ROOT / "clean" / "clean-spec.md")
        self.assertEqual(html_receipt["result"], "holds")
        self.assertEqual(spec_receipt["result"], "holds")
        self.assertEqual(html_receipt["issues"], [])
        self.assertEqual(spec_receipt["issues"], [])

    def test_workbook_fixture_exposes_semantic_formula_candidates(self):
        receipt = gauntlet.inspect_workbook(SUITE_ROOT / "workbook" / "target.xlsm")
        detectors = {issue.get("detector_id") for issue in receipt["issues"]}
        for detector in (
            "SHEET-MANUAL-CALC", "SHEET-HIDDEN-DEPENDENCY", "SHEET-FORMULA-GAP",
            "SHEET-RANGE-ADJACENT", "SHEET-EXTERNAL-FORMULA", "SHEET-MACRO",
        ):
            self.assertIn(detector, detectors)
        hidden_dependencies = next(issue for issue in receipt["issues"] if issue.get("detector_id") == "SHEET-HIDDEN-DEPENDENCY")
        self.assertEqual(hidden_dependencies["count"], 3)
        formulas = {(item["sheet"], item["cell"]): item["formula"] for item in receipt["inventory"]["formula_cells"]}
        self.assertEqual(formulas[("Summary", "B1")], "SUM(Inputs!B2:B4)")
        self.assertNotIn("C4", {cell for sheet, cell in formulas if sheet == "Inputs"})

    def test_html_fixture_implicit_label_is_not_a_false_positive(self):
        receipt = gauntlet.inspect_html(SUITE_ROOT / "html" / "target.html")
        unlabeled = [issue for issue in receipt["issues"] if issue.get("detector_id") == "HTML-CONTROL-NAME"]
        self.assertEqual(len(unlabeled), 1)
        self.assertEqual(unlabeled[0]["line"], 12)

    def test_seeded_secret_values_never_enter_receipts(self):
        targets = [
            SKILL_ROOT / "fixtures" / "target" / "config.js",
            SUITE_ROOT / "html" / "target.html",
            SUITE_ROOT / "spec" / "target.md",
        ]
        receipts = [gauntlet.inspect_text(targets[0]), gauntlet.inspect_html(targets[1]), gauntlet.inspect_text(targets[2])]
        serialized = json.dumps(receipts)
        for target in targets:
            text = target.read_text()
            for _, pattern in gauntlet.SECRET_PATTERNS:
                for match in pattern.finditer(text):
                    self.assertNotIn(match.group(0), serialized)
        detector_ids = {issue.get("detector_id") for receipt in receipts for issue in receipt["issues"]}
        self.assertIn("SECRET-STRIPE-LIVE", detector_ids)
        self.assertIn("SECRET-URL-CREDENTIALS", detector_ids)


if __name__ == "__main__":
    unittest.main()
