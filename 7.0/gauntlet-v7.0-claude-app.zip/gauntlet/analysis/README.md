# Analysis archive

`gauntlet-universal-blueprint.html` is a preserved planning artifact that predates the operational Gauntlet v7 implementation. Its version labels, roadmap states, counts, and proposed interfaces are historical context, not the current contract.

Timestamped pre-v7 file backups are preserved outside the operational skill tree at `../../.gauntlet-backups/`. `gauntlet-v5-sample-report.html` is likewise retained only as a historical report specimen. The blueprint's old reference named templates/gauntlet-report.html refers to this archived specimen, not an operational template.

For current behavior, use `../SKILL.md`, `../modules/engine.md`, the schemas under `../schemas/`, `../templates/report-shell.html`, `../templates/generate_report.py`, and `../engine/gauntlet.py`. The archived files are not loaded as execution guidance and create no compatibility promise.
