#!/usr/bin/env python3
"""Gauntlet report generator.

Assembles a complete, branded Miancore review report from a Gauntlet v7 run
ledger (findings-schema.json) and the token shell (report-shell.html). Mechanical
parts include run identity, coverage, check state, release gate, re-review delta,
verdict, stat tiles, severity chart, finding cards, and revision history.
Per-engagement prose is authored in `sections` as trusted raw HTML and inserted
after the writing scan. Structured finding fields are escaped by default; only an
explicit `custom_body` is treated as trusted HTML. The writing scan (no em/en
dashes, no AI-stock words) runs before delivery and blocks on any hit.

Usage:
    python3 generate_report.py <ledger.json> <output.html>

Paths resolve relative to this script's own directory, so it runs from anywhere.
"""
import json, os, re, sys, tempfile, html as _html
from html.parser import HTMLParser
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL_ROOT = HERE.parent
sys.path.insert(0, str(SKILL_ROOT))
from engine.gauntlet import (  # noqa: E402
    coverage_gate, detected_secret_ids, finding_fingerprint, load_json, sha256_file,
    validate_bound_verifier, validate_gate_receipt, validate_manifest,
)

SHELL = HERE / "report-shell.html"
SCHEMA = HERE / "findings-schema.json"

BANNED_CHARS = ["—", "–"]  # em dash, en dash
BANNED_WORDS = [
    "delve", "tapestry", "unlock", "elevate", "game-chang", "seamless", "robust",
    "leverage", "landscape of", "journey", "crucial", "pivotal", "in today",
    "furthermore", "moreover", "holistic", "synerg", "cutting-edge", "empower",
    "streamline", "comprehensive", "utilize", "dive deep", "navigate the",
]
SEV_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]
SEV_CLASS = {"CRITICAL": "critical", "HIGH": "high", "MEDIUM": "medium", "LOW": "low", "INFO": "info"}
SEV_LABEL = {"CRITICAL": "Critical", "HIGH": "High", "MEDIUM": "Medium", "LOW": "Low", "INFO": "Info"}
SEV_VAR = {"CRITICAL": "--sev-critical", "HIGH": "--sev-high", "MEDIUM": "--sev-medium",
           "LOW": "--sev-low", "INFO": "--sev-info"}


def esc(value):
    """Escape a structured ledger value for insertion into HTML."""
    text = "" if value is None else str(value)
    text = text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    return _html.escape(text, quote=True)


def prose(value):
    """Escape structured prose while preserving authored line breaks."""
    return esc(value).replace("\n", "<br>")


def writing_scan(text):
    """Strip style/script blocks and tags, then look for banned chars and words."""
    t = re.sub(r"<style>.*?</style>|<script>.*?</script>", " ", text, flags=re.S)
    t = re.sub(r"<[^>]+>", " ", t)
    issues = [f"banned char {c!r}" for c in BANNED_CHARS if c in t]
    issues += [f"AI-stock word: {w}" for w in BANNED_WORDS if re.search(w, t, re.I)]
    return issues


class TrustedFragmentValidator(HTMLParser):
    """Allow only inert authored markup; structured ledger fields are always escaped."""
    allowed_tags = {"p", "br", "strong", "b", "em", "i", "u", "ul", "ol", "li", "code", "pre", "blockquote", "a", "span", "div", "h3", "h4", "table", "thead", "tbody", "tr", "th", "td"}
    allowed_attrs = {"class", "id", "href", "title", "aria-label", "role", "colspan", "rowspan"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.issues = []

    def handle_starttag(self, tag, attrs):
        lowered_tag = tag.lower()
        if lowered_tag not in self.allowed_tags:
            self.issues.append(f"blocked tag <{tag}>")
        for name, value in attrs:
            lowered = name.lower()
            normalized = (value or "").strip().lower()
            if lowered not in self.allowed_attrs or lowered.startswith("on"):
                self.issues.append(f"blocked attribute {name}")
            if lowered == "href" and not (normalized.startswith(("https://", "http://", "mailto:", "#"))):
                self.issues.append(f"blocked URL in {name}")

    handle_startendtag = handle_starttag


def validate_trusted_fragment(fragment, label):
    if any(0xD800 <= ord(char) <= 0xDFFF for char in fragment or ""):
        raise SystemExit(f"LEDGER INVALID: non-Unicode byte surrogate in {label}")
    parser = TrustedFragmentValidator()
    try:
        parser.feed(fragment or "")
        parser.close()
    except Exception as exc:
        raise SystemExit(f"LEDGER INVALID: malformed trusted HTML in {label}: {exc}")
    if parser.issues:
        raise SystemExit(f"LEDGER INVALID: active HTML in {label}: " + ", ".join(sorted(set(parser.issues))))


def validate(ledger, ledger_path=None):
    """Validate required v7 structure and the release invariants the report depends on."""
    schema = json.loads(SCHEMA.read_text())
    missing = [k for k in schema["required"] if k not in ledger]
    if missing:
        raise SystemExit("LEDGER INVALID: missing top-level keys: " + ", ".join(missing))
    if ledger.get("schema_version") != "7.0":
        raise SystemExit("LEDGER INVALID: schema_version must be 7.0")
    serialized_ledger = json.dumps(ledger, ensure_ascii=False)
    secret_detectors = detected_secret_ids(serialized_ledger)
    if secret_detectors:
        raise SystemExit("LEDGER INVALID: raw secret candidate present; replace it with a redacted description and local evidence reference: " + ", ".join(secret_detectors))
    for group in ("meta", "sections", "verdict", "coverage", "gate"):
        for key in schema["properties"][group]["required"]:
            if key not in ledger[group]:
                raise SystemExit(f"LEDGER INVALID: {group}.{key} missing")
    for section, fragment in ledger["sections"].items():
        validate_trusted_fragment(fragment, f"sections.{section}")
        visible = _html.unescape(re.sub(r"<[^>]+>", " ", fragment or "")).strip()
        if not visible:
            raise SystemExit(f"LEDGER INVALID: sections.{section} must contain scoped content or an N/A reason")
    finding_required = schema["properties"]["findings"]["items"]["required"]
    ids, fingerprints = set(), set()
    for finding in ledger["findings"]:
        missing_finding = [key for key in finding_required if key not in finding]
        if missing_finding:
            raise SystemExit(f"LEDGER INVALID: finding {finding.get('id','?')} missing: " + ", ".join(missing_finding))
        if finding.get("severity") not in SEV_ORDER:
            raise SystemExit(f"LEDGER INVALID: finding {finding.get('id','?')} has bad severity {finding.get('severity')!r}")
        if finding.get("custom_body"):
            validate_trusted_fragment(finding["custom_body"], f"finding {finding.get('id','?')}.custom_body")
        if finding["id"] in ids:
            raise SystemExit(f"LEDGER INVALID: duplicate finding id {finding['id']}")
        if finding["fingerprint"] != finding_fingerprint(finding):
            raise SystemExit(f"LEDGER INVALID: stale or invalid finding fingerprint {finding['id']}")
        if finding["fingerprint"] in fingerprints:
            raise SystemExit(f"LEDGER INVALID: duplicate finding fingerprint {finding['fingerprint']}")
        ids.add(finding["id"])
        fingerprints.add(finding["fingerprint"])
    coverage = ledger["coverage"]
    accounted = sum(coverage[key] for key in ("reviewed", "excluded", "cannot_verify", "failed", "pending"))
    if accounted != coverage["mandatory_total"]:
        raise SystemExit("LEDGER INVALID: coverage terminal counts do not equal mandatory_total")
    calculated_rate = 1.0 if coverage["mandatory_total"] == 0 else coverage["reviewed"] / coverage["mandatory_total"]
    if abs(calculated_rate - coverage["rate"]) > 0.000001:
        raise SystemExit("LEDGER INVALID: coverage.rate does not match reviewed / mandatory_total")
    if ledger["gate"]["verdict"] != ledger["verdict"]["status"]:
        raise SystemExit("LEDGER INVALID: gate.verdict and verdict.status disagree")
    if ledger["gate"]["target_fingerprint"] != ledger["target_fingerprint"]:
        raise SystemExit("LEDGER INVALID: gate and ledger target fingerprints disagree")
    if abs(ledger["gate"]["coverage_rate"] - coverage["rate"]) > 0.000001:
        raise SystemExit("LEDGER INVALID: gate coverage and ledger coverage disagree")
    manifest_path = Path(ledger["manifest_path"]).expanduser()
    if not manifest_path.is_absolute() and ledger_path is not None:
        manifest_path = Path(ledger_path).resolve().parent / manifest_path
    if not manifest_path.is_file():
        raise SystemExit("LEDGER INVALID: bound review manifest is unavailable")
    try:
        bound_manifest = load_json(manifest_path)
        validate_manifest(bound_manifest)
    except (OSError, ValueError):
        raise SystemExit("LEDGER INVALID: bound review manifest cannot be read") from None
    check_ids = set()
    for check in ledger["checks"]:
        missing_check = [key for key in ("id", "required", "execution_status", "result", "scope", "evidence") if key not in check]
        if missing_check:
            raise SystemExit("LEDGER INVALID: check missing: " + ", ".join(missing_check))
        if check["id"] in check_ids:
            raise SystemExit(f"LEDGER INVALID: duplicate check id {check['id']}")
        if check["execution_status"] not in {"pending", "completed", "failed", "could_not_run", "skipped"}:
            raise SystemExit(f"LEDGER INVALID: bad execution state for check {check['id']}")
        if check["result"] not in {"unknown", "holds", "fails", "candidates", "not_applicable"}:
            raise SystemExit(f"LEDGER INVALID: bad result for check {check['id']}")
        check_ids.add(check["id"])
    verifier_checks = [check for check in ledger["checks"] if check["id"] == "CHK-FINDINGS-VERIFIER" or check.get("kind") == "finding_verifier"]
    if len(verifier_checks) != 1 or verifier_checks[0]["execution_status"] != "completed" or verifier_checks[0]["result"] != "holds":
        raise SystemExit("LEDGER INVALID: final report requires one completed independent findings verifier with result holds")
    if ledger["verdict"]["status"] == "READY":
        if coverage["pending"] or coverage["cannot_verify"] or coverage["failed"] or coverage["excluded"]:
            raise SystemExit("LEDGER INVALID: READY cannot contain incomplete mandatory coverage")
        severe = [f for f in ledger["findings"] if f["severity"] in {"CRITICAL", "HIGH"} and f["status"] in {"open", "regressed", "accepted", "not_rechecked"}]
        if severe:
            raise SystemExit("LEDGER INVALID: READY cannot contain unresolved or accepted CRITICAL/HIGH findings")
        incomplete_checks = [check["id"] for check in ledger["checks"] if check["required"] and (check["execution_status"] != "completed" or check["result"] in {"unknown", "candidates", "fails"})]
        if incomplete_checks:
            raise SystemExit("LEDGER INVALID: READY has incomplete required checks: " + ", ".join(incomplete_checks))
        if ledger["gate"].get("reasons"):
            raise SystemExit("LEDGER INVALID: READY cannot retain gate reasons")
    manifest_checks = {check["id"]: check for check in bound_manifest["checks"]}
    if check_ids != set(manifest_checks):
        raise SystemExit("LEDGER INVALID: report checks do not match the bound manifest check set")
    for check in ledger["checks"]:
        bound = manifest_checks[check["id"]]
        fields = ("required", "blocking", "execution_status", "result", "scope", "evidence")
        if any(check.get(field) != bound.get(field) for field in fields):
            raise SystemExit(f"LEDGER INVALID: report check {check['id']} disagrees with the bound manifest")
    try:
        verifier_binding = validate_bound_verifier(bound_manifest, ledger, manifest_path.parent)
    except (OSError, ValueError):
        raise SystemExit("LEDGER INVALID: bound findings verifier evidence is unavailable or disagrees with the report") from None
    expected_gate_binding = {
        "manifest_sha256": sha256_file(manifest_path),
        **verifier_binding,
    }
    if any(ledger["gate"].get(key) != value for key, value in expected_gate_binding.items()):
        raise SystemExit("LEDGER INVALID: gate hashes do not bind the current manifest, candidate ledger, and verifier receipt")
    gate_receipt_path = Path(ledger["gate_receipt_path"]).expanduser()
    if not gate_receipt_path.is_absolute() and ledger_path is not None:
        gate_receipt_path = Path(ledger_path).resolve().parent / gate_receipt_path
    try:
        gate_receipt = load_json(gate_receipt_path)
        validate_gate_receipt(gate_receipt, require_bindings=True)
    except (OSError, ValueError):
        raise SystemExit("LEDGER INVALID: bound gate receipt is unavailable or invalid") from None
    if sha256_file(gate_receipt_path) != ledger["gate_receipt_sha256"] or gate_receipt != ledger["gate"]:
        raise SystemExit("LEDGER INVALID: embedded gate does not match its bound receipt")
    try:
        live_gate = coverage_gate(bound_manifest, ledger)
    except (OSError, ValueError) as exc:
        raise SystemExit(f"LEDGER INVALID: live gate recheck failed ({type(exc).__name__})") from None
    recorded_reasons = sorted(json.dumps(reason, sort_keys=True) for reason in ledger["gate"].get("reasons", []))
    live_reasons = sorted(json.dumps(reason, sort_keys=True) for reason in live_gate.get("reasons", []))
    if live_gate["target_fingerprint"] != ledger["gate"]["target_fingerprint"] or live_gate["verdict"] != ledger["gate"]["verdict"] or abs(live_gate["coverage_rate"] - ledger["gate"]["coverage_rate"]) > 0.000001 or live_reasons != recorded_reasons:
        raise SystemExit("LEDGER INVALID: recorded gate is stale or disagrees with the live target recheck")


def counts(findings):
    c = {k: 0 for k in SEV_ORDER}
    for f in findings:
        # a group card counts once toward its severity unless it declares a span count
        c[f["severity"]] += f.get("count", 1)
    return c


def severity_chart(c):
    total = sum(c.values())
    mx = max(c.values()) or 1
    rows = []
    for s in SEV_ORDER:
        n = c[s]
        w = round(n / mx * 100, 1)
        rows.append(
            f'<div class="bar-row"><span class="bl" style="color:var({SEV_VAR[s]})">{SEV_LABEL[s]}</span>'
            f'<div class="bar-track"><div class="bar-fill" style="width:{w}%;background:var({SEV_VAR[s]})" '
            f'title="{SEV_LABEL[s]}: {n}"></div></div><span class="bn">{n}</span></div>')
    return (
        f'<figure class="sevchart"><figcaption>Findings by severity '
        f'<span class="sub">&#183; {total} total &#183; detailed in Section 03</span></figcaption>'
        + "".join(rows)
        + '<div class="chart-note">Severity reflects consequence and likelihood, not volume.</div></figure>')


def stat_tiles(stats):
    cells = []
    for tile in stats[:5]:
        cls = " ok" if tile.get("tone") == "ok" else ""
        cells.append(f'<div class="tile{cls}"><div class="n">{esc(tile["n"])}</div>'
                     f'<div class="l">{esc(tile["label"])}</div></div>')
    return '<div class="stat-row">' + "".join(cells) + '</div>'


def verdict_banner(verdict):
    return (
        '<div class="verdict"><span class="badge-big">' + esc(verdict["badge"]) + '</span>'
        '<div><h4>' + esc(verdict["headline"]) + '</h4><p>' + prose(verdict["body"]) + '</p></div></div>')


def coverage_block(ledger):
    coverage = ledger["coverage"]
    rate = round(coverage["rate"] * 100, 1)
    check_counts = {state: 0 for state in ("completed", "pending", "failed", "could_not_run", "skipped")}
    for check in ledger["checks"]:
        check_counts[check["execution_status"]] = check_counts.get(check["execution_status"], 0) + 1
    details = (
        f'{coverage["reviewed"]} reviewed; {coverage["excluded"]} excluded; '
        f'{coverage["cannot_verify"]} not verifiable; {coverage["failed"]} failed; '
        f'{coverage["pending"]} pending. Required checks: {check_counts["completed"]} completed; '
        f'{check_counts["failed"] + check_counts["could_not_run"] + check_counts["pending"] + check_counts["skipped"]} incomplete.'
    )
    reasons = ledger["gate"].get("reasons", [])
    reason_html = ""
    if reasons:
        reason_html = '<ul>' + "".join(f'<li><span class="mono">{esc(reason.get("code", "GATE"))}</span>'
                                       + (f': {esc(reason.get("path") or reason.get("check_id") or reason.get("count") or "")}' if len(reason) > 1 else "")
                                       + '</li>' for reason in reasons) + '</ul>'
    return (
        '<div class="verdict"><span class="badge-big">Coverage ' + esc(f"{rate}%") + '</span>'
        '<div><h4>Gate: ' + esc(ledger["gate"]["verdict"]) + '</h4><p>' + esc(details) + '</p>'
        + reason_html + '</div></div>')


def checks_block(checks):
    rows = []
    for check in checks:
        evidence = check.get("evidence", [])
        evidence_text = "; ".join(str(item) for item in evidence) if evidence else "None recorded"
        reason = check.get("reason") or check.get("error") or ""
        rows.append(
            '<tr><td class="strong mono">' + esc(check["id"]) + '</td>'
            '<td>' + esc(check["execution_status"]) + '</td><td>' + esc(check["result"]) + '</td>'
            '<td>' + esc(check["scope"]) + '</td><td>' + esc(evidence_text) + (('<br><span class="sub">' + esc(reason) + '</span>') if reason else '') + '</td></tr>'
        )
    return (
        '<h3>Check receipts</h3><div class="tblwrap"><table><thead><tr><th>Check</th><th>Execution</th>'
        '<th>Result</th><th>Scope</th><th>Evidence or reason</th></tr></thead><tbody>'
        + "".join(rows) + '</tbody></table></div>')


def delta_block(delta):
    if not delta:
        return ""
    labels = [("new", "New"), ("persisting", "Persisting"), ("fixed", "Fixed"),
              ("regressed", "Regressed"), ("accepted", "Accepted"),
              ("withdrawn", "Withdrawn"), ("not_rechecked", "Not rechecked")]
    values = []
    for key, label in labels:
        value = delta.get(key, [])
        values.append(f'<div class="tile"><div class="n">{len(value)}</div><div class="l">{esc(label)}</div></div>')
    return '<h3>Re-review delta</h3><div class="stat-row">' + "".join(values) + '</div>'


def finding_card(finding):
    opened = " open" if finding.get("open") else ""
    severity = finding["severity"]
    severity_label = finding.get("severity_label", SEV_LABEL[severity])
    meta_fields = [
        ("Rule", "rule_id", True), ("Location", "location", True),
        ("Evidence", "evidence", False), ("Evidence class", "evidence_class", False),
        ("Method", "evidence_method", False), ("Scope", "evidence_scope", False),
        ("Confidence", "confidence", False), ("Horizon", "horizon", False), ("Status", "status", False),
        ("Disposition", "disposition", False),
    ]
    meta_bits = []
    for label, key, mono in meta_fields:
        if finding.get(key):
            value = esc(finding[key])
            if mono:
                value = f'<span class="mono">{value}</span>'
            meta_bits.append(f'<span><b>{label}:</b> {value}</span>')
    if finding.get("evidence_refs"):
        meta_bits.append(f'<span><b>Evidence refs:</b> <span class="mono">{esc(", ".join(finding["evidence_refs"]))}</span></span>')
    if finding.get("criteria"):
        meta_bits.append(f'<span><b>Criteria:</b> {esc(", ".join(finding["criteria"]))}</span>')
    if finding.get("surface_ids"):
        meta_bits.append(f'<span><b>Surfaces:</b> <span class="mono">{esc(", ".join(finding["surface_ids"]))}</span></span>')
    meta_bits.append(f'<span><b>Fingerprint:</b> <span class="mono">{esc(finding["fingerprint"])}</span></span>')
    meta = '<div class="fmeta">' + "".join(meta_bits) + '</div>'

    if finding.get("custom_body"):
        body_inner = finding["custom_body"]
    else:
        fields = [
            ("Evidence quote", "quote"), ("What we found", "found"),
            ("Why it matters", "why"), ("Risk if unaddressed", "risk"),
            ("Root cause", "root_cause"), ("Counter-evidence", "counter"),
            ("Required correction", "remediation"), ("Regression risk", "regression"),
            ("Verification", "verification"),
        ]
        parts = []
        for heading, key in fields:
            if finding.get(key):
                parts.append(f'<h5>{heading}</h5><p>{prose(finding[key])}</p>')
        if finding.get("manifestations"):
            parts.append('<h5>Manifestations</h5><ul>' + "".join(f'<li>{prose(item)}</li>' for item in finding["manifestations"]) + '</ul>')
        body_inner = "".join(parts)

    return (
        f'<details class="finding" data-sev="{SEV_CLASS[severity]}"{opened}><summary>'
        f'<span class="fid">{esc(finding["id"])}</span>'
        f'<span class="sev {SEV_CLASS[severity]}">{esc(severity_label)}</span>'
        f'<span class="ftitle">{esc(finding["title"])}</span><span class="chev">&#9654;</span></summary>'
        f'<div class="fbody">{meta}{body_inner}</div></details>')


def findings_section(findings, c):
    # filter controls with live counts (only for severities that have findings)
    btns = [f'<button class="fbtn sel" data-f="all">All &#183; {sum(c.values())}</button>']
    for s in ["HIGH", "MEDIUM", "LOW", "INFO", "CRITICAL"]:
        if c[s]:
            btns.append(f'<button class="fbtn" data-f="{SEV_CLASS[s]}">{SEV_LABEL[s]} &#183; {c[s]}</button>')
    controls = (
        '<div class="controls" role="group" aria-label="Filter findings by severity">'
        + "".join(btns)
        + '<span class="gap"></span>'
        '<button class="xbtn" id="expandAll">Expand all</button>'
        '<button class="xbtn" id="collapseAll">Collapse all</button></div>')
    order = {s: i for i, s in enumerate(SEV_ORDER)}
    cards = "".join(finding_card(f) for f in sorted(findings, key=lambda x: order[x["severity"]]))
    return (
        '<section id="findings"><div class="eyebrow">Section 03</div><h2>Findings</h2>'
        '<p>Each finding states what was found, where, why it matters, and the risk of leaving '
        'it unaddressed. Findings are deduplicated: one root cause, its manifestations listed.</p>'
        + controls + cards + '</section>')


def revisions_table(revisions):
    rows = "".join(
        f'<tr><td class="strong">{esc(row["rev"])}</td><td>{esc(row["date"])}</td>'
        f'<td>{prose(row["change"])}</td><td>{esc(row["author"])}</td></tr>' for row in revisions)
    return (
        '<section id="revisions"><div class="eyebrow">Section 08</div><h2>Revision History</h2>'
        '<div class="tblwrap"><table><thead><tr><th>Rev</th><th>Date</th><th>Change</th>'
        '<th>Author</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>')


def build_main(ledger, c):
    s = ledger["sections"]
    exec_section = (
        '<section id="summary"><div class="eyebrow">Section 01</div><h2>Executive Assessment</h2>'
        + s["executive"] + verdict_banner(ledger["verdict"])
        + coverage_block(ledger) + delta_block(ledger.get("delta"))
        + stat_tiles(ledger["stats"]) + severity_chart(c) + '</section>')
    scope_section = (
        '<section id="scope"><div class="eyebrow">Section 02</div><h2>Scope &amp; Method</h2>'
        + s["scope"] + checks_block(ledger["checks"]) + '</section>')
    strengths = ('<section id="strengths"><div class="eyebrow">Section 04</div>'
                 '<h2>What Is Working &amp; Must Be Preserved</h2>' + s["strengths"] + '</section>')
    risks = ('<section id="risks"><div class="eyebrow">Section 05</div><h2>Future Risks</h2>'
             + s["future_risks"] + '</section>')
    actions = ('<section id="actions"><div class="eyebrow">Section 06</div><h2>Required Actions</h2>'
               + s["actions"] + '</section>')
    verif = ('<section id="verification"><div class="eyebrow">Section 07</div>'
             '<h2>Verification &amp; Remaining Unknowns</h2>' + s["verification"] + '</section>')
    return ('<main class="wrap">' + exec_section + scope_section
            + findings_section(ledger["findings"], c) + strengths + risks + actions
            + verif + revisions_table(ledger["revisions"]) + '</main>')


def atomic_text(path, content):
    path = path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    ledger_path = Path(sys.argv[1]).expanduser().resolve()
    out_path = Path(sys.argv[2]).expanduser().resolve()
    if out_path == ledger_path:
        raise SystemExit("OUTPUT INVALID: report cannot overwrite its ledger")
    ledger = json.loads(ledger_path.read_text())
    for protected_key in ("manifest_path", "artifact_path", "gate_receipt_path"):
        protected_value = ledger.get(protected_key)
        if not protected_value:
            continue
        protected_path = Path(protected_value).expanduser()
        if not protected_path.is_absolute():
            protected_path = ledger_path.parent / protected_path
        protected = protected_path.resolve(strict=False)
        if out_path == protected:
            raise SystemExit(f"OUTPUT INVALID: report cannot overwrite {protected_key}")
        if protected_key == "artifact_path" and protected.is_dir():
            try:
                out_path.relative_to(protected)
            except ValueError:
                pass
            else:
                raise SystemExit("OUTPUT INVALID: report must be outside the reviewed directory")
    evidence_values = [str(value) for check in ledger.get("checks", []) for value in check.get("evidence", [])]
    evidence_values += [str(value) for finding in ledger.get("findings", []) for value in finding.get("evidence_refs", [])]
    for value in evidence_values:
        local_value = value.split("#", 1)[0]
        if not local_value or re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", local_value):
            continue
        evidence_path = Path(local_value).expanduser()
        if not evidence_path.is_absolute():
            evidence_path = ledger_path.parent / evidence_path
        if out_path == evidence_path.resolve(strict=False):
            raise SystemExit("OUTPUT INVALID: report cannot overwrite a bound evidence artifact")
    validate(ledger, ledger_path)

    # Writing scan on all human-authored prose BEFORE assembly.
    authored = json.dumps(ledger["sections"]) + json.dumps(ledger["verdict"])
    authored += json.dumps([{key: finding.get(key, "") for key in
                             ("title", "quote", "found", "why", "risk", "root_cause", "counter",
                              "remediation", "regression", "verification", "custom_body")}
                            for finding in ledger["findings"]])
    authored += json.dumps(ledger["revisions"])
    issues = writing_scan(authored)
    if issues:
        raise SystemExit("WRITING SCAN FAILED on ledger prose:\n  " + "\n  ".join(issues))

    c = counts(ledger["findings"])
    shell = SHELL.read_text()
    subs = {
        "TITLE": esc(ledger.get("title", "Review Report")),
        "REPORT_ID": esc(ledger["report_id"]),
        "REVISION": esc(ledger["revision"]),
        "PREPARED_FOR": esc(ledger["meta"]["prepared_for"]),
        "PREPARED_BY": esc(ledger["meta"]["prepared_by"]),
        "REPORT_DATE": esc(ledger["meta"]["report_date"]),
        "ARTIFACT": esc(ledger["meta"]["artifact"]),
        "CLASSIFICATION": esc(ledger["meta"]["classification"]),
        "TRACK": esc(ledger["meta"]["track"]),
        "MAIN": build_main(ledger, c),
    }
    doc = shell
    for tok, val in subs.items():
        doc = doc.replace("{{" + tok + "}}", val)

    leftover = re.findall(r"\{\{[A-Z_]+\}\}", doc)
    if leftover:
        raise SystemExit("UNFILLED TOKENS remain: " + ", ".join(sorted(set(leftover))))

    doc_issues = writing_scan(doc)
    if doc_issues:
        raise SystemExit("WRITING SCAN FAILED on assembled document:\n  " + "\n  ".join(doc_issues))

    atomic_text(out_path, doc)
    print(f"Report written: {out_path}")
    print(f"  {sum(c.values())} findings  " + "  ".join(f"{s[:4]}:{c[s]}" for s in SEV_ORDER))
    print("  tokens: all filled   writing scan: CLEAN")


if __name__ == "__main__":
    main()
