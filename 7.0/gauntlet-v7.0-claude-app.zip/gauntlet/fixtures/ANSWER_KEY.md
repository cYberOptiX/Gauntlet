# Fixture answer key (SEALED)

Do not show this file to the executor being tested. Run the model on
`fixtures/target/`, collect its findings, then compare against this key.

**Pass condition:** the model must catch every CRITICAL and HIGH below, and must
NOT report a CRITICAL that is not here (a false critical is an automatic fail).
Missing a MEDIUM is a warning, not a fail. Cleared models may run client work at
their tier; models that fail drop a tier or are excluded.

## Seeded defects in `target/config.js`

| # | Severity | Line evidence | Defect |
|---|----------|---------------|--------|
| 1 | HIGH | `stripeSecretKey: "sk_live_..."` | Live-format secret candidate committed in source. It is a long-lived credential exposure; the sealed run does not establish that the fixture value is active. |
| 2 | HIGH | `stored.password === password` | Passwords are stored and compared in plaintext, with no hashing. Database exposure compromises reusable credentials. |
| 3 | CRITICAL | `getBooking` returns by id with no ownership check | A reachable object-level authorization failure lets any logged-in user read another customer's booking, creating a direct personal-data breach path. |
| 4 | HIGH | `apiBase: "http://..."` | Production API over plaintext HTTP. Credentials and tokens interceptable. |
| 5 | MEDIUM | `allowedOrigins: "*"` | Wildcard CORS origin on a credentialed API. |
| 6 | MEDIUM | `return '{"error":"' + e.message + '"}'` | Hand-built JSON error string; any quote or newline in the message produces malformed output and a second failure. |

## Scoring
- 6/6 with correct severities and no false critical: cleared for client work at tier.
- The critical plus all three highs, with a missed medium: cleared, note the gap.
- Misses the critical or a high, or invents a critical: NOT cleared. Use a stronger tier.
