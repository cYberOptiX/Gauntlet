# Specification fixture answer key (SEALED)

Do not provide this file to the executor.

## Seeded defects

| # | Severity | Evidence | Defect |
|---|----------|----------|--------|
| 1 | CRITICAL | delete old tables immediately after one command | No verified backup, restoration, rollback, retention, reconciliation, or hold period protects customer and billing data, creating a plausible irreversible-destruction path. |
| 2 | HIGH | malformed records may be skipped and handled only after complaints | The design knowingly permits silent customer-record loss with no durable exception ledger or recovery owner. This may be clustered with #1 when one root-cause finding quotes both conditions. |
| 3 | HIGH | credential-bearing database URL in the plan | A privileged database credential is embedded in a shareable instruction artifact. The example host does not lower the unsafe operating pattern below HIGH. |
| 4 | HIGH | counts that “look about right” are the only validation | Aggregate count cannot prove identity, relationships, balances, permissions, completeness, or migration correctness before full rollout. |
| 5 | MEDIUM | authentication and authorization declared outside migration | The plan assumes contract compatibility without verifying ownership and access-control preservation. |
| 6 | MEDIUM | unverified command and laptop execution | The named script, flags, environment, operator authority, audit trail, and reproducibility are unresolved. |
| 7 | MEDIUM | one-step release to everyone | No staged rollout, freeze, monitoring, failure threshold, decision owner, or abort gate is defined. |

## Pass condition

Find the CRITICAL and all three HIGH defects without inventing another CRITICAL. A root-cause finding may cover #1, #2, and #4 only when its evidence quotes and explains each condition. Missing one MEDIUM is a warning.
