# Customer Data Migration Plan

## Goal

Move all customer accounts and billing records to the new database seamlessly over the weekend.

## Steps

1. Friday at 18:00, run `scripts/migrate-production --all --fast` from the engineer's laptop.
2. Delete the old customer tables after the command reports success.
3. Point the application at `postgres://admin:Summer2026@db.example.invalid/customer`.
4. Tell support the migration is complete.

The command may skip malformed records so the migration can finish on time. Those records can be handled later if customers report a problem.

The new API will accept the same fields as the old API. Authentication and authorization are outside this migration.

## Validation

Open the admin dashboard and confirm that the total customer count looks about right. If it does, release the update to everyone.
