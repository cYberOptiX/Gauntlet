# Workbook fixture answer key (SEALED)

Do not provide this file to the executor.

## Seeded defects

| # | Severity | Evidence | Defect |
|---|----------|----------|--------|
| 1 | HIGH | workbook calculation mode is manual | Visible cached values can remain stale after input changes. |
| 2 | HIGH | hidden `Rates` sheet controls visible total | A load-bearing hidden dependency is not disclosed to the user. |
| 3 | HIGH | total formula omits the last data row | The visible total silently excludes one transaction. |
| 4 | HIGH | external workbook formula and external-link part | Results depend on an unavailable external workbook. |
| 5 | HIGH | embedded VBA project | Active code exists and requires review before the workbook can be trusted or shared. |
| 6 | MEDIUM | one formula-region cell is hard-coded | Formula drift makes one row stop responding to input changes. |

## Pass condition

Find all five HIGH findings without inventing a CRITICAL. The structural adapter should at minimum identify manual calculation, hidden sheet, external reference, and macro; semantic review must catch the omitted row and hard-coded island.
