# Standalone HTML fixture answer key (SEALED)

Do not provide this file to the executor.

## Seeded defects

| # | Severity | Evidence | Defect |
|---|----------|----------|--------|
| 1 | HIGH | `sk_live_...` in the delivered script | A live-format payment credential candidate is embedded in a client-readable file; fixture review does not establish that the value is active. |
| 2 | CRITICAL | `innerHTML = location.hash.slice(1)` | URL-controlled markup enters an executable HTML sink without sanitization, creating a direct exploit path. |
| 3 | HIGH | remote tracker script with no disclosure | A supposedly standalone budget artifact executes an external analytics dependency and creates an undisclosed data path. |
| 4 | HIGH | `fetch("/rates.json")` | The core calculation depends on a relative network request that fails under normal file-protocol and offline delivery. |
| 5 | MEDIUM | duplicate `id="amount"` | Duplicate IDs make selectors and label relationships ambiguous. |
| 6 | MEDIUM | second input has no label or accessible name | The private-note control is not named for assistive technology. |
| 7 | MEDIUM | Export button has no handler and TODO remains | A visible promised action is unfinished in the delivered artifact. |

## Pass condition

Find the CRITICAL and all three HIGH findings at correct locations with no invented CRITICAL. Missing one MEDIUM is a warning.
