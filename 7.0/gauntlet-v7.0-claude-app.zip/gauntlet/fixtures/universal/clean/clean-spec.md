# Profile export specification

## Objective

Allow an authenticated account owner to download a JSON copy of their profile data without exposing another account or changing stored data.

## Requirements

- R1: The server derives the account identifier from the authenticated session, never from a request parameter.
- R2: The export contains the documented profile fields and excludes password hashes, session tokens, internal flags, and other users' data.
- R3: The response uses UTF-8 JSON, a stable schema version, and a filename containing no personal data.
- R4: A missing or expired session returns 401 and produces no export body.
- R5: Export generation is read-only, rate-limited, logged without profile contents, and cancellable on disconnect.

## Acceptance

Automated tests cover the owner path, unauthenticated path, attempted cross-account parameter, Unicode data, empty optional fields, rate limit, disconnect, and schema snapshot. The release gate requires all tests to pass in the packaged server configuration.
