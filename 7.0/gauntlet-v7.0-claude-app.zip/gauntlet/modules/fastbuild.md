# Module: Fast-Build Misses — Code-Specific Rushed-Work Sweep

**Activate when:** code was written quickly, with generative tools, by a solo builder, across many sessions, or its history is unknown. **Skip when:** a mature team's reviewed codebase is under a differential review of one small change with known process evidence.

This is the code-specific companion to `slop.md` and `rules/slop.json`. It detects observable defects, never authorship. Each line is a thing to resolve, grep, trace, mutate, or try, not a topic to discuss. Record each as a finding with consequence and proof, a candidate needing adjudication, clean with exact scope, or N/A.

## Secrets and access
- Keys in client code, `.env` committed or once committed (`git log --all -p -S` the key prefix), keys in screenshots, docs, or test fixtures.
- Backend-as-a-service rules left open: Supabase row-level security off, Firebase rules `allow read, write: if true`, storage buckets public. Service-role or admin keys in the client.
- API routes with no auth check, or auth checked only in the UI. IDs in URLs that let one user read another's record.
- No rate limit on login, signup, AI calls, or email sending (a bill or spam problem, not only security).

## Code the AI invented
- Imports of packages that do not exist or are look-alike names (slopsquatting): check each new dependency exists, is the intended one, and is maintained.
- Calls to API methods, flags, or config keys that do not exist in the installed version. Check against the lockfile's version, not memory.
- Tests that assert nothing, mock the unit under test, or were edited to pass. Guards that pass because the thing they look for is never present.
- Two or three copies of the same helper with small differences; dead files from abandoned attempts; commented-out blocks.

## Silent failure
- `catch {}` or `let _ =` on writes, saves, and network calls; promises without `await` or `.catch`; errors logged to a console nobody reads.
- Fallbacks that hide the failure (default values, empty lists) so the UI looks fine while data is missing.
- No error boundary: one render error blanks the whole app.

## Data
- No migrations (schema changed by hand), or migrations never tested on an older real store.
- No backup, no export, no delete. Deleting a parent leaves orphans; foreign keys off.
- Time stored without time zone; dates compared as strings; money as floats; IDs as numbers that overflow JavaScript.
- No pagination or limits: fine at 20 rows, broken at 20,000.

## Leftovers
- `console.log`, debug panels, test accounts, seeded fake data, `localhost` or developer paths, `TODO`/`FIXME`, lorem ipsum, and feature flags left on in the shipped build.
- Hard-coded sizes that break on another screen, locale, or font size.

## Dependencies and build
- Unpinned or wildly outdated packages; known vulnerabilities (OSV, see `toolchains.md`); many packages for one small job.
- Works only on the developer's machine: absolute paths, globally installed tools, a model or file that is not bundled or downloaded.
- No lockfile, or a lockfile that disagrees with the manifest.

## AI features inside the product
- Prompt text built from user or file content with no boundary; model output rendered as HTML or run as code; no timeout, token cap, or cost cap; no behavior when the model is slow, down, or wrong (see `ai.md`).

## Evidence bar

A static match is a candidate, not a conclusion. Resolve invented surfaces against the locked version, force silent-failure paths where safe, trace duplicates to every call site, inspect the packaged output for leftovers, and mutation-test claimed guards. Before any severe finding, check for the control elsewhere. Never write “AI-generated” as a defect; name the observable artifact and consequence.

**Ask:** what did the builder only ever test by clicking the happy path once?
