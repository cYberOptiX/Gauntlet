# Module: Data — Database, Storage, Migrations, Privacy

**Activate when:** the submission stores, collects, or moves user or persistent data. **Skip when:** it is stateless and collects nothing — record that as the reason.

## Database and persistent storage
- Schema: types, relationships, constraints, foreign keys, indexes; queries: correctness and efficiency; N+1 patterns.
- Transactions, concurrency, deadlocks, races; duplicate and orphaned records; corruption paths.
- Migrations: safety, rollback, schema evolution; connection management and pooling.
- Backups and — separately — verified restoration; encryption; access control on the store itself.
- Growth: data volume, storage cost, archiving, retention.

## Data lifecycle
- Where every class of data lives across its life: created → stored → cached → transmitted → backed up → exported → deleted. Gaps between "deleted in the app" and "gone from disk/backups" are findings.
- Consistency between stores (DB vs cache vs index vs files) and who wins on conflict.

## Privacy
- What is collected, why, and whether it is necessary — excessive collection is a finding even when legal.
- Tracking, analytics, telemetry, device identifiers, location, contacts, background collection, profiling.
- Consent and its withdrawal; third-party sharing; retention; account and data deletion; user export.
- Privacy defaults (private by default or not); sensitive data leaking into logs, URLs, notifications, or crash reports.

## Regulatory exposure (when personal data is handled)
- **Privacy law follows the user, not the developer.** A developer in one country who distributes to users in another is generally subject to that country's data protection law: GDPR and UK GDPR apply extraterritorially to anyone offering services to or monitoring people there, and the app stores' developer agreements separately make compliance in every distribution territory contractual. Targeting decides "offering" — storefront availability, language, currency, marketing — not the developer's nationality. Worldwide distribution means worldwide obligations.
- From what the code demonstrably collects and where distribution is intended, name the regimes plausibly in play — EU and UK GDPR, US state privacy laws (California and successors), COPPA wherever children can plausibly use it, LGPD (Brazil), PIPL (China), DPDP (India), PDPL (UAE, Saudi Arabia), PIPEDA (Canada), and others — labeled confirmed, likely, or possible. Regimes and thresholds change: verify current requirements with live sources during the run before a finding cites specifics.
- Obligations to check for concrete evidence of: a published, reachable privacy policy that matches actual collection; lawful basis or consent for tracking and marketing; data subject rights (access, deletion, export) that the system can actually fulfill; breach notification capability; a local representative where required for foreign controllers (EU/UK); processor agreements behind third-party services; age gates where minors are plausible users.
- **Never fabricate a legal conclusion.** The review names the exposure, the evidence, and the missing artifacts; a qualified lawyer confirms obligations. Recommend counsel explicitly for any cross-border distribution — the cost of the review is noise against one regulator's fine.

## Submitted datasets (when the artifact is or contains a data file)
- Scan for personal or sensitive information embedded in the data itself; check for a stated license or terms of use and whether the intended use honors them; note re-identification risk in data claimed to be anonymized.

**Ask:** name one record — where does it live, who can read it, and what actually happens when the user deletes it? And under whose country's law does its owner live?
