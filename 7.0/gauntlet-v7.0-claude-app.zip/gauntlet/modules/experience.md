# Module: Experience — UI, UX, Accessibility, Internationalization

**Activate when:** the submission has a user-facing surface. **Skip when:** it is headless — say so.

**Evidence note:** static review sees structure and code, not pixels. Layout and interaction claims from unrendered code are [derived]; recommend rendering or device testing when it matters.

## UI
- Layout, alignment, spacing, typography, hierarchy; overflow, clipping, overlap; responsive behavior.
- Component states: loading, empty, disabled, error, success, hover, focus, selected — missing states are findings, not polish.
- Consistency across components; feedback for every action the user takes.

## UX
- Learnability and discoverability; workflow efficiency; excess steps and friction; cognitive load.
- Poor defaults; misleading or dangerous controls; destructive operations without confirmation or undo; recovery paths; error messages a human can act on.
- Onboarding and guidance proportional to the audience; behavior matching user expectations; anything that erodes trust.

## Accessibility (increasingly a legal requirement, not polish)
- WCAG 2.2 is the reference standard. The European Accessibility Act covers e-commerce and many digital services serving the EU (in force June 2025); US ADA litigation targets consumer websites and apps. A booking, shopping, or service app serving those markets treats accessibility gaps as compliance findings, not cosmetics — see `sources.md`.
- Keyboard navigation, focus order, focus visibility; screen-reader semantics, labels, alt text.
- Contrast, text scaling, zoom; color never the only signal; touch-target size.
- Motion and flashing content; reduced-motion and high-contrast support; captions/alternatives for media; OS accessibility settings honored.

## Cookie consent and web tracking (websites serving regulated markets)
- Analytics, advertising, or tracking cookies set before consent is a GDPR/ePrivacy finding for any site reachable by EU or UK visitors; a consent banner that only offers "accept" fails. Check what loads before interaction and whether refusal is as easy as acceptance.

## Internationalization (when multi-locale use is plausible or claimed)
- Encoding and Unicode; hard-coded strings; text expansion breaking layouts; RTL.
- Date, time, number, currency, and unit formats; time zones; locale-aware sorting and searching; translation completeness.

**Ask:** where does a normal user get stuck, lose work, or destroy something by accident — and what does the design do about it?
