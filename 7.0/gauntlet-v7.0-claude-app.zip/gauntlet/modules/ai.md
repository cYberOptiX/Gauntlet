# Module: AI and Agent Systems

**Activate when:** the submission contains AI, LLM, or agent functionality — as a feature, a pipeline, or an autonomous system. **Skip when:** no model is in the loop. (A prompt or agent-instruction file as the review target itself takes the REBUILD track and its prompt lens; this module covers AI *inside* a reviewed system.)

## Model and routing
- Model selection fit for the task and cost tier; routing between models; behavior when the model changes underneath (upgrades, deprecations); provider outages and fallbacks.

## Prompt and context
- Prompt construction: injection points where user or retrieved content enters; instruction conflicts; system-prompt leakage.
- Context handling: overflow, truncation, contamination between users or sessions; retrieval quality and grounding; hallucination exposure where outputs are trusted downstream. Local runtimes can cut an oversized prompt without any error (Ollama uses its small default window unless `num_ctx` is sent): text sized to the model's advertised window must also request that window.
- Retrieval integrity: an embedding dimension or model mismatch can make ranked recall fall back to arbitrary results while looking healthy. Check the stored dimension against what the embedder emits.
- Self-description drift: what the model says about its own abilities comes from several surfaces (tool descriptions, app map, system prompt). Tool descriptions usually win; check that all surfaces agree and actually reach the prompt on the real code path. Positive instructions hold better than bans.

## Tools and autonomy
- Tool access and permissions: what the model can touch, and what limits execution; unsafe tool execution paths (shell, file writes, network, payments).
- Autonomy bounds: loop limits, runaway-action containment, human-approval boundaries for irreversible or outward-facing actions; failure containment when the model is wrong.

## Memory
- What persists, who wrote it, and whether stored content can steer future behavior (memory poisoning); incorrect memory correction paths; sensitive data retained in memory or logs.

## Output
- Validation of structured output; downstream consumers trusting unvalidated model text; fallback when the model fails or refuses.

## Cost and latency
- Token consumption per operation and its growth with usage; latency on user-facing paths; caching; cost at plausible scale.

**Ask:** feed it a hostile input and a wrong-but-confident model answer — what is the worst real-world action this system takes before a human can stop it?
