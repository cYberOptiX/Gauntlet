# Module: Platform — Mobile, Desktop, Web, and Delivered Artifacts

**Activate when:** the submission targets a specific platform, or is itself a delivered file artifact. Activate only the matching subsections — never the whole module by reflex. `artifacts.md` supplies the universal adapter contract; `spreadsheets.md` owns workbook depth.

## Mobile (iOS / iPadOS / Android)
- Screen sizes, orientation, safe areas; touch targets and gestures; keyboard behavior.
- Lifecycle: background/foreground, suspension, termination, state restoration; low-power and thermal behavior.
- Permissions (camera, mic, photos, contacts, location, Bluetooth, biometrics) — requested minimally, degrading gracefully when denied.
- Notifications, deep/universal/app links; offline operation; cellular vs Wi-Fi; battery and data cost; OS-update exposure; accessibility settings and font scaling.

### Store submission readiness (when store distribution is intended)
Split every item into what the repo can prove and what only the store console holds; report the console group as a submission checklist, never as silently skipped.
- Verifiable here: in-app privacy policy and terms links present AND resolving — fetch them live; a 404 legal page fails review exactly like a missing one, and users are agreeing to documents that do not exist. In-app account deletion flow (Apple requires it for any app with accounts; Play adds a web deletion link). Permission purpose strings. iOS privacy manifests where required-reason APIs are used (app-level and plugin-level). Sign in with Apple present if any third-party login is offered. Payment method fits store rules: physical goods and services may use external payments; digital content must use in-app purchase.
- Console-side checklist (CANNOT VERIFY from a repo): privacy policy URL field; App Privacy labels / Play Data safety form matching what the code actually collects; descriptions, screenshots, content rating, support URL; target API level at submission time.
- The legal documents themselves must exist, be reachable, and match actual data collection — flag divergence between what the code collects and what the published policy discloses (readable policy text permitting).

## Desktop (macOS / Windows / Linux)
- Install, uninstall, update, rollback; residue on removal; signing and notarization/SmartScreen where the OS demands it.
- File-system and OS permissions; sandboxing; startup items and background services; registry (Windows) hygiene.
- macOS privacy grants (Accessibility, Screen Recording, Microphone, Automation) are tied to the code-signing identity: an app re-signed ad hoc on every build loses them each time. Check for a stable signing identity.
- Webview shells (Tauri, Electron): packaged builds enforce a CSP the dev server does not; in Tauri a style nonce voids `'unsafe-inline'`, so runtime-injected stylesheets fail silently. Translucent or glass window surfaces can bleed through popovers and menus unless those carry their own solid background.
- Windows/menus/tray, multi-monitor, DPI scaling, keyboard shortcuts, drag-and-drop, file associations, clipboard; sleep/wake and user switching; local storage and databases.

## Web application / website
- Client and server logic split; routing; forms; broken links and navigation; redirects and open redirects; URL and query-parameter hygiene.
- Cookies, sessions, localStorage/sessionStorage/IndexedDB; service workers and caching; security headers, CSP, CORS, CSRF, clickjacking (XSS lives in `security.md`).
- Browser compatibility; responsive and mobile layouts; third-party scripts and CDN dependencies; console and network errors; metadata; progressive enhancement and offline behavior where expected.

## Interactive HTML file (standalone)
- Validity of HTML/CSS/JS; runtime errors; event handlers; dynamic DOM.
- Self-containment: external scripts, fonts, images, and CDN calls that break offline or under file:// and sandbox restrictions; cross-origin behavior.
- Local-file restrictions (storage, fetch, downloads) in the environment it will actually open in; browser compatibility; responsive behavior.
- Unexpected network connections, tracking, embedded secrets, and any executable behavior the user did not ask for — a standalone file that phones home is a finding.

## Browser extension
- Manifest version and its policy implications; host permissions scoped narrowly or a wildcard over every site; content-script injection breadth; `externally_connectable`; any remote code load (banned by current store policy); background/service-worker persistence.
- Data leaving the browser and to where; the extension's own store policies (Chrome Web Store, Firefox AMO, Edge) as a separate gate from app stores.

## Cloud and infrastructure configuration
- Public storage buckets; security-group or firewall ingress open to `0.0.0.0/0`; wildcard IAM actions or resources; over-broad service accounts; `privileged` containers; secrets in environment blocks or committed state files.
- Terraform/CloudFormation/Kubernetes/Docker manifests read as configuration, not code: what does this provision expose to the public internet, and with what privilege.

## File and artifact integrity (any submitted file)
- Type matches extension and claim; structure valid; truncation or corruption.
- Embedded executable content, scripts, macros; hidden metadata, credentials, personal information, URLs.
- External and broken references; version info; excessive size; anything suspicious for its type — the inspection path follows the file type, not a fixed list.
- Inventory the artifact-native surfaces in the review manifest: pages and objects, tracks and channels, sheets and cells, archive entries, forms and fields, frames, metadata namespaces, or the nearest valid coordinate system.
- Route spreadsheets to `spreadsheets.md`; documents, media, archives, binaries, and unfamiliar types to the matching section of `artifacts.md` and first-party rule pack.
- Parsing success proves readable structure only. Semantic correctness, runtime behavior, rendering, rights, accessibility, and intended delivery remain separate checks.
