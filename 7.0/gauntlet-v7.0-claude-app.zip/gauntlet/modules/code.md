# Module: Code — Correctness, Quality, State, Concurrency, Behavior

**Activate when:** source code is available, at any size. **Skip when:** no code was supplied — design-level concerns belong to `design.md`.

**Evidence note:** code findings cite file, function, and line. Behavior not exercised here is [derived] or [unverifiable here], never [verified].

## Correctness
- Parse/compile/build state as supplied; runtime and logic errors; type, reference, and null/undefined handling; incorrect conditions, calculations, loops; infinite loops and unbounded recursion.
- Broken control flow and state transitions; incorrect transformations and return values; initialization and cleanup errors.
- Exception handling: swallowed exceptions, silent failures, improper fallbacks; error propagation; improper state mutation and unintended side effects.
- Resource leaks: memory, connections, file handles, threads, timers, listeners.
- Dead, unreachable, duplicate, and unused code; unused variables and dependencies; hard-coded values and magic numbers; fragile assumptions; unsafe operations.

## Functionality and edge cases
- Do the features, workflows, and states actually behave as intended — including error states, not just the happy path? Broken, incomplete, or impossible workflows; feature interactions and conflicts; missing, duplicate, or wrong results.
- Boundaries: empty/null input, min/max and extreme sizes, invalid and corrupt input, special characters and Unicode, long names and paths, large/empty/missing/duplicate files, rapid repeated input, interrupted actions.
- Environment shifts: termination mid-operation, network loss, permission loss, expired credentials, full disk, low memory, clock/time-zone/DST changes, locale changes.

## Error handling
- Detection, propagation, and messaging for both users and developers; retry, recovery, and fallback behavior; partial failures; error loops.
- Sensitive information in error output; errors that offer no corrective path; crashes that corrupt state on the way down.

## State
- Application, session, UI, server, cached state: synchronization, staleness, invalid or impossible states, restoration after unexpected termination.
- Transitions: background/foreground, offline/online, multi-tab, multi-window, multi-device.

## Concurrency (when parallelism exists)
- Races, deadlocks, livelocks, contention; thread safety and shared state; atomicity and ordering assumptions; duplicate execution; cancellation; parallel writes; simultaneous users/requests.

## Engineering quality
- Readability, naming, organization, modularity, testability; complexity and nesting; oversized units and god objects; duplicate logic; tight coupling; weak, excessive, or premature abstraction; inconsistent patterns.
- Misleading/outdated comments; TODO/FIXME/deprecated markers; workarounds and hacks — each with its consequence, not as style policing.

**Ask:** what input, timing, or interruption did the author never imagine — and what does the code do when it arrives?
