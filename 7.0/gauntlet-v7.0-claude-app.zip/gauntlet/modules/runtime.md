# Module: Runtime — Performance, Reliability, Resilience

**Activate when:** the submission executes; design-level for plans. **Skip when:** it never runs.

**Evidence note:** measured numbers are [verified]; complexity analysis from code is [derived]; anything else is a test recommendation, not a finding.

## Performance
- Startup, response, and processing time; rendering; API and database latency.
- CPU, GPU, memory, disk, network, battery, thermal cost; background usage; memory growth and leaks over time.
- Waste patterns: excessive polling, chatty network or query behavior (N+1), inefficient loops and algorithms on hot paths, cache misuse, oversized assets and bundles, slow dependencies on the critical path.
- Judge against the plausible workload from Phase 2, not an imagined one.

## Reliability and resilience
- Crash paths: application, service, component; what a crash takes down with it and what state it leaves behind.
- Dependency, database, network, and storage failures; partial and cascading failures; graceful degradation vs hard stop.
- Recovery: restart, resume, failover, redundancy; retries and circuit breakers; interrupted updates and transactions; disaster recovery and restoration where the system's importance warrants it.
- Observability of failure: will anyone know it broke, or does it fail silently? (Instrumentation details live in `operations.md`.)

**Ask:** kill it at the worst moment — mid-write, mid-update, mid-sync. What is on disk, and what happens on the next launch?
