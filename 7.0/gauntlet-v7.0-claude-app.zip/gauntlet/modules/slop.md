# Module: AI-Slop and Rushed-Work Evidence

**Activate when:** history is unknown, work was produced quickly or across many generated iterations, the target has suspiciously generic or inconsistent output, or the user asks for AI-slop detection. This module applies to code, interfaces, standalone HTML, spreadsheets, plans, documents, prompts, and mixed artifacts.

**Non-negotiable:** detect residue, never guess authorship. A finding must identify an observable artifact, a real consequence, and proof. “Looks AI-made” and detector scores are not evidence of who created the work.

Use `rules/slop.json` with the matching artifact pack. The static engine can produce candidate locations for secrets, placeholders, local paths, empty catches, and debug residue; every candidate still requires context and counter-evidence.

## Code and vibe-built systems

- Fabricated packages, APIs, methods, flags, versions, files, commands, or environment keys. Resolve against the locked environment rather than memory.
- Tests that assert nothing, mock the behavior they claim to test, update snapshots around a defect, or cannot fail under a restored fault.
- Duplicate implementation islands, abandoned files, incompatible patterns, stale comments, and local patches that violate another contract.
- Silent catches, empty or plausible fallback data, optimistic success messages, and failures visible only in a console nobody reads.
- Half-wired UI, dead controls, placeholder routes, disabled security, public backend rules, missing migrations, unbounded data, local paths, debug behavior, and fake data in shipping output.
- Excessive wrappers, indirection, comments, types, or configuration that add volume but no enforced invariant.

## Visual and interaction residue

- Generic component arrangements, arbitrary decorative effects, stock language, unearned metrics, and visual choices that do not derive from the product's subject, user, or hierarchy.
- Conflicting spacing, type, radius, color, icon, motion, and interaction grammars; count unexplained one-offs rather than asserting a feeling.
- A polished happy path beside absent loading, empty, error, denied, offline, overflow, accessibility, and recovery states.
- Motion or controls that appear interactive but do not change meaningful state, output, navigation, or accessible semantics.

## Standalone HTML residue

- Works only in a builder or server, not in the delivered file-protocol and offline context.
- Hidden network calls, CDN dependencies, analytics, remote fonts, or uploads inside a supposedly self-contained artifact.
- Dead event handlers, duplicate IDs, uncaught errors, controls with no accessible name, failed downloads, and export that omits current state.
- Hard-coded demo content, fake controls, placeholder copy, or screenshot-like UI with no underlying behavior.

## Spreadsheet residue

- Formula drift, hard-coded values inside calculated regions, totals that omit newly added rows, stale cached results, and inconsistent anchors.
- Formatting that makes mixed raw types look consistent; blank or zero formulas that conceal errors.
- Hidden sheets, names, links, macros, and local paths controlling visible results without disclosure.
- Decorative dashboards with no trace from a displayed metric to source cells and business definition.

## Plans, specs, prompts, and documents

- Fluent claims such as secure, scalable, intuitive, automatic, or production-ready without measurable behavior, ownership, failure semantics, or acceptance proof.
- Long checklists with no applicability, dependency graph, exception handling, decision authority, evidence, or exit gate.
- Repeated filler, contradictory names for the same concept, stale or invented references, and examples that conflict with governing rules.
- Requirements copied into several sections with different force instead of one governing home and explicit references.

## Finding bar

Before recording a slop finding, answer:

1. What exact artifact or repeated pattern exists, and where?
2. What requirement, contract, state, or quality bar does it violate?
3. What consequence does it create for a user, maintainer, operator, or downstream system?
4. What deterministic check, runtime observation, comparison, or mutation proves it?
5. What benign explanation or mitigating control was checked?

If those answers are unavailable, record an investigation candidate or INFO opportunity, not a defect and never an authorship claim.
