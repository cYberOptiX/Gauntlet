# Module: Design — Requirements, Architecture, Scalability

**Activate when:** the submission is a plan, spec, or architecture, or any system whose structure is visible or described. **Skip when:** the submission is an isolated snippet with no design surface.

**Evidence note:** from a document, these are design findings ("the plan does not specify X"); from code, they are structural findings with locations. Never claim implementation defects from a document.

## Requirements and design intent
- Purpose, intended users, problem solved, primary and secondary workflows — stated, coherent, and mutually consistent.
- Functional and nonfunctional requirements: missing, contradictory, duplicated, ambiguous, or untestable ones; undefined behavior; hidden or unsupported assumptions.
- Feasibility on the stated platform and stack; requirement and feature dependencies; success, acceptance, and failure criteria present and checkable.
- Omitted edge cases at the design level; feature conflicts; scope problems in both directions — overengineering and underengineering are both findings.

## Architecture and system design
- Suitability: is this architecture right for what the system is expected to become, not merely capable of running today?
- Component structure, module boundaries, separation of concerns, dependency direction, coupling and cohesion, circular dependencies.
- Data, control, and state flow; client/server and frontend/backend responsibility split; service boundaries.
- Single points of failure; bottlenecks; architectural dead ends; decisions that make plausible future features unnecessarily hard.
- Cross-cutting architectures where the system claims them: auth, API, caching, queues, background work, offline, sync, updates, logging, recovery, backup.
- Extensibility and replaceability; vendor dependencies and lock-in as architectural facts.

## Scalability (proportional to plausible use — rule 7)
- Growth axes that actually apply: users, concurrency, data volume, file count/size, traffic, integrations, features, cost.
- Hard limits and soft limits; where the first bottleneck appears and at what rough scale; storage and cost growth curves.
- Never criticize a personal tool for failing hyperscale it will never see; do flag the ceiling when the stated ambition exceeds it.

**Ask:** if this succeeds and doubles twice, what breaks first — and was that choice deliberate?
