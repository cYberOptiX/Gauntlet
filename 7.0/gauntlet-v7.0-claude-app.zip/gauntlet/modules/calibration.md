# Module: Calibration — Universal Fixtures, Executor Tiers, Finding Contract

**Activate:** every run for the finding and evidence contract. Execute the fixture gate before any non-frontier executor's first real run, after a model or strategy change, and before releasing changes to Gauntlet itself. This module carries the knowledge a strong model holds implicitly, so a weaker one does not have to guess.

## Executor tiers (by capability, not model name)

Classify the executor before starting. Names are current examples; the tier is what matters.

- **Frontier** — large hosted models (Fable, Sol, Opus-class). Run the protocol as written, full context, all modules in one pass if desired.
- **Heavy local** — the flagship local tier, ~120B-class. The primary review models when no frontier model is reachable: **qwen3.5:122b, gpt-oss:120b, nemotron-3-super:120b** (laguna-s-2.1 and nemotron3:33b at its best also qualify). Capable of a full REPORT run, but still follow the small-context protocol below because local context windows are short by default. Clear each on the fixture once before its first client job.
- **Mid local** — ~20B to 35B (qwen3.8:27b, qwen3.6:35b, nemotron-3.5-lightning:30b, gemma4:26b/31b, gpt-oss:20b, ornith:35b). One module per pass, ledger between passes, quote-then-claim enforced, fixture gate required before any client job.
- **Light** — under ~10B (gemma4:e2b/e4b). Not for client reviews. Acceptable only for a single narrow mechanical pass (for example, one secret sweep) whose output a higher tier re-verifies.

**Embedding models** (qwen3-embedding:8b) are not executors; they retrieve, they do not review.

## Universal fixture gate (prove the system before trusting it)

Before a non-frontier model runs real work, and before any release that materially changes the core, engine, adapters, rule packs, severity policy, or verifier, run the locked suite in `fixtures/universal/manifest.json` plus the original source-code fixture. Keep every `ANSWER_KEY.md` sealed from the executor. The suite manifest hash-locks both targets and answer keys; a severity-policy change requires an explicit answer-key revision, new declared hashes, and an owner-side comparison record rather than a silent rescore.

The minimum gate is universal, not code-only:

- **Seeded targets:** source code, standalone HTML, specification, and workbook. Find every seeded CRITICAL and HIGH at the correct artifact-native location.
- **Clean controls:** raise no unsupported CRITICAL or HIGH. One false severe finding fails the gate exactly as a missed severe defect does.
- **Mechanics:** manifest validation, adapter receipts, finding fingerprints, delta behavior, and coverage gate tests must pass.
- **Mutation:** where a fixture represents a guard or correction, restoring the defect must make the guard fail.

A model or release that misses a CRITICAL/HIGH, invents one on a clean control, leaks a seeded secret value into a receipt, or returns READY with incomplete mandatory coverage is not cleared. Drop the executor tier or block the release. MEDIUM misses are recorded as calibration debt until the suite has enough fixtures for stable per-family thresholds.

Run the first-party mechanical gate from the skill root with `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v`. It validates locked fixture hashes, deterministic workbook generation, clean controls, redaction, adapters, Git scopes, target and finding fingerprints, verifier behavior, re-review deltas, gate policy, schema invariants, and report hardening. Passing mechanics does not replace the sealed-answer-key review by the selected executor.

## Small-context protocol (heavy local and below)

1. Do Phase 0-2 once. Create the universal manifest with `engine/gauntlet.py`, then write the target identity, classification, criteria, assumptions, unknowns, and applicability decisions to the run ledger.
2. Run **one module or adapter group per pass**. Load only that material, the relevant manifest surfaces, and the candidate ledger defined by `schemas/candidate-ledger-schema.json`. Append findings in the full v7 finding shape.
3. End each pass by marking its surfaces and checks. A module pass with no findings still records scoped pass evidence; silence is not completion.
4. Never hold all modules or an unbounded repository in context at once. The manifest is coverage memory; the ledger is reasoning memory; receipts are tool memory.
5. After discovery, run a separate verifier pass over candidate findings, quotes, anchors, counter-evidence, fingerprints, severity, and duplicates. The discovery pass does not approve itself.
6. Load only the verified ledger, gate result, and required target fragments for correction and delivery.
7. Re-reviews compare ledgers with the native engine. A finding absent from a later pass remains `not_rechecked` until explicit evidence changes its state.

## Quote-then-claim (all tiers, enforced for local)

Write the evidence before the conclusion. Every code finding leads with the quoted line and its location, then states what is wrong. A finding with no quote is not ready to record. This suppresses hallucination in weak models and makes every report defensible to a client.

## The finding template (copy these fields exactly)

```
ID:          F-NN
FINGERPRINT: GF-<stable digest>
RULE:        first-party rule ID or domain
SURFACES:    manifest surface IDs
CRITERIA:    R/C IDs or universal gate
TITLE:       one line, the defect, not the topic
SEVERITY:    CRITICAL | HIGH | MEDIUM | LOW | INFO
HORIZON:     active | emerging (trigger) | future (trigger)
EVIDENCE:    concise supporting observation
EVIDENCE_CLASS: verified_fact | derived_inference | judgment | unverifiable_risk
EVIDENCE_METHOD: exact check, derivation, or missing proof
EVIDENCE_SCOPE: what the evidence covers and does not cover
EVIDENCE_REFS: receipt, command, URL + fetch date, or artifact coordinate IDs
CONFIDENCE:  high | moderate | low
LOCATION:    artifact-native coordinate
ANCHOR:      type + coordinate + resolved true/false (+ quote hash when raw material must stay local)
QUOTE:       the exact material the finding rests on, or a redacted description tied to a local receipt
FOUND:       what is wrong
WHY:         what it costs, and to whom
ROOT_CAUSE:  immediate cause and governing cause; list every manifestation
COUNTER:     the mitigating control looked for, and whether it exists
STATUS:      open | fixed | regressed | accepted | withdrawn | not_rechecked
DISPOSITION: FIX (concrete change) | WAIVE (reason) | ASK | BLOCK | INFO
REGRESSION:  what the correction can break and what must be retested
VERIFICATION: exact check that settles the finding
FIRST_SEEN_REVISION: target revision where the finding entered the ledger
WATCH:       recheck date + exact re-test, only if it depends on external state
```

**Worked example (copy this shape):**
```
ID: F-02
FINGERPRINT: GF-a156761fcb53d4b14f11c630
RULE: CODE-STATE
SURFACES: S-0f6a99b024d3
CRITERIA: C-SESSION-RECOVERY
TITLE: Session refresh disables itself permanently after first forced logout
SEVERITY: HIGH
HORIZON: active
EVIDENCE: the reset function has no login or resume caller
EVIDENCE_CLASS: verified_fact
EVIDENCE_METHOD: traced every reference to the reset function in the bound source revision
EVIDENCE_SCOPE: session repository source paths; packaged runtime was not exercised
EVIDENCE_REFS: source-receipt.json#api_wrapper.dart; S-0f6a99b024d3
CONFIDENCE: high
LOCATION: lib/data/repositories/api_wrapper.dart : 24, 84, 310
ANCHOR: line-range | lib/data/repositories/api_wrapper.dart:24,84,310 | resolved true
QUOTE: "static bool _isLoggingOut = false;" ... reset only called inside _requestRefreshToken
FOUND: the flag that blocks refresh is only reset inside the flow the flag itself blocks
WHY: returning users hit permanent silent API failure until they force-quit; no crash reaches support
ROOT_CAUSE: logout state is owned by the refresh branch rather than the session lifecycle; all login and resume paths share the omission
COUNTER: looked for a reset on login and on app resume — neither exists
STATUS: open
DISPOSITION: FIX — reset the flag on successful login and on app resume
REGRESSION: a reset during an active logout could duplicate refresh; retest concurrent logout, login, and resume
VERIFICATION: force logout, log in again, expire the token, and prove refresh succeeds; restore the omission and prove the test fails
FIRST_SEEN_REVISION: <target revision>
WATCH: n/a
```

## Severity anchors (calibrate every run against these)

- **CRITICAL** — remote data breach of personal or payment data; auth bypass; silent money loss or double charge; irreversible data destruction; shipping a working exploit path.
- **HIGH** — release cannot build; a shipped feature is broken in normal use (session, push, payments); long-lived credentials in plaintext; dead legal pages on a data-collecting app; sensitive identity data with no lifecycle.
- **MEDIUM** — failure with a contained blast radius: no error feedback on a failing action, personal data in device logs, a startup race masked only by luck, one production-only environment.
- **LOW** — dead code, an unused permission, logout residue, a mislabeled declaration, mixed dependency pinning.
- **INFO** — a real improvement that is not a defect: missing tests, no crash reporting, no localization scaffolding, template documentation.

Severity is consequence times likelihood. A theoretical flaw nobody can reach drops a level; a small flaw on the payment or identity path rises one.
