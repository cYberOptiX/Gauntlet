# Module: Dependencies — Supply Chain, Integrations, Compatibility

**Activate when:** the submission depends on packages, external services, or specific platform/runtime versions. **Skip when:** it is fully self-contained — verify that claim, don't assume it.

## Supply chain
- Inventory: libraries, frameworks, SDKs, plugins — runtime, dev, build, and transitive.
- Known vulnerabilities (check with tools when a manifest is available; otherwise flag as unverified); deprecated, abandoned, or unmaintained packages; problematic maintenance histories.
- Version pinning and drift; an exact-version gate on a dependency that updates itself (a local model runtime, a browser, an OS service) is a time bomb that fails closed on the next silent update, often into an endless retry loop; version conflicts; package origin and integrity; typosquatting and dependency-confusion exposure.
- Excessive dependency count for what the code does; licensing of each dependency; dependencies likely to disappear or break compatibility — with the plausible trigger named.

## External APIs and integrations
- Contracts and schemas; request/response validation; auth on the integration itself.
- Failure handling: timeouts, retries and retry storms, idempotency, rate limits, pagination, partial failures, provider outages, unexpected responses, duplicate requests, ordering.
- Versioning and deprecation exposure; webhook/callback verification; provider lock-in and the exit cost.

## Compatibility
- Supported OS, browser, runtime, framework, and API versions — stated vs actual; device generations and architectures where relevant.
- Backward compatibility with existing user data and previous versions; forward compatibility where the design claims it.
- Network environments (proxy, captive portal, IPv6, offline) when the submission is networked.

**Ask:** which single dependency or provider, gone tomorrow, hurts most — and is there any plan for that day?
