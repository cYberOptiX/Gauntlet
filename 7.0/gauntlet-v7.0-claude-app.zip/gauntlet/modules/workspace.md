# Module: Workspace — Working Copies, Build Outputs, Agent Hygiene

**Activate when:** the target is a repository, a project folder, or a project built across many sessions or by delegated agents. **Skip when:** the target is a single pasted file or a plan with no folder behind it.

**Standard:** one canonical folder per project. Every other working copy has a named, current reason to exist, or it is a finding. The folder that holds the history is never the one mistaken for disposable.

## Map every working copy (read-only)
- `git rev-parse --git-common-dir` and `git worktree list` from the target: which folder holds `.git`, and every folder sharing it. A worktree's `.git` is a small pointer file; the folder with the real `.git` directory is the home.
- Symlinks into the repo (`ls -la` the parent), sibling folders carrying the project name, nested `workspaces/` trees, and detached-HEAD worktrees nobody owns.
- Folder names that lie: a folder named for one milestone holding another branch; a folder named `-main` that is not the history's home. Handoff docs, memory, and scripts that point at a path must point at the canonical one; a stale path reference is a defect.
- Size by component (`target/`, `node_modules/`, caches) versus source. Large numbers are usually rebuildable cache, not versions; say which.

## Before any copy is called safe to remove
- Every branch it carries is pushed or merged. Squash merges leave "1 commit not in main" on a merged branch: confirm by PR state or tree diff, never by `rev-list` count alone.
- `git status --porcelain` is empty, and `git status --ignored` is read: ignored does not mean worthless. Vaults, local databases, `.env`, kickoff docs, agent logs, and engine caches live there, and none of it is in any commit.
- Removal goes through `git worktree remove` (it refuses dirty trees), never `rm -rf` on a worktree. Anything worth keeping moves first; the report names where it went.

## Build outputs versus source
- Build caches bake in absolute paths: after a folder move or rename, the cache is stale and must be cleaned before a build or test result counts. Dependency folders go stale after large branch moves: reinstall before trusting a red suite.
- Artifacts the normal start command does not rebuild (bundled sidecars, embedded frontends, release binaries) drift from source silently. Verify what the running or installed artifact contains: the built asset files, their mtime against the install, and an embedded revision stamp. Never `strings`-grep a binary for compressed frontend code; absence there proves nothing.
- Retention: current build plus one previous. Rollbacks live in a backups folder, not beside the installed app. Check whether the install script rotates; if not, strays accumulate.
- A distributable build carries zero personal secrets, keys, vault data, or owner-specific provider config.

## Delegated-agent hygiene
- Agent logs and scratch folders are never committed and are archived, not lost, when a copy is removed.
- A delegated worker can edit outside its brief (formatters are the usual cause). Compare a full-tree manifest before and after, not only the named files.
- Undo your own edit by reversing it, not by `git checkout` of a path that may hold someone else's uncommitted work. Quote heredocs (`<<'EOF'`) so prose with backticks cannot execute.

**Ask:** if the owner kept one folder and deleted the rest, which folder must it be, and what would be lost?
