# Module: Security — Surface, Auth, Injection, Secrets, Network, Abuse

**Activate when:** anything executable, networked, multi-user, credentialed, or handling untrusted input; at design level for plans. **Skip when:** purely inert content with no execution or data surface — and say so, scoped.

**Evidence note:** a confirmed vulnerability in code is CRITICAL/HIGH with a location; an unspecified control in a plan is a potential risk. Never conflate them (rule 4).

## Attack surface and security architecture
- Entry points, external and internal interfaces, trust boundaries, privilege boundaries; where would a deliberate attacker start?
- Unsafe defaults, fail-open behavior, missing defense in depth, excessive privilege; admin/debug/dev interfaces reachable in production.
- Client/server and local/remote trust assumptions — anything the client asserts that the server believes.

## Authentication
- Registration, login, password storage (hashing, not reversible), reset and recovery flows, MFA.
- Sessions and tokens: creation, expiration, invalidation, storage location, refresh, revocation, persistence.
- Bypass paths, brute-force and credential-stuffing resistance, user enumeration, default or hard-coded credentials, weak recovery.

## Authorization
- Roles and permissions; resource ownership checks; object-level and function-level authorization; horizontal and vertical escalation.
- Client-side-only authorization is a finding wherever a server exists; least privilege across file, DB, API, OS, cloud, and service-account permissions; inheritance and revocation.

## Input, output, and injection
- Validation and sanitization at every trust-boundary crossing; output encoding.
- SQL/command/code/script/template/header/log injection; XSS; path traversal; unsafe deserialization; dynamic SQL or shell built from user input; user-controlled paths.
- Malformed, oversized, and malicious input; dangerous uploads and filenames; Unicode and encoding tricks; regex DoS.

## Secrets
- Keys, tokens, passwords, certificates, private keys, credentials — in source, config, env files, repos, logs, build artifacts, client-side code, embedded HTML/JS.
- Storage, distribution, rotation, expiration. A secret shipped to the client is exposed, full stop.

## Data security
- Sensitive data inventory; encryption at rest and in transit; exposure via local storage, cache, temp files, clipboard, logs, backups, exports.
- Exfiltration paths; retention and secure deletion; unauthorized-access consequences.
- **Payment data is its own tier.** Card details must never touch the app's own storage, logs, analytics, or crash reports. Tokenized SDK flows (hosted payment sheets and elements) keep the app out of card-data scope; a hand-rolled card form pulls the whole system into PCI DSS territory — flag it on sight. Check payment and identity screens for screenshot, app-switcher, and screen-recording exposure where the platform offers control.
- **Inventory every leak channel, not just storage:** third-party SDKs shipping data off-device, clipboard, system logs, device backups, URLs and deep links carrying tokens or identifiers, push notification payloads, webviews sharing sessions, and error reporters capturing request bodies. Each one is a data path; when personal or payment data flows, each gets a line in the sweep — found, clean with scope, or CANNOT VERIFY.

## Network
- TLS and certificate validation; plaintext protocols; open ports and unnecessary services; MITM exposure on untrusted networks; replay; webhook/callback verification; behavior under interception, proxying, and offline.

## Abuse and adversarial use
- Automated abuse, scraping, spam, fraud; rate-limit bypass; parameter and client tampering; resource abuse and denial-of-service exposure; social-engineering hooks the design creates.

**Ask:** if someone deliberately tries to misuse this, where do they start — and what stops them there, specifically?
