# Module: Toolchains — Verification Recipes and Degradation Ladder

**Activate:** every REPORT run. **Mandatory** when tools are constrained, so a weak or offline executor cannot silently pretend it verified something.

## Capability degradation ladder

Declare what the executor actually has, then hold every claim to it. Never label a check verified above the rung the tools support.

1. **Full** — shell, network, and the project's own toolchain installed. Build it, run its tests and analyzer, run the vulnerability audit. Highest-confidence findings.
2. **Shell + network, no project toolchain** — read all code, sweep with grep, fetch external URLs and the OSV API. This was the Ananda level: static plus live checks. Compiler/test claims are [unverifiable here].
3. **Shell only, no network** — code and config inspection only. External URLs, live rules, and vulnerability data all become [unverifiable here] with the source named.
4. **No shell** — reason over supplied text only. Everything structural is [derived], nothing is [verified].

Dropping a rung never means guessing the missing evidence. It means labeling it honestly and, where it matters, offering the deeper pass.

## Native engine receipts

When shell access exists, use `engine/gauntlet.py` to create the manifest and store safe deterministic receipts. The engine never executes target code. It can resolve Git scope, hash and classify surfaces, scan text locally with secret values redacted, inspect standalone HTML structure, and inspect XLSX/XLSM, ODS, CSV, and TSV structure.

A check has two independent dimensions:

- **Execution:** pending, completed, failed, could_not_run, or skipped.
- **Result:** unknown, holds, fails, candidates, or not_applicable.

A completed scanner with candidate matches is not a failed tool and not a confirmed finding. A failed tool is not evidence the target passed or failed. Record the receipt path, artifact fingerprint, scope, environment, start and end, and limitations. Runtime, build, render, accessibility, recalculation, device, and production checks remain separate even when a static adapter is clean.

## Instrument traps (a result from these is void until re-run clean)

- **Truncated pipes:** output-compressing hooks cut long output before the next pipe stage; `ps | grep X` can return 0 for a running process. Re-run unfiltered (`rtk proxy ...`) or from a script.
- **Empty globs:** a glob that matches nothing can leave `grep` reading stdin or the working directory. Include a negative-control marker that must NOT match and a positive one that must.
- **Compressed binaries:** `strings` finds native-code markers but never compressed frontend code, so it looks trustworthy and is not. Check the built assets instead.
- **Hostile measurement environment:** an agent session may kill child processes; a runtime that loses its helper can silently fall back (for example GPU to CPU). Latency and performance numbers measured there are untrusted; hand them to a run outside the session.
- **Headless browsers on macOS:** add `--use-mock-keychain --password-store=basic` or the owner gets a keychain prompt.

## Safe verification commands (read-only)

- **Secret sweep:** grep for key formats (`sk_live`, `pk_live`, `AIza`, `-----BEGIN`, `Bearer `, `password`, `api_key`) across source, manifests, and configs. A committed private/secret key is CRITICAL; a publishable/embeddable key that is meant to ship is a pass with scope.
- **Transport:** grep `http://` for plaintext endpoints.
- **URL liveness:** `curl -s -o /dev/null -w "%{http_code}" -L --max-time 20 <url>` — read-only, no credentials, no state-changing verbs. Legal pages, support/help links, API base host, download links. Date-stamp the result.
- **Dependency vulnerabilities (no toolchain needed):** POST package name + version to the OSV API (`https://api.osv.dev/v1/query`, body `{"package":{"name":"X","ecosystem":"npm|PyPI|Pub|..."},"version":"Y"}`) over HTTPS. Read the lockfile, batch the queries, report known CVEs. This closes the "vulnerability audit needs the toolchain" gap for most ecosystems.
- **Never:** run untrusted code, hit authenticated or state-changing endpoints, exfiltrate secrets to test them, or execute an exploit to "prove" a vulnerability. Confirm read-only and stop.

## Per-stack quick recipes (where the toolchain is present)

- **Flutter/Dart:** `flutter analyze`, `flutter test`; `pubspec.lock` → OSV (Pub ecosystem). Absent toolchain = rung 2, as in the Ananda run.
- **JS/TS:** `npm audit` or `pnpm audit`; `package-lock.json`/`pnpm-lock.yaml` → OSV (npm). Lint/typecheck/test if configured.
- **Python:** lockfile → OSV (PyPI); run the configured linter and test runner.
- **Cloud/infra:** grep IaC (Terraform, Docker, k8s, CloudFormation) for public buckets, `0.0.0.0/0` ingress, wildcard IAM actions, `privileged: true`, plaintext secrets in env blocks.
- **Browser extension:** read `manifest.json` — host permissions breadth, content-script injection scope, `externally_connectable`, remote code.

Whatever ran, its exact scope is stated in the report; whatever did not run is named, not implied.
