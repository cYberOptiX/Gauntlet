# Module: Spreadsheets and Workbooks

**Activate when:** the target is CSV, TSV, XLS, XLSX, XLSM, ODS, Numbers, or another tabular or workbook artifact. Also activate when a system imports, generates, or relies on one.

**Evidence boundary:** structural parsing can prove what the package contains. Formula correctness, business meaning, displayed layout, recalculation, macros, and downstream imports require their matching tools and scenarios. A stored cached value is not proof a formula recalculates correctly.

## Native structural probe

Run the workbook adapter where supported:

```bash
python3 <skill-root>/engine/gauntlet.py inspect-workbook <file> -o <receipt.json>
```

The standard-library probe covers XLSX/XLSM, ODS, CSV, and TSV structure. Legacy XLS and proprietary formats report CANNOT VERIFY unless an appropriate local parser exists. Receipts redact cell contents by default.

## Inventory before judgment

- File format, application and version expectations, workbook calculation mode, locale, date system, and external compatibility.
- Every visible, hidden, and very-hidden sheet; rows, columns, tables, names, formula regions, array or spilled formulas, pivots, charts, filters, validation, protection, comments, objects, connections, queries, macros, scripts, and embedded files.
- Input cells, calculated cells, outputs, instructions, assumptions, scenario controls, and delivery or export ranges.
- External workbooks, URLs, data sources, add-ins, custom functions, templates, and local paths.

Every sheet and load-bearing named range is a manifest surface. Sampled cell regions state their sampling; do not imply workbook-wide formula review from several visible rows.

## Formula and calculation integrity

- Normalize copied formulas by relative position. Find drift, hard-coded islands, broken references, circularity, inconsistent anchors, omitted rows, double-counted subtotals, and references to hidden or stale data.
- Inspect lookup exactness, error handling, blank behavior, mixed types, units, sign conventions, precision, rounding, money, percentages, dates, time zones, and locale-dependent parsing.
- Check volatile and indirect functions, iterative calculation, manual calculation mode, stale caches, and formulas unsupported by the intended viewer.
- Recalculate in a clean compatible engine when safe. Compare raw values, stored caches, displayed values, and an independent result for sentinel scenarios.
- Add boundary rows or values that expose off-by-one ranges. A plausible total is not evidence of a correct range.

## Inputs, scenarios, and user safety

- Make editable inputs distinguishable without relying on color alone. Confirm units, accepted ranges, validation, protection, and clear instructions.
- Exercise blank, zero, negative, duplicate, extreme, missing, new-row, new-period, alternate-locale, and malformed-import cases.
- Confirm destructive edits, sort and filter behavior, copy-paste, row insertion, column insertion, sheet duplication, and refresh do not silently break formulas or references.
- Errors must identify the affected input or dependency and a corrective path; hiding errors with blank strings or zero is a finding when it masks failed calculation.

## Hidden behavior, privacy, and active content

- Trace every hidden sheet, row, column, name, object, comment, and formula that contributes to a visible result.
- Inventory macros, scripts, external data refresh, executable links, and embedded files. Do not enable unknown macros to inspect them.
- Scan locally for personal, financial, credential, location, author, path, revision, and organization metadata. Reports identify coordinates and classes, not sensitive values.
- Check protection claims honestly: worksheet protection is often edit friction, not encryption or access control.

## Presentation, accessibility, and delivery

- Verify headings, frozen regions, reading order, print areas, repeating headers, pagination, charts, labels, legends, contrast, text alternatives, and keyboard operation.
- Test the actual delivery formats: workbook, PDF, CSV, print, copy, and downstream import. Confirm headers, precision, encoding, visible scope, formulas versus values, and hidden content policy survive.
- Record the intended application and minimum version. A workbook that only works in the author's environment is not portable.

## Clean-bill minimum

A clean workbook verdict requires: structural inventory; no unexplained hidden or external dependency; formula consistency checks; recalculation or an explicit CANNOT VERIFY; sentinel scenarios; raw-type inspection; privacy and active-content review; and delivery-format verification. Generic visual inspection alone cannot satisfy it.
