# Module: Universal Artifact Adapters

**Activate when:** the target is a file, directory, package, mixed submission, or unfamiliar artifact whose inspection path must be chosen. Use only the matching subsections after classification.

**Principle:** anything may enter; no format earns invented certainty. Identify the real type, map how it can fail, use safe native tools, and state the specialist boundary when the available adapter cannot prove a claim. The first-party baseline is available through `python3 <skill-root>/engine/gauntlet.py inspect-artifact <file> -o <receipt>`; its structural result never substitutes for semantic, render, runtime, rights, or specialist proof.

## Adapter contract

Every first-party adapter follows the same sequence:

1. **Detect** the real type from content, magic, container, metadata, and structure, not extension alone.
2. **Inventory** every meaningful surface, hidden object, reference, active component, dependency, and delivered variant.
3. **Probe safely** with read-only parsing, metadata inspection, schema checks, or sandboxed runtime where the target is trusted and authorized.
4. **Interrogate semantically** against purpose, domain rules, hostile inputs, failure states, privacy, accessibility, and lifecycle.
5. **Anchor** findings in artifact-native coordinates: file and line, route and element, sheet and cell, page and object, timestamp and channel, frame, metadata field, or equivalent.
6. **Emit receipts** for checks and limitations. Parsing success proves structure was readable, not that content is correct.
7. **Clean up** temporary files, mounted images, browser profiles, servers, extracted content, and test data.

## Application and website

Map entry points, screens or routes, services, stores, permissions, network boundaries, release assets, and packaged outputs. Review source, then drive the delivered product. Exercise first run, loading, empty, full, error, denied, offline, slow, interrupted, upgrade, and removal states. Capture console, network, accessibility, storage, persistence, and platform evidence. Source-only confidence cannot produce a premium verdict for a rendered product.

Activate `platform.md`, `experience.md`, `runtime.md`, `operations.md`, `premium.md`, and the application or web rule pack.

## Standalone HTML

Use the `html` adapter for static inventory, then open the exact delivered file in its intended browser and file-protocol context. Test offline, narrow and wide viewports, keyboard, reduced motion, every control, state change, copy, print, download, export, local storage, runtime errors, and unexpected requests. A builder preview is not the artifact.

Activate `platform.md`, `experience.md`, `security.md`, and `rules/html.json`.

## Documents and PDFs

Identify source versus exported final. The native baseline inspects PDF markers and active-content indicators, DOCX/EPUB/Pages package containment, macros or scripts, external relationships, comments, revisions, and RTF active controls without rendering or executing them. Inventory structure, pages, headings, tables, forms, links, references, active content, attachments, fonts, metadata, comments, hidden text, revisions, signatures, and accessibility tags. Render the delivered file in intended viewers and print or export paths. Resolve material claims and references. Never infer that visible text is the complete file when hidden layers or package contents exist.

Activate `sources.md`, `experience.md` when accessibility matters, and `rules/document.json`.

## Images, audio, and video

The native baseline validates PNG chunk structure and checksums, JPEG/GIF boundaries and dimensions, SVG active or external content, redacted secret candidates, and WAV stream properties. Other codecs return a named capability limit. Inspect type, container, streams, duration or dimensions, encoding, corruption, metadata, embedded art or chapters, origin fields, and delivered variants without re-encoding unless authorized. Review provenance, rights, disclosure, captions, transcripts, descriptions, technical quality, and fit for the actual channel. Visual or audible semantic claims require human inspection; metadata alone cannot prove them.

Activate `sources.md` for factual or rights claims and `rules/media.json`.

## Archives, binaries, installers, and disk images

Do not execute unknown or third-party content. The native ZIP baseline enforces entry, expansion, and compression-ratio budgets; checks duplicate and escaping paths, links, special and encrypted entries, checksums, executable payloads, and nested archives; and never extracts. Other containers receive type and hash inventory plus an explicit parser limit. Inspect signatures, type, structure, entries, normalized paths, links, permissions, active content, nested archives, metadata, provenance, dependencies, and platform compatibility. Never extract an untrusted archive into a real project or user folder. Use a disposable sandbox when authorized. Name every claim that requires a malware lab, specialist parser, signing identity, or target OS.

Activate `security.md`, `dependencies.md`, `platform.md`, and `rules/binary.json`.

## Structured data and configuration

Parse with the real consumer when available. Validate schema, references, invariants, types, units, precision, ordering, encoding, environment precedence, secrets, provenance, privacy, migration, rollback, and round-trip behavior. A generic JSON or YAML parse is not proof the deployed consumer accepts the file.

Activate `data.md`, `security.md`, `operations.md`, and `rules/data.json`.

## Unfamiliar or mixed artifacts

1. Record the type as unknown or mixed; do not force the nearest familiar category.
2. Inspect magic, container, metadata, strings, references, and active-content indicators with read-only tools.
3. Derive failure modes from what consumes the artifact, what it controls, what it contains, and what happens if it is malformed or hostile.
4. Apply universal gates plus any justified existing adapter in LIMITED mode.
5. Mark unsupported semantic or runtime claims CANNOT VERIFY and name the exact parser, specialist, device, or environment that would settle them.

The result can be rigorous without pretending to certify what the available tools cannot understand.
