# Module: Premium Release Bar — Would a Top-Tier Company Ship This?

**Activate when:** the target is an app, site, or tool that real people will use, and the user wants it ready for use rather than "it runs". **Skip when:** the target is a plan, a library with no user surface, or throwaway by the user's own statement.

**Method:** this is the review a platform owner's app-review team and a premium product team run before launch. Where the app can run here, **drive it** — do not grade pixels from source. Render it at the smallest and largest supported window or screen, in light and dark, on first launch with no data, with a lot of data, offline, and after a kill mid-save. Screens seen are [verified]; screens reasoned from code are [derived].

## 1. First five minutes
- First launch with an empty store: does it explain itself, offer one clear first action, and never show a blank, broken, or debug screen? Sample or placeholder content ("Lorem", "Test", "TODO", `undefined`, `NaN`, `[object Object]`, raw IDs, raw error codes) visible to a user is a finding.
- Every permission prompt appears at the moment of need, after a sentence of context, and the app still works when it is denied.
- Nothing a user sees says "coming soon", leads to a dead button, or opens an empty sheet. Unfinished features are hidden, not stubbed (Apple guideline 2.1 app completeness).

## 2. Every state, every screen
- For each screen: loading, empty, partial, full, error, offline, no-permission, and too-much-data (long names, 10,000 rows, huge files). A missing state is a finding, not polish.
- Every action gives feedback within ~100 ms; anything longer than ~1 s shows progress; anything longer than ~10 s can be cancelled.
- Destructive actions confirm or offer undo. Undo and redo work where a user expects them (text, moves, deletes).
- Errors say what happened, in plain words, and what to do next. Never a stack trace, never "Something went wrong" alone.

## 3. Craft
- One type scale, one spacing scale, one radius scale, one icon family, applied everywhere; values come from tokens, not one-off numbers. Count the one-offs.
- Alignment, optical balance, truncation with ellipsis and full text on hover, no text overlap, no layout jump when content loads or a title is edited.
- Light and dark both designed, not inverted; contrast meets WCAG AA in both, including over translucent or glass surfaces on a bright background.
- Motion has a purpose, is fast (roughly 150-300 ms for UI), can be interrupted, follows the pointer where dragged, and honors reduced motion. Nothing flashes, jitters, or animates layout on every keystroke.
- App icon, window title, About box, version number, and empty-state art are finished, consistent, and on brand.
- **No generated look.** Anything that makes the interface read as AI-made is a finding at MEDIUM or higher, because the owner's bar is a design that is unique and ownable.
  - **Owner rule, never allowed: a colored vertical bar or thick left border on a card, notice, toast, callout, quote, list item, or active navigation item.** Flag every instance (search the styles for `border-left`, `border-inline-start`, and absolutely positioned `::before` or `::after` strips at `left: 0`). The fix signals tone or selection another way: a tint or light inside the surface, a changed fill, weight, or an icon. Never a narrower or softer bar.

## 4. Platform conventions (use the native rules the target runs on)
- **macOS:** standard menu bar (App, File, Edit, View, Window, Help) with working standard shortcuts (⌘, Settings, ⌘N, ⌘W, ⌘Q, ⌘Z/⇧⌘Z, ⌘F, ⌘C/⌘V in every text field); window size and position restored; full screen and split view behave; right-click menus where users expect them; drag and drop; Esc closes sheets and popovers; focus ring visible; system accent, text size, and appearance respected; signed and notarized.
- **iOS / iPadOS:** safe areas, Dynamic Type to the largest size, standard gestures (back swipe, pull to refresh where lists refresh), haptics used sparingly, state restoration after the app is killed.
- **Web:** works without layout break from 320 px to wide desktop; back button, deep links, and refresh keep the user's place; favicon, page titles, social preview metadata, 404 page; no console errors on a clean load.

## 5. Speed budgets (judge against the plausible machine and data)
- Cold launch to usable: target under 2 s on the owner's class of machine; warm under 1 s.
- Scrolling and dragging hold the display rate (60 or 120 fps); long lists virtualize.
- Search and filter feel instant (under ~100 ms for local data at plausible size).
- Idle CPU near zero, no polling loops, memory flat over an hour of use, battery impact small. Measure where possible; otherwise name the measurement.
- Installed size proportional to what the app does.

## 6. Trust
- The user never loses work: autosave or explicit save that cannot be skipped by quit, crash, sleep, or update. Kill the app mid-write and relaunch: the data is intact.
- Backup or export exists for anything the user would cry about losing; import restores it.
- Data leaves the device only where the user was told, in words, before it happened. AI or cloud features say which provider sees what.
- Updates never break stored data (migrations tested on a real older store, not only a fresh one).

## 7. Words
- Copy is short, specific, consistent in terms (one name per concept), sentence case, free of jargon and of developer language ("null", "sync failed: 500"). Numbers, dates, and times follow the user's locale and 12/24-hour setting.
- The same action has the same label everywhere.

## 8. Accessibility (as a release gate, not a checklist)
- Walk the core task with keyboard only, then with the screen reader on. Every control has a name, role, and state; focus order follows the visual order; nothing is reachable only by hover or only by color.
- Text scales without clipping; reduced motion and increased contrast are honored.

## 9. Release engineering
- Version and build number increase each release; changelog exists; a crash or error report reaches the developer without leaking user content.
- Clean-machine install works (no dependency on the developer's paths, keys, or tools). Uninstall leaves nothing surprising.
- Legal and store items where distribution requires them: privacy policy that matches actual collection, terms, licenses for bundled code, fonts, and models (see `platform.md`, `data.md`, `lifecycle.md`).

## Readiness ladder (use in the verdict)
State the highest rung the evidence supports, and the finding IDs that block the next one:
1. **Runs** — builds and starts on the developer's machine.
2. **Personal use** — the owner's daily use is safe; data cannot be lost.
3. **Private beta** — a stranger can install and finish the core task without help; no CRITICAL or HIGH open.
4. **Public release** — every state, platform convention, accessibility, and legal item above passes; store review would pass.
5. **Premium** — the craft, speed, and words sections pass on a real render; nothing in the product reads as unfinished or generic.

**Ask:** a demanding stranger uses this for one week on real data — what is the first thing that makes them trust it less?
