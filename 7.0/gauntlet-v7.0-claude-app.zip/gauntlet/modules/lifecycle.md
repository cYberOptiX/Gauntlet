# Module: Lifecycle — Maintainability, Debt, Future-Proofing, Docs, Compliance

**Activate when:** almost always for implementations and plans — this module carries the future-risk battery Phase 3 requires. **Skip when:** the submission is throwaway by the user's own statement.

## Maintainability
- Could another competent developer understand, modify, debug, and extend this without the original author explaining undocumented behavior? That question governs the whole section.
- Structure, modularity, complexity; build and environment setup instructions that actually work; hidden dependencies; knowledge concentrated in one head (bus factor); fragile or unownable components.

## Technical debt
- Kinds: architectural, code, test, security, dependency, documentation, infrastructure, UX, data.
- For each item that matters: current consequence, future consequence, cost to fix now vs later, whether it is acceptable, and the recommended remediation window. Intentional, documented debt is a decision; hidden debt is a finding.

## Future-proofing battery
Apply to load-bearing findings and structures. Every future risk needs a plausible trigger — no science fiction.
- Is it a problem today? What transition makes it one — at what user count, data volume, or cost level?
- What happens when: the OS changes; a framework or dependency majors; an API changes; a provider disappears or reprices; the app, team, or database grows; security or privacy expectations rise; the workaround must carry one more feature; the original developer is gone?
- Will fixing this later be substantially more expensive than now? Is today's convenience creating tomorrow's problem?
- Output horizon per Phase 3: active / emerging (named near trigger) / future.

## Documentation
- README, install/build/config instructions, architecture and API docs, user/admin docs, troubleshooting, recovery — present where needed, absent where noise.
- Outdated or incorrect docs, and docs that contradict the implementation, outrank missing docs — they actively mislead.

## Licensing and platform compliance
- Software and open-source licenses (own and third-party); distribution restrictions; store/platform technical requirements; required disclosures, consent mechanisms, and deletion functionality where data handling demands them.
- Label each item: confirmed requirement, likely requirement, or possible requirement needing verification. Never fabricate legal conclusions — flag for professional review when stakes warrant.

**Ask:** it is eighteen months from now and this succeeded — which of today's decisions does its maintainer curse first?
