# Module: Operations — Build, Config, Deploy, Testing, Observability, Cost

**Activate when:** the submission is built, shipped, deployed, operated, or tested. Activate only the subsections the submission actually has a surface for.

## Build system
- Build scripts and configuration; debug vs release differences; reproducibility; environment assumptions; target architectures.
- Signing and packaging; minification/obfuscation and source-map handling; debug symbols.
- Contamination: secrets, dev assets, or test assets packaged into production artifacts.

## Configuration
- Env vars and config files; defaults; dev/test/prod separation; missing, invalid, conflicting, or unsafe values; debug settings reachable in production.
- Hard-coded environment assumptions; feature flags and remote config; rollback of a bad config.

## Install, update, migration, removal
- Install, upgrade, downgrade; automatic vs manual updates; interrupted, failed, and partial updates; rollback.
- Config and database migration on update; user-data preservation across versions; uninstall residue: files, credentials, services, config.

## Deployment and release
- Versioning and build numbering; signing and certificates; distribution path and its platform requirements.
- Environment promotion; staged/canary rollout where scale warrants; migrations during deploy; production secrets handling; debug functionality left enabled.

## Testing quality
- What exists: unit, integration, end-to-end, and the specialized kinds the system's risks demand (security, load, migration, recovery, fuzz, accessibility).
- What is missing: untested critical paths ranked by consequence — the test that would have caught the findings in this review is the first recommendation.
- Test health: coverage claims vs reality, independence, flakiness, tests that assert nothing, false confidence.
- A large green suite proves only what it exercises. Look for the shipping branch hard-mocked away (a toggle always mocked off), heavy tests on dead code beside none on the live path, verdicts recorded as bare booleans where "could not run" collapses into pass, and tests that depend on today's date or pass alone but fail under full-suite load.
- Behavior that exists only in the packaged build (CSP, signing, embedded assets, bundled helpers) is untested by dev-server and unit runs; say so, and name the packaged check that would cover it.

## Observability and diagnostics
- Logging: quality, levels, structure — and sensitive data leaking into logs.
- Metrics, tracing, crash and error reporting, health checks, audit trails for security events.
- Alerts: thresholds, fatigue, and whether a real failure actually reaches a human; root-cause visibility when something breaks at 2 a.m.

## Operational readiness
- Runbooks, known-failure procedures, emergency shutdown, restoration, dependency-outage procedures; admin and diagnostic tools; support path; incident and security response.

## Cost sustainability (only when the design creates real cost exposure)
- Hosting, API, storage, network, AI-inference, licensing, and third-party costs; growth of cost with users and data; hidden recurring expenses; architectures that are expensive for no benefit.

**Ask:** walk the path from "developer finished" to "user running it" — where does that path break, and who notices?
