# Module: Sources — Authoritative Rulebooks

**Activate when:** any finding cites an external rule, store requirement, law, or standard.

**Governing rule:** the text below is a starting map, frozen at the executor's training cutoff. Rules, thresholds, and deadlines move. Before a finding cites a specific requirement, fetch the current authoritative page and date-stamp it. If the network is unavailable, the finding is [unverifiable here] and says which source must be checked — never assert a current legal or store rule from memory alone. Cite the specific document and clause, never "regulations require."

## App stores
- Apple App Review Guidelines; Apple Developer Program License Agreement; App Store Connect data-privacy (App Privacy "nutrition labels"); required-reason API and privacy manifest rules.
- Google Play Developer Program Policies; Play Console Data safety form; target API level requirements; sensitive-permission and data-deletion policies.
- Store deadlines change yearly (target API level, privacy manifest enforcement) — always fetch the current date.

## Privacy and data protection
- EU GDPR (EDPB guidance, europa.eu) and UK GDPR (ICO). US state laws: CCPA/CPRA (California AG/CPPA) and successors in other states. COPPA (US FTC, children under 13). Canada PIPEDA. Brazil LGPD. China PIPL. India DPDP. UAE PDPL; Saudi PDPL. Australia Privacy Act.
- Cross-border principle: obligations follow the user and the distribution choice, not the developer's nationality. Map regimes from what the code collects and where the app is offered. Confirmed / likely / possible only — a lawyer converts exposure into obligation.

## Security standards
- OWASP: Top 10 (web), API Security Top 10, Mobile Top 10, MASVS for mobile. CWE for classifying a weakness. NIST guidance where a US posture is claimed.
- Payments: PCI DSS. The reliable escape is never touching card data — tokenized SDK flows keep the app out of scope; a hand-rolled card form pulls it in.
- Live vulnerability data: the OSV database has a free HTTPS API (see `toolchains.md`) for known package vulnerabilities without any local toolchain.

## Accessibility (increasingly law, not polish)
- WCAG 2.2 (W3C) is the reference standard. European Accessibility Act applies to e-commerce and many digital services serving the EU (in force June 2025). US: ADA litigation targets websites and apps; Section 508 for US government-facing work.

## Advertising and creative
- US FTC Act and endorsement/testimonial guides (claims substantiation, disclosure of paid endorsements). EU consumer-protection and unfair-commercial-practices rules. Platform ad policies (Meta, Google, TikTok). Trademark and copyright/licensing for supplied assets and fonts.

## Escalate, do not certify
Smart contracts and crypto custody, medical device software (FDA/CE), gambling and gaming licences, aviation/automotive/industrial safety-critical systems. The Gauntlet reports what it sees and states that a licensed specialist audit is required.
