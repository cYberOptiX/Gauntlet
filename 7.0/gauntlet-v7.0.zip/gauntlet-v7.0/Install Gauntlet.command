#!/bin/zsh
# Installs Gauntlet v7.0 into ~/.claude/skills/gauntlet for Claude Code.
set -e
HERE="${0:A:h}"
DEST="$HOME/.claude/skills/gauntlet"
mkdir -p "$HOME/.claude/skills"
if [ -e "$DEST" ] || [ -L "$DEST" ]; then
  BK="$HOME/.claude/skills-backup/gauntlet-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$HOME/.claude/skills-backup"
  mv "$DEST" "$BK"
  echo "Old gauntlet moved to: $BK"
fi
cp -R "$HERE/gauntlet" "$DEST"
echo "Installed: $(grep -m1 'version:' "$DEST/SKILL.md")"
echo "Done. Start a new Claude Code session, then type /gauntlet"
